Hecke Actions and Pure Inner Forms in Families of Real Langlands Parameters
Minghua Dou and Jiawei Yang
Preprint release 2026-11-25-r3

From the root of a freshly extracted source archive, compile the paper with
TeX Live, XeLaTeX, BibTeX and latexmk:

  latexmk -xelatex -interaction=nonstopmode -halt-on-error main.tex

The entry point is main.tex. All its inputs, references.bib, and the compiled
bibliography main.bbl are included. The proof by root system and the finite
verification procedures appear in Appendix C. The paper can be compiled
independently of the exceptional computations.

The auxiliary programs, inputs, compact certificates and ledgers are in anc/.
Start with anc/README.txt. It identifies each input used in the proof, gives
the clean regeneration commands, and distinguishes the checks repeated for
this release from the earlier full runs. To run the portable suite and check
the archived pass histories from the root of this archive, use

  python3 anc/run_checks.py --outer-e6
  (cd anc && python3 check_e7_outputs.py && python3 check_e8_outputs.py)

The full exceptional runs require the separate commands in anc/README.txt.
The large action tables and equality forests can be regenerated from the
supplied programs and inputs. The length-64 residual tree is included.

anc/SHA256SUMS.json records the byte counts and SHA-256 digests of every file
in this source archive except the manifest itself. The release directory also
has SHA256SUMS.txt for the accompanying PDF and complete source ZIP.
