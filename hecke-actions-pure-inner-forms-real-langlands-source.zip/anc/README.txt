FINITE CERTIFICATES FOR HECKE ACTIONS AND PURE INNER FORMS
IN FAMILIES OF REAL LANGLANDS PARAMETERS
Jiawei Yang and Minghua Dou
23 November 2026; verification notes updated 25 November 2026

1. What this directory contains

This directory supplies exact integer and rational computation used in
the parts of the paper on ordinary tilting coefficients, exceptional root systems,
and the computation appendix. The relative directory
names are stable names used by the programs; they do not indicate additional
mathematical dependencies on earlier drafts. Run the commands below from
this anc/ directory unless a command explicitly says otherwise.

Requirements: Python 3.10 or later (standard library only), GCC or Clang
with C++17 support, and a
little-endian 64-bit Unix-like platform for the supplied binary certificates.
Run Python without -O or -OO; leave PYTHONOPTIMIZE unset. Compile C++
without -DNDEBUG. Both sets of programs use assertions to verify inputs and outputs. Programs use exact
integers, finite sets, or rational arithmetic, not floating-point tolerances.

The paper proves why the recorded source, endpoint, and equality implications
hold for the actual ordinary marked coefficient. Code checks those finite
implications. In particular, the E8 equality forest needs the geometric
anchor in the E8 subsection and the vanishing theorem at a marked diagonal; the forest alone
does not prove the vanishing of its one unanchored component.

Clean start and verification order
----------------------------------
Unpack the source ZIP into a new writable directory. It should contain
main.tex and anc/ side by side. Keep a copy of the archive; full replay
writes newly computed records beside its inputs. Section numbers in different
builds may change. The TeX labels below locate the exact mathematical claims.

From the directory containing main.tex:
  python3 anc/run_checks.py --outer-e6
  python3 anc/check_e7_outputs.py
  python3 anc/check_e8_outputs.py

The first command recompiles and runs the portable checks. The next two
compare recorded or newly regenerated outputs. For full regeneration,
change into anc/, follow E7_COMMANDS.txt, then execute Sections 4 and 5
of this README in order. The E8 factorization uses the audited E7 group
table; it does not use E7's guard results.

Claim in the paper                 Input and verification in this directory
------------------------------------------------------------------------------
base:outer-a3-a4                   round26/descent/check_outer_small_sources.py;
                                   replay_outer_small_sources.py reconstructs
                                   the Bruhat padding from subwords.
sec:finite-forcing                 round26/root_audit/small_marked_closure.py
(G2, F4 and trivial action on E6)  --e6, using the Cartan matrices, marks and
                                   source identities. Independent raw G2/F4
                                   check in round26/local_redteam/.
oe6:ordinary                       round26/descent/e6_inputs/ contains the
(outer E6)                         source list, expected mu values, endpoint
                                   events and missing rows. run_checks.py
                                   gives the precise file arguments to the
                                   source, mu, event and positive replays.
e7:guard-support;                  E7_COMMANDS.txt, including the independent
e7:central-ordinary                group table and per-orbit raw guard checks.
                                   check_e7_outputs.py compares their records.
e8:layer-replay                    round21/computation/: source generation,
                                   sink census, forest construction and raw
                                   verifier. Steps 4 and 5 below give inputs.
e8:chosen-state;                   The length-64 residual TSV, compact binary
e8:diagonal-coefficient;           keys and edges, and word dictionary are in
e8:central-ordinary                round21/computation/. check_e8_outputs.py
                                   matches the residual states to the keys.
                                   The root-matrix core replay checks every
                                   edge. check_e8_anchor.py checks the raw
                                   phase used in the geometric argument.
------------------------------------------------------------------------------
The E7/E8 ledger checks are fast because they read records. Replaying a
forest relation requires the binaries built in steps 4 and 5. In particular,
a counts-only check cannot detect an invalid head incidence.

2. Portable checks

From the parent directory (the directory containing main.tex), run:

  python3 anc/run_checks.py
  python3 anc/run_checks.py --outer-e6

The first command checks the selected E8 anchor, the independent Euclidean
root model and rank-one recurrence, all 1,920 Schreier transitions, the
nonstable-middle control, the outer A3/A4 source lists, and the compact E8
core. It regenerates the 20,717 root matrices needed for the 35,419 states
and verifies all 35,418 equality edges. It does not read an E7/E8 group-sized
cache. The second command additionally regenerates the entire outer-E6
source, Kazhdan--Lusztig, endpoint-event, and positive-elimination checks.
In the 25 November 2026 run, all 16 commands (including compilation)
succeeded. On an Apple M5, macOS arm64, Python 3.14.6 and Apple Clang 21,
the full portable command took 18.06 s elapsed. /usr/bin/time -l reported
620,576,768 bytes maximum resident set size. This is a measurement of the
portable invocation; the full runs have different resource requirements.

Both commands run in an isolated temporary copy of the supplied inputs and
write logs and the newly generated JSON results to anc/replay_output/.
Use --output /an/absolute/path to select another output directory. Read
replay_ledger.json for the exact executed commands and exit status.

Outer E6 expected totals:
  original source labels                         26,242
  additional source labels                       19,892
  union of source labels                         26,760
  checked KL recurrence pairs (including zero)  481,490
  positive KL values                             84,837
  checked endpoint events                       240,317
  nonnegative equation rows                      90,782
  active variables          15,407 -> 115 -> 33 -> 1 -> 0

The retained input lists are in round26/descent/e6_inputs/. The source,
recurrence, event and elimination programs are separate. The recurrence
check includes the zero values; it does not merely verify the positive list.

3. E7 full regeneration

E7_COMMANDS.txt gives the complete ordered commands, including the group
builder, an independent group-table audit, the raw-mark quotient audit,
three primary zero-forcing calculations, and independent dense checks.
Execute that file's commands from this directory. Large files are generated
locally. The source archive intentionally omits these regenerable caches.

The exact order is 2,903,040. The source census has 1,689,999 labels and
1,213,041 remaining labels. The raw mark orbits have sizes
1, 1, 63, 63, 56, 72. Quotient calculations use orbit sizes 63, 28, 36,
with raw lifting multiplicities 2, 4, 4. The final three independent
checks must report complete_actual_zero=true. Higher-gap KL coefficients
are not evaluated by these conservative-guard checks.
The final command python3 check_e7_outputs.py checks the complete JSON
acceptance conditions and agreement of the two implementations. Executing
that command on the supplied records does not rerun the full E7 calculation.

For this revision we regenerated the group action and source labels, rebuilt
the raw mark quotient, and ran all four executables for each of the three
blocks. Every initial Boolean was compared independently. The primary and
independent pass histories reproduced the recorded histories through zero.
The twelve block executables took 285.36 s total, excluding compilation and
group-table setup, with 2,089,631,744 bytes the highest per-process RSS.
E7_COMMANDS.txt gives the individual timings.

4. E8 model, sources, and sink census

The full E8 regeneration is a large computation. Run it serially with
at least approximately 6 GB available RAM and sufficient local disk space. The
retained complete forest occupies 17,620,902,048 bytes (about 17.6 GB),
in addition to approximately 3.5 GB of group-action/source caches and
temporary files. Also allow 185,795,092 bytes for the E7 table, space for
the compiler, logs and independent guard arrays; 17.6 GB alone is insufficient.
On the Apple M5 used for the portable measurement we rebuilt the following
stages from the distributed source. Timings exclude compilation; individual
peak RSS values are from /usr/bin/time -l, with GB in decimal units:

  stage                                   elapsed (s)       peak RSS (GB)
  E7 group table generation / audit          3.88 / 0.99      0.68 / 0.19
  E8 remaining simple left action            8.20             2.89
  E8 all-label source gather / scatter      20.37 / 12.53     2.99 / 3.32
  E8 independent sink census                 3.25             3.33
  E8 orbit 135, length 64, generate        106.29             3.61
  E8 orbit 135, length 64, verify            5.67             3.35

For planning, generation of layer 64 in this orbit examined 21,289,288 heads
in 104.2 s after setup. The recorded two-orbit run examined 813,884,180 heads.
At that rate generation would take about 66 minutes, plus setup and the
independent verification. Costs per head, memory and disk throughput vary
by layer. No measured end-to-end time or peak RSS was retained for the
historical run of all 242 layers.
Do not run the large stages concurrently on a memory-constrained machine.

First build and independently audit the E7 table as in E7_COMMANDS.txt.
Then run these small model checks and input generators:

  python3 round20/e8_frontier/schreier_transversal.py
  python3 round20/e8_frontier/audit_schreier_euclidean.py
  python3 round21/root_audit/audit_e8_schreier_model.py
  python3 round21/computation/prepare_e8_factor_input.py
  python3 round21/computation/e8_color_quadratic.py
  python3 round21/structure/e8_black_sink_quadratic_audit.py

Build the missing simple reflection and the source census:

  g++ -O3 -std=c++17 round21/computation/e8_source_terminal.cpp -o /tmp/e8-source
  /tmp/e8-source build_l8 240
  /tmp/e8-source source
  g++ -O3 -std=c++17 round21/computation/e8_source_independent_audit.cpp -o /tmp/e8-source-audit
  /tmp/e8-source-audit
  g++ -O3 -std=c++17 round21/computation/e8_sink_census.cpp -o /tmp/e8-sink-census
  /tmp/e8-sink-census

The two source algorithms are lower-predecessor gathering and upward
scattering. Their byte arrays must agree at every one of the 696,729,600
group elements. The source census is 171,947,976 and the residual census
is 524,781,624. The two nontrivial raw-mark orbits have sizes 120 and 135;
their sink-state totals are 88,916,761 and 461,736,429.

5. E8 full equality-forest generation and independent replay

  g++ -O3 -std=c++17 round21/computation/e8_levelwise_lazy.cpp -o /tmp/e8-forest
  /tmp/e8-forest 120 120 --certificate
  /tmp/e8-forest 135 63 --certificate
  mv round21/computation/e8_lazy_levelwise_135.json round21/computation/e8_lazy_levelwise_135_L0_63.json
  /tmp/e8-forest 135 120 --certificate 64
  /tmp/e8-forest 135 120 --certificate 65 --continue-conditional

The third orbit-135 run starts at length 65. The preceding call requests
64--120 and stops at length 64, which is recorded in its completed_range.
The orbit-135 length-64 call is expected to retain precisely one equality
component with 35,419 states. The last call checks the implications at
lengths 65--120 under the shorter-length premises, which the geometric
anchor supplies in the proof. No residual component is being declared zero
by the generator. Binary forest files are written one length at a time.

Independently replay all lengths, using raw marks and direct word data:

  g++ -O3 -std=c++17 round21/computation/audit_e8_levelwise_forest.cpp -o /tmp/e8-forest-audit
  /tmp/e8-forest-audit 120 120
  /tmp/e8-forest-audit 135 60 0
  /tmp/e8-forest-audit 135 63 61
  /tmp/e8-forest-audit 135 64 64 --allow-residual
  /tmp/e8-forest-audit 135 120 65

The last command verifies the higher-length implications; the induction
that discharges their premises is mathematical, as stated above. Across
both nontrivial orbits the complete forest has 550,653,189 records for
550,653,190 states. The difference of one is accounted for by the single
geometric anchor, not by an omitted check or a nonzero coefficient.

To re-extract the compact core from the newly generated length-64 files:

  python3 round21/computation/extract_e8_L64_core.py
  g++ -O2 -std=c++17 -I round21/computation round26/root_audit/audit_e8_core_root_matrices.cpp -o /tmp/e8-core-audit
  /tmp/e8-core-audit
  python3 round26/root_audit/check_e8_anchor.py
  python3 round27/local/independent_controls.py
  python3 check_e8_outputs.py

The core audit reconstructs its roots from explicit integer matrices, not
from the group-sized action cache. The supplied compact core already makes
the root and tree checks portable without the full forest (run them via run_checks.py). The ledger check
compares the 121 layers of each orbit; the residual-list check also verifies
that the word at code 359034028 and the raw index 5 match the anchor.

In this edition an independent run rebuilt the E7 action table and both
full E8 action/source caches. It generated all 14,812,036 relations at
length 64 of orbit 135, verified all 14,812,037 targets against those
relations, checked the one residual component, and re-extracted the compact
core. The three large tables and this layer's binary forest matched the
retained SHA-256 digests. Results for the other full forest layers are
documented by their original construction and replay records.

6. Other small controls

The first command regenerates the root-trivial small exceptional closure
including E6. The second independently repeats G2 and F4 on raw states.
The other commands test type-A and parabolic-source calculations:

  python3 round26/root_audit/small_marked_closure.py --e6
  python3 round26/local_redteam/check_small_closure_raw_states.py
  python3 round26/local_redteam/check_uniform_type_a.py
  python3 round26/r1_r2/nonstable_middle_root_check.py
  python3 round26/descent/check_outer_small_sources.py
  python3 round26/descent/replay_outer_small_sources.py

The retained small_marked_closure_with_e6.json includes the full
small exceptional closure run, not merely a random sample.

7. Provenance and integrity

retained_large_artifacts.json records the byte lengths and SHA-256 hashes
of the retained large E7/E8 artifacts. Those large artifacts are not in
this archive; the commands above regenerate them. Source and verifier
logic, exact small inputs, compact certificates, and retained output
ledgers are included. A hash checks file identity, not the mathematical
validity of a certificate. Acceptance is determined by the independent
verifiers and the hypotheses proved in the article.

verification_2026_11_25.json records this revision's portable check names,
fresh E7 counts and histories, full E8 source and sink census stages,
orbit-135 length-64 graph counts, per-stage timings and measured sizes,
and the matching digests of the reconstructed large and compact files.
The dated 2026_11_23 directories contain earlier replay records.
SHA256SUMS.json lists the byte count and SHA-256 digest of every source-archive
member except the manifest itself. Paths are relative to the directory containing main.tex.
