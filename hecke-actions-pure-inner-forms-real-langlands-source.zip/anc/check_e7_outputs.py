#!/usr/bin/env python3
"""Check the E7 replay's JSON acceptance conditions; this does not rerun it."""
from pathlib import Path
import argparse
import json


def require(condition, message):
    if not condition:
        raise ValueError(message)


def check(root):
    folder = root / 'round20/e7_computation'

    def read(name):
        return json.loads((folder / name).read_text())

    source = json.loads((root / 'round19/structure/e7_source_heads_independent_audit.json').read_text())
    require(source['status'] == 'PASS', 'Group/source audit did not pass')
    require(source['covered_count'] == 1689999 and source['missing_count'] == 1213041,
            'Wrong source census')
    require(read('e7_mark_quotient_audit.json')['passed'] is True, 'Raw-mark audit did not pass')
    residual = 1213041
    blocks = []
    for size, multiplicity in ((63, 2), (28, 4), (36, 4)):
        initial = read(f'e7_orbit{size}.json')
        primary = read(f'e7_orbit{size}_coarse.json')
        independent = read(f'e7_orbit{size}_coarse_independent.json')
        # New zero-only runs write the first name, including for the 28-mark block.
        # The older 28-mark retained run also checked a discovery phase.
        zero_name = f'e7_orbit{size}_dense_zero_independent_audit.json'
        baseline_name = zero_name if (folder / zero_name).is_file() else f'e7_orbit{size}_dense_independent_audit.json'
        baseline = read(baseline_name)
        require(primary['complete'] is True and primary['remaining_compressed_unknowns'] == 0,
                f'Primary {size}-mark closure is incomplete')
        require(independent['passed'] is True and independent['complete_actual_zero'] is True,
                f'Independent {size}-mark closure is incomplete')
        history = primary['raw_unknown_history']
        require(history == independent['raw_unknown_history'], f'{size}-mark histories differ')
        require(primary['productive_white_inverse_rows'] == independent['productive_white_inverse_rows'],
                f'{size}-mark inverse-row counts differ')
        require(history[0] == initial['phase1_raw_unknown'][-1] == baseline['actual_zero_unknown'],
                f'{size}-mark initial counts differ')
        require(history[-1] == 0 and all(a > b for a, b in zip(history, history[1:])),
                f'{size}-mark history does not decrease to zero')
        require(baseline['passed'] is True, f'{size}-mark initial pointwise audit failed')
        compared = baseline.get('raw_states_compared', baseline.get('raw_states_compared_per_phase'))
        require(compared == residual * size * size, f'{size}-mark initial comparison is incomplete')
        blocks.append({'orbit_size': size, 'raw_lift_multiplicity': multiplicity,
                       'history': history, 'baseline_file': baseline_name})
    require(sum(residual * b['orbit_size'] ** 2 * b['raw_lift_multiplicity'] for b in blocks)
            + 2 * residual == residual * 16260, 'Raw-sector accounting mismatch')
    return {'passed': True, 'scope': 'Acceptance conditions of supplied or regenerated E7 output records; not a fresh full replay.',
            'initial_raw_coordinates': residual * 16260, 'final_unknown_coordinates': 0,
            'blocks': blocks}


if __name__ == '__main__':
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--root', type=Path, default=Path(__file__).resolve().parent)
    args = parser.parse_args()
    print(json.dumps(check(args.root.resolve()), indent=2))
