#!/usr/bin/env python3
"""Cross-check the E8 source, layer and core records shipped with the manuscript."""
import csv
import json
import struct
from pathlib import Path

ANC = Path(__file__).resolve().parent
DATA = ANC / "round21/computation"
ANCHOR = "5423143565423143546765423143542654787654231435426543176542348765"


def require(condition, message):
    if not condition:
        raise ValueError(message)


def read(name):
    return json.loads((DATA / (name + ".json")).read_text())


def check_orbit(orbit, generator_ranges, audit_ranges, byte_counts):
    generated = {}
    for suffix, low, high in generator_ranges:
        name = f"e8_lazy_levelwise_{orbit}{suffix}"
        report = read(name)
        rows = report["levels"]
        require(report["orbit"] == orbit and report["certificate"], name)
        require([r["length"] for r in rows] == list(range(low, high + 1)), name)
        for row in rows:
            length = row["length"]
            require(length not in generated, name)
            generated[length] = row
    audited = set()
    for suffix, low, high, partial in audit_ranges:
        family = "partial" if partial else "independent"
        name = f"e8_levelwise_forest_{family}_audit_{orbit}{suffix}"
        report = read(name)
        require(report["status"] == ("PASS_PARTIAL_LEVEL" if partial else "PASS"), name)
        require(report["orbit"] == orbit and report["independent_full_raw_mark_partitions"]
                and report["every_sink_target_reconstructed"]
                and report["every_forest_relation_checked"], name)
        rows = report["levels"]
        require([r["length"] for r in rows] == list(range(low, high + 1)), name)
        for key in ("sink_states", "forest_events"):
            require(sum(r[key] for r in rows) == report["total_" + key], name)
        for row in rows:
            length = row["length"]
            require(length not in audited, name)
            audited.add(length)
            primary = generated[length]
            exceptional = (orbit, length) == (135, 64)
            path = f"round21/computation/e8_lazy_levelwise_{orbit}_L{length}_forest.bin"
            location = f"orbit {orbit}, length {length}"
            require(primary["sink_states"] == row["sink_states"]
                    and primary["forest_events"] == row["forest_events"], location)
            require(row["forest_events"] == row["equalities"] + row["source_head_boundaries"]
                    + row["ordinary_predecessor_boundaries"], location)
            require(row["forest_events"] == row["sink_states"] - int(exceptional)
                    and byte_counts[path] == 32 * row["forest_events"], location)
            require(primary["remaining_states"] == (35419 if exceptional else 0)
                    and primary["remaining_components"] == int(exceptional), location)
            # Earlier PASS ledgers only emitted counts of exceptions when positive.
            require(row.get("unresolved_states", 0) == primary["remaining_states"]
                    and row.get("unresolved_equivalence_components", 0)
                    == primary["remaining_components"], location)
    require(set(generated) == audited == set(range(121)), f"coverage of orbit {orbit}")
    return tuple(sum(row[key] for row in generated.values())
                 for key in ("sink_states", "forest_events"))


def check_core():
    states = set()
    codes = set()
    chosen = None
    with (DATA / "e8_lazy_levelwise_135_L64_remaining.tsv").open() as file:
        for row in csv.DictReader(file, delimiter="\t"):
            code, left, right = (int(row[k]) for k in ("code", "left_black", "right_black"))
            key = code | (left << 32) | (right << 40)
            require(key not in states and row["length"] == "64", "residual state")
            codes.add(code)
            states.add(key)
            if (code, left, right) == (359034028, 16, 16):
                chosen = row
    binary = (DATA / "e8_L64_core_keys.bin").read_bytes()
    packed = [k for (k,) in struct.iter_unpack("<Q", binary)]
    require(len(packed) == len(states) == 35419 and set(packed) == states
            and len(codes) == 10313, "residual list versus compact core")
    require(chosen and chosen["word"] == ANCHOR
            and chosen["left_raw"] == chosen["right_raw"] == "5", "anchor in residual list")
    with (DATA / "e8_L64_core_words.txt").open() as dictionary:
        count = int(next(dictionary))
        words = dict(line.split() for line in dictionary)
    require(len(words) == count == 20717 and words["359034028"] == ANCHOR,
            "anchor in compact dictionary")


def main():
    inventory = json.loads((ANC / "retained_large_artifacts.json").read_text())
    byte_counts = {r["path"]: r["bytes"] for r in inventory["large_artifacts"]}
    full = check_orbit(120, [("", 0, 120)], [("", 0, 120, False)], byte_counts)
    other = check_orbit(135, [("_L0_63", 0, 63), ("_L64_120", 64, 64),
                              ("_L65_120", 65, 120)],
                       [("_L0_60", 0, 60, False), ("_L61_63", 61, 63, False),
                        ("_L64_64", 64, 64, True), ("_L65_120", 65, 120, False)],
                       byte_counts)
    require(full == (88916761, 88916761) and other == (461736429, 461736428),
            "totals by orbit")
    require(read("e8_sink_census")["residual_compressed_sink_states"] == full[0] + other[0],
            "independent sink census")
    check_core()
    print("PASS: 242 orbit-lengths, 550653190 targets, 550653189 forest records.")
    print("The supplied residual list matches the 35419 compact keys and the selected anchor.")
    print("This checks the recorded results; a full replay also reads the generated forests.")


if __name__ == "__main__":
    main()
