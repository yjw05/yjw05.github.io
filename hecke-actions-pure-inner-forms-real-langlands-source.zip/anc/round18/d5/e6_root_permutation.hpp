#include <algorithm>
#include <array>
#include <cassert>
#include <cstdint>
#include <fstream>
#include <iostream>
#include <map>
#include <numeric>
#include <queue>
#include <string>
#include <unordered_map>
#include <vector>
using namespace std;
using Rt=array<int8_t,6>;using Perm=array<uint8_t,72>;
struct Group {
 int A[6][6]{},N=0,nw=0;vector<Rt> roots;vector<Perm> g;array<Perm,6>s;
 unordered_map<string,int>idx;vector<array<int,6>>R,L;vector<int>len,parent,last,dl,dr;vector<vector<int>>low;vector<uint64_t>down;
 string key(const Perm&p){return string((const char*)p.data(),72);}
 Rt refl(Rt a,int i){int d=0;for(int j=0;j<6;j++)d+=A[i][j]*a[j];a[i]-=d;return a;}
 vector<int>word(int u){vector<int>w;while(u){w.push_back(last[u]);u=parent[u];}reverse(w.begin(),w.end());return w;}
 bool below(int x,int w){return down[(size_t)w*nw+x/64]>>(x%64)&1ULL;}
 Group(){
  for(int i=0;i<6;i++)A[i][i]=2;for(auto [i,j]:vector<pair<int,int>>{{0,2},{2,3},{3,4},{4,5},{1,3}})A[i][j]=A[j][i]=-1;
  map<Rt,int>ri;for(int i=0;i<6;i++){Rt a{};a[i]=1;ri[a]=0;roots.push_back(a);}
  for(size_t i=0;i<roots.size();i++)for(int j=0;j<6;j++){Rt a=refl(roots[i],j);if(!ri.count(a)){ri[a]=0;roots.push_back(a);}}
  sort(roots.begin(),roots.end());assert(roots.size()==72);for(int i=0;i<72;i++)ri[roots[i]]=i;
  for(int j=0;j<6;j++)for(int i=0;i<72;i++)s[j][i]=ri.at(refl(roots[i],j));
  Perm id{};iota(id.begin(),id.end(),0);g.push_back(id);idx.reserve(110000);idx[key(id)]=0;len.push_back(0);parent.push_back(-1);last.push_back(-1);
  for(size_t u=0;u<g.size();u++){auto p=g[u];array<int,6>row{};for(int j=0;j<6;j++){Perm q{};for(int i=0;i<72;i++)q[i]=p[s[j][i]];auto k=key(q);auto it=idx.find(k);int v;if(it==idx.end()){v=g.size();idx[k]=v;g.push_back(q);len.push_back(len[u]+1);parent.push_back(u);last.push_back(j);}else v=it->second;row[j]=v;}R.push_back(row);}
  N=g.size();assert(N==51840);L.resize(N);dl.resize(N);dr.resize(N);low.resize(N);
  vector<int>pos;vector<char>neg(72);for(int i=0;i<72;i++){bool p=true,n=true;for(int x:roots[i]){p&=x>=0;n&=x<=0;}if(p)pos.push_back(i);neg[i]=n;}assert(pos.size()==36);
  long long nc=0;for(int u=0;u<N;u++){
   int check=0;for(int i:pos)check+=neg[g[u][i]];assert(check==len[u]);
   for(int j=0;j<6;j++){Perm q{};for(int i=0;i<72;i++)q[i]=s[j][g[u][i]];L[u][j]=idx.at(key(q));dl[u]|=(len[L[u][j]]<len[u])<<j;dr[u]|=(len[R[u][j]]<len[u])<<j;}
   auto w=word(u);vector<int>c;for(size_t j=0;j<w.size();j++){int v=0;for(size_t k=0;k<w.size();k++)if(k!=j)v=R[v][w[k]];if(len[v]+1==len[u])c.push_back(v);}sort(c.begin(),c.end());c.erase(unique(c.begin(),c.end()),c.end());low[u]=move(c);nc+=low[u].size();
  }assert(nc==459588);cerr<<"Independent 72-root permutation model, lengths and "<<nc<<" deletion covers passed\n";
  nw=(N+63)/64;down.resize((size_t)N*nw);for(int u=0;u<N;u++){auto d=&down[(size_t)u*nw];d[u/64]|=1ULL<<(u%64);for(int v:low[u]){auto b=&down[(size_t)v*nw];for(int k=0;k<nw;k++)d[k]|=b[k];}}
  cerr<<"Independent deletion Bruhat intervals ready\n";
 }
};
