#include <algorithm>
#include <array>
#include <cassert>
#include <cstdint>
#include <fstream>
#include <iostream>
#include <map>
#include <numeric>
#include <queue>
#include <string>
#include <unordered_map>
#include <vector>
using namespace std;

// HEADS ONLY: no Bruhat intervals, KL recurrence, or marked closure.
// Actual source family is U C_J V, with both endpoints supported in one
// proper maximal I. Every traversed edge strictly increases Coxeter length.
using Mat = array<int8_t,49>;
using Weight = array<int8_t,7>;
using Row = array<int32_t,7>;

struct E7 {
    static constexpr int n=7, expected=2903040;
    int A[n][n]{};
    vector<Mat> g;
    unordered_map<string,int32_t> index;
    vector<Row> R,L;
    vector<uint8_t> length,last;
    vector<int32_t> parent;
    array<int32_t,128> w0{};
    vector<Weight> weights;
    map<Weight,int> wi;
    vector<int> weight_class,weight_distance;
    string key(const Mat& m) const {return string((const char*)m.data(),49);}
    Mat right(const Mat& m,int s) const {
        Mat b=m;
        for(int j=0;j<n;j++)if(A[s][j])for(int i=0;i<n;i++)
            b[i*n+j]=m[i*n+j]-A[s][j]*m[i*n+s];
        return b;
    }
    Mat left(const Mat& m,int s) const {
        Mat b=m;
        for(int j=0;j<n;j++){
            int a=0;
            for(int k=0;k<n;k++)a+=A[s][k]*m[k*n+j];
            b[s*n+j]-=a;
        }
        return b;
    }
    vector<int> word(int u) const {
        vector<int> w;
        while(u){w.push_back(last[u]+1);u=parent[u];}
        reverse(w.begin(),w.end());
        return w;
    }
    E7(){
        for(int i=0;i<n;i++)A[i][i]=2;
        for(auto [i,j]:vector<pair<int,int>>{{0,2},{2,3},{1,3},{3,4},{4,5},{5,6}})
            A[i][j]=A[j][i]=-1;
        index.max_load_factor(0.9);index.reserve(expected);
        g.reserve(expected);R.reserve(expected);length.reserve(expected);
        parent.reserve(expected);last.reserve(expected);
        Mat e{};for(int i=0;i<n;i++)e[i*n+i]=1;
        g.push_back(e);index[key(e)]=0;length.push_back(0);parent.push_back(-1);last.push_back(255);
        for(size_t u=0;u<g.size();u++){
            Mat m=g[u];Row row{};
            for(int s=0;s<n;s++){
                Mat b=right(m,s);string k=key(b);auto it=index.find(k);int v;
                if(it==index.end()){
                    v=g.size();index.emplace(move(k),v);g.push_back(b);
                    length.push_back(length[u]+1);parent.push_back(u);last.push_back(s);
                }else v=it->second;
                row[s]=v;
            }
            R.push_back(row);
            if(u%250000==0)cerr<<"BFS processed "<<u<<", found "<<g.size()<<"\n";
        }
        assert(g.size()==expected);L.resize(expected);
        for(int u=0;u<expected;u++){
            for(int s=0;s<n;s++){
                L[u][s]=index.at(key(left(g[u],s)));
                assert(R[R[u][s]][s]==u);
                assert(abs(int(length[R[u][s]])-int(length[u]))==1);
                assert(abs(int(length[L[u][s]])-int(length[u]))==1);
            }
            if(u%500000==0)cerr<<"Left tables "<<u<<" / "<<expected<<"\n";
        }
        assert(*max_element(length.begin(),length.end())==63);
        for(int mask=0;mask<128;mask++){
            int u=0;
            for(;;){int v=u;for(int s=0;s<n;s++)if((mask>>s&1)&&length[R[u][s]]>length[u]){v=R[u][s];break;}if(v==u)break;u=v;}
            w0[mask]=u;
            for(int s=0;s<n;s++)if(mask>>s&1)assert(length[R[u][s]]<length[u]);
        }
        assert(length[w0[127]]==63);
        // Small weight orbit, in twice the simple-root coordinates.
        Weight lambda{2,3,4,6,5,4,3};weights.push_back(lambda);wi[lambda]=0;weight_distance.push_back(0);
        for(size_t u=0;u<weights.size();u++)for(int s=0;s<n;s++){
            Weight b=weights[u];int pairing=0;for(int j=0;j<n;j++)pairing+=A[s][j]*b[j];b[s]-=pairing;
            if(!wi.count(b)){int v=weights.size();wi[b]=v;weights.push_back(b);weight_distance.push_back(weight_distance[u]+1);}
        }
        assert(weights.size()==56);weight_class.assign(56,-1);
        int cl=0;
        for(int start=0;start<56;start++)if(weight_class[start]<0){
            queue<int> q;q.push(start);weight_class[start]=cl;
            while(!q.empty()){int u=q.front();q.pop();for(int s=0;s<6;s++){
                Weight b=weights[u];int pairing=0;for(int j=0;j<n;j++)pairing+=A[s][j]*b[j];b[s]-=pairing;
                int v=wi.at(b);if(weight_class[v]<0){weight_class[v]=cl;q.push(v);}
            }}cl++;
        }
        assert(cl==4);
    }
    vector<uint8_t> family(int I) const {
        vector<uint8_t> seen(expected);
        for(int J=0;J<128;J++)seen[w0[J]]=1;
        for(int u=0;u<expected;u++)if(seen[u])for(int s=0;s<n;s++)if(I>>s&1)
            for(int v:{R[u][s],L[u][s]})if(length[v]>length[u])seen[v]=1;
        return seen;
    }
};

template<class T>void binary_vector(ofstream& f,const vector<T>& a){f.write((const char*)a.data(),sizeof(T)*a.size());}

int main(int argc,char**argv){
    assert(argc==3);E7 W;
    vector<uint8_t> coverage(E7::expected),weight_index(E7::expected);
    vector<int64_t> families;
    for(int omitted=0;omitted<7;omitted++){
        auto a=W.family(127^(1<<omitted));int64_t count=0;
        for(int u=0;u<E7::expected;u++)if(a[u]){coverage[u]|=1<<omitted;count++;}
        families.push_back(count);cerr<<"E7 family omit "<<omitted+1<<": "<<count<<"\n";
    }
    vector<int64_t> weight_total(56),weight_missing(56),class_total(4),class_missing(4),missing_by_length(64);
    vector<vector<int>> samples(4);int64_t covered=0,nonopposite_missing=0;
    Weight lambda{2,3,4,6,5,4,3};
    for(int u=0;u<E7::expected;u++){
        Weight a{};for(int i=0;i<7;i++){int z=0;for(int j=0;j<7;j++)z+=W.g[u][i*7+j]*lambda[j];assert(z>=-6&&z<=6);a[i]=z;}
        int j=W.wi.at(a),cl=W.weight_class[j];weight_index[u]=j;weight_total[j]++;class_total[cl]++;
        if(coverage[u])covered++;
        else{
            weight_missing[j]++;class_missing[cl]++;missing_by_length[W.length[u]]++;
            if(samples[cl].size()<20)samples[cl].push_back(u);
            if(cl!=3)nonopposite_missing++;
        }
    }
    for(int j=0;j<56;j++)assert(weight_total[j]==51840);
    assert(class_total==vector<int64_t>({51840,1399680,1399680,51840}));
    ofstream out(argv[1]);
    out<<"{\n\"type\":\"E7 root-trivial\",\n\"weyl_order\":"<<E7::expected
       <<",\n\"scope\":\"All SAME-I source HEADS for proper maximal I and all standard J; no KL or marked closure.\",\n\"covered_count\":"<<covered
       <<",\n\"missing_count\":"<<E7::expected-covered<<",\n\"nonopposition_missing_count\":"<<nonopposite_missing
       <<",\n\"family_counts_by_omitted_node\":[";
    for(int i=0;i<7;i++){if(i)out<<",";out<<families[i];}
    out<<"],\n\"doublecoset_distribution\":[";
    for(int cl=0;cl<4;cl++){
        if(cl)out<<",";out<<"{\"class\":"<<cl<<",\"total\":"<<class_total[cl]<<",\"missing\":"<<class_missing[cl]<<",\"sample_missing_words\":[";
        for(size_t j=0;j<samples[cl].size();j++){if(j)out<<",";out<<"\"";for(int s:W.word(samples[cl][j]))out<<s;out<<"\"";}out<<"]}";
    }
    out<<"],\n\"weight_distribution\":[";
    for(int j=0;j<56;j++){
        if(j)out<<",";out<<"{\"weight_index\":"<<j<<",\"doublecoset\":"<<W.weight_class[j]<<",\"twice_simple_root_coordinates\":[";
        for(int k=0;k<7;k++){if(k)out<<",";out<<int(W.weights[j][k]);}
        out<<"],\"minimum_length\":"<<W.weight_distance[j]<<",\"total\":"<<weight_total[j]<<",\"missing\":"<<weight_missing[j]<<"}";
    }
    out<<"],\n\"missing_by_length\":[";for(int i=0;i<64;i++){if(i)out<<",";out<<missing_by_length[i];}out<<"]\n}\n";
    ofstream binary(argv[2],ios::binary);
    int32_t header[5]={0x45374844,1,7,E7::expected,56};binary.write((const char*)header,sizeof(header));
    binary_vector(binary,W.R);binary_vector(binary,W.L);binary_vector(binary,W.length);binary_vector(binary,W.parent);binary_vector(binary,W.last);
    binary.write((const char*)W.w0.data(),sizeof(W.w0));binary_vector(binary,coverage);binary_vector(binary,weight_index);
    cerr<<"FINAL E7 HEADS "<<covered<<" / "<<E7::expected<<"; missing outside opposition="<<nonopposite_missing<<"\n";
}
