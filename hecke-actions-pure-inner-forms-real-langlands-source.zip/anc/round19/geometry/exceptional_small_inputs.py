#!/usr/bin/env python3
"""Exact small E7/E8 root, weight, and central-mark data; no full W enumeration."""
from collections import Counter, deque
from itertools import product
from pathlib import Path
import json

HERE = Path(__file__).resolve().parent


class SmallExceptional:
    def __init__(self, rank):
        self.n = rank
        self.A = [[2 * int(i == j) for j in range(rank)] for i in range(rank)]
        edges = [(0, 2), (2, 3), (1, 3)] + [(i, i + 1) for i in range(3, rank - 1)]
        for i, j in edges:
            self.A[i][j] = self.A[j][i] = -1
        seen = {tuple(int(i == j) for i in range(rank)) for j in range(rank)}
        queue = deque(seen)
        while queue:
            a = queue.popleft()
            for s in range(rank):
                b = self.reflect_root(a, s)
                if b not in seen:
                    seen.add(b)
                    queue.append(b)
        self.roots = sorted(seen)
        assert len(self.roots) == {7: 126, 8: 240}[rank]
        self.ri = {a: i for i, a in enumerate(self.roots)}
        self.pos = [i for i, a in enumerate(self.roots) if all(c >= 0 for c in a)]
        self.neg = [all(c <= 0 for c in a) for a in self.roots]
        assert len(self.pos) * 2 == len(self.roots)
        self.simple = [tuple(self.ri[self.reflect_root(a, s)] for a in self.roots) for s in range(rank)]
        self.id = tuple(range(len(self.roots)))
        self.simple_root_ids = [self.ri[tuple(int(i == s) for i in range(rank))] for s in range(rank)]

    def reflect_root(self, a, s):
        b = list(a)
        b[s] -= sum(self.A[s][j] * a[j] for j in range(self.n))
        return tuple(b)

    def reflect_weight(self, a, s):
        return tuple(a[j] - a[s] * self.A[s][j] for j in range(self.n))

    def right(self, w, s):
        return tuple(w[i] for i in self.simple[s])

    def left(self, w, s):
        p = self.simple[s]
        return tuple(p[i] for i in w)

    def word_element(self, word):
        w = self.id
        for s in word:
            w = self.right(w, s - 1)
        return w

    def length(self, w):
        return sum(self.neg[w[a]] for a in self.pos)

    def descents(self, w):
        right = [s for s, a in enumerate(self.simple_root_ids) if self.neg[w[a]]]
        inverse = [0] * len(w)
        for i, a in enumerate(w):
            inverse[a] = i
        left = [s for s, a in enumerate(self.simple_root_ids) if self.neg[inverse[a]]]
        return left, right

    def central_marks(self):
        marks = [b for b in product(range(4), repeat=self.n)
                 if all(sum(a * c for a, c in zip(row, b)) % 2 == 0 for row in self.A)]
        assert len(marks) == 256
        index = {b: i for i, b in enumerate(marks)}
        two_rho = [sum(self.roots[a][j] for a in self.pos) for j in range(self.n)]
        assert [sum(a * c for a, c in zip(row, two_rho)) for row in self.A] == [2] * self.n
        tau_squared = [2 * c % 4 for c in two_rho]
        actions, white, raw_square, actual_norm = [], [], [], []
        for b in marks:
            phase = [sum(a * c for a, c in zip(row, b)) % 4 for row in self.A]
            act = []
            for s in range(self.n):
                c = list(b)
                c[s] = (c[s] - phase[s]) % 4
                act.append(index[tuple(c)])
            actions.append(act)
            white.append([p == 0 for p in phase])
            raw_square.append(tuple(2 * c % 4 for c in b))
            actual_norm.append(tuple((2 * c + z) % 4 for c, z in zip(b, tau_squared)))
        for i in range(len(marks)):
            for s in range(self.n):
                assert actions[actions[i][s]][s] == i
                assert white[i][s] == (actions[i][s] == i)
                assert actual_norm[i] == actual_norm[actions[i][s]]
                for t in range(s):
                    order = 3 if self.A[s][t] == -1 else 2
                    j = i
                    for _ in range(order):
                        j = actions[actions[j][s]][t]
                    assert j == i
        unseen, orbits = set(range(len(marks))), []
        while unseen:
            start = min(unseen)
            found, queue = {start}, deque([start])
            while queue:
                for j in actions[queue.popleft()]:
                    if j not in found:
                        found.add(j)
                        queue.append(j)
            unseen.difference_update(found)
            orbits.append(sorted(found))
        records = []
        for orbit in orbits:
            i = orbit[0]
            records.append({"size": len(orbit), "representative_phase_mod4": marks[i],
                            "raw_square_phase_mod4": raw_square[i],
                            "actual_norm_phase_mod4": actual_norm[i], "indices": orbit})
        return {"type": f"E{self.n}", "cartan_matrix": self.A,
                "root_count": len(self.roots), "two_rho_coroot_simple_coordinates": two_rho,
                "tau_squared_fundamental_phases_mod4": tau_squared,
                "raw_mark_count": len(marks), "raw_marks": marks,
                "raw_square_branch_sizes": {str(k): v for k, v in sorted(Counter(raw_square).items())},
                "actual_norm_branch_sizes": {str(k): v for k, v in sorted(Counter(actual_norm).items())},
                "orbit_sizes": [len(o) for o in orbits],
                "supported_sector_count": sum(len(o) ** 2 for o in orbits),
                "orbits": records, "simple_actions": actions, "white": white,
                "simple_action_involutions_and_braids_checked": True}

    def weight_doublecosets(self):
        start = tuple(int(i == self.n - 1) for i in range(self.n))
        words = {start: []}
        queue = deque([start])
        while queue:
            a = queue.popleft()
            for s in range(self.n):
                b = self.reflect_weight(a, s)
                if b not in words:
                    words[b] = [s + 1] + words[a]
                    queue.append(b)
        assert len(words) == {7: 56, 8: 240}[self.n]
        unseen, out = set(words), []
        while unseen:
            start = min(unseen, key=lambda a: (len(words[a]), a))
            found, queue = {start}, deque([start])
            while queue:
                a = queue.popleft()
                for s in range(self.n - 1):
                    b = self.reflect_weight(a, s)
                    if b not in found:
                        found.add(b)
                        queue.append(b)
            unseen.difference_update(found)
            w = self.word_element(words[start])
            left, right = self.descents(w)
            assert self.length(w) == len(words[start])
            assert all(s == self.n - 1 for s in left + right)
            out.append({"size": len(found), "minimal_weight": start,
                        "minimum_word": words[start], "minimum_length": len(words[start]),
                        "support": sorted(set(words[start])), "left_descents": [s + 1 for s in left],
                        "right_descents": [s + 1 for s in right]})
        out.sort(key=lambda a: a["minimum_length"])
        return {"weight_orbit_size": len(words), "doublecosets": out}


if __name__ == "__main__":
    all_marks, all_quotients = {}, {}
    original = json.loads((HERE.parent / "structure/exceptional_weight_doublecosets.json").read_text())
    for rank in (7, 8):
        W = SmallExceptional(rank)
        marks = W.central_marks()
        quotient = W.weight_doublecosets()
        old = original[f"E{rank}"]
        assert quotient["weight_orbit_size"] == old["orbit_size"]
        assert [(a["size"], a["minimum_length"]) for a in quotient["doublecosets"]] == [(a["size"], a["length"]) for a in old["doublecosets"]]
        for new, prior in zip(quotient["doublecosets"], old["doublecosets"]):
            assert W.word_element(new["minimum_word"]) == W.word_element(prior["min_word"])
            assert new["minimal_weight"] == tuple(prior["min_weight"])
        all_marks[f"E{rank}"] = marks
        all_quotients[f"E{rank}"] = quotient
        with (HERE / f"e{rank}_central_marks.txt").open("w") as stream:
            stream.write(f"{marks['raw_mark_count']} {marks['supported_sector_count']} {rank}\n")
            for action, color in zip(marks["simple_actions"], marks["white"]):
                stream.write(" ".join(map(str, action + list(map(int, color)))) + "\n")
            for orbit in marks["orbits"]:
                for a in orbit["indices"]:
                    for b in orbit["indices"]:
                        stream.write(f"{a} {b}\n")
        print(f"E{rank}: marks={marks['raw_mark_count']}, orbits={marks['orbit_sizes']}, sectors={marks['supported_sector_count']}, tau²={marks['tau_squared_fundamental_phases_mod4']}")
    (HERE / "exceptional_central_marks.json").write_text(json.dumps(all_marks, indent=2) + "\n")
    (HERE / "exceptional_small_quotients_audit.json").write_text(json.dumps(all_quotients, indent=2) + "\n")
