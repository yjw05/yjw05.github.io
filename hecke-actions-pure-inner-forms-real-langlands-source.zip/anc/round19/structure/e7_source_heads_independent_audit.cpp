#include <algorithm>
#include <array>
#include <cassert>
#include <cstdint>
#include <fstream>
#include <iostream>
#include <numeric>
#include <queue>
#include <vector>
using namespace std;
using Row=array<int32_t,7>;
template<class T> void readv(ifstream&f,vector<T>&v,size_t n){
 v.resize(n);f.read(reinterpret_cast<char*>(v.data()),sizeof(T)*n);assert(f);
}
int main(int argc,char**argv){
 assert(argc==3);ifstream f(argv[1],ios::binary);int32_t h[5];f.read((char*)h,sizeof(h));
 assert(h[0]==0x45374844&&h[1]==1&&h[2]==7&&h[3]==2903040&&h[4]==56);
 const int N=h[3];vector<Row>R,L;vector<uint8_t>len,last,original,weight;vector<int32_t>parent;
 readv(f,R,N);readv(f,L,N);readv(f,len,N);readv(f,parent,N);readv(f,last,N);
 array<int32_t,128>w0;f.read((char*)w0.data(),sizeof(w0));assert(f);
 readv(f,original,N);readv(f,weight,N);assert(f.peek()==EOF);
 int A[7][7]{};for(int i=0;i<7;i++)A[i][i]=2;
 for(auto e:vector<pair<int,int>>{{0,2},{2,3},{1,3},{3,4},{4,5},{5,6}})
  A[e.first][e.second]=A[e.second][e.first]=-1;
 assert(parent[0]==-1&&len[0]==0);
 // A transitive E7-Coxeter action on exactly |W(E7)| points is regular.
 for(int u=0;u<N;u++){
  if(u){assert(parent[u]>=0&&parent[u]<u&&last[u]<7);
   assert(R[parent[u]][last[u]]==u&&len[u]==len[parent[u]]+1);}
  for(int s=0;s<7;s++){
   int v=R[u][s];assert(v>=0&&v<N&&R[v][s]==u);
   assert(abs(int(len[v])-int(len[u]))==1);
   assert(L[u][s]>=0&&L[u][s]<N);
  }
 }
 cerr<<"All parent paths, right involutions, and exact graph distances passed.\n";
 for(int s=0;s<7;s++)for(int t=0;t<s;t++){
  int m=A[s][t]==-1?3:2;
  for(int u=0;u<N;u++){int v=u;for(int j=0;j<m;j++)v=R[R[v][s]][t];assert(v==u);}
 }
 cerr<<"Every right Coxeter braid passed; table is the regular E7 action.\n";
 // Commuting with every right generator and agreeing at 1 determines left multiplication.
 for(int s=0;s<7;s++){
  assert(L[0][s]==R[0][s]);
  for(int t=0;t<7;t++)for(int u=0;u<N;u++)
   assert(L[R[u][t]][s]==R[L[u][s]][t]);
 }
 cerr<<"All left/right commutation squares passed.\n";
 for(int mask=0;mask<128;mask++){
  int u=0;
  for(;;){int v=u;for(int s=6;s>=0;s--)if((mask>>s&1)&&len[R[u][s]]>len[u]){v=R[u][s];break;}
   if(v==u)break;u=v;}
  assert(u==w0[mask]);int d=0;
  for(int s=0;s<7;s++)if(len[R[u][s]]<len[u])d|=1<<s;
  assert(d==mask);
 }
 vector<uint8_t>coverage(N);vector<long long>counts;
 for(int omit=0;omit<7;omit++){
  vector<uint8_t>seen(N);queue<int>q;
  for(int w:w0)if(!seen[w]){seen[w]=1;q.push(w);}
  long long count=0;
  while(!q.empty()){
   int u=q.front();q.pop();count++;coverage[u]|=1<<omit;
   for(int s=0;s<7;s++)if(s!=omit)for(int v:{R[u][s],L[u][s]})
    if(len[v]>len[u]&&!seen[v]){seen[v]=1;q.push(v);}
  }
  counts.push_back(count);cerr<<"Independent queue family omit "<<omit+1<<": "<<count<<"\n";
 }
 assert(coverage==original);
 vector<long long>hist(64),missingweights(56),weighttotals(56);
 long long covered=0;int common=127,first=-1,firstno7=-1;
 auto getword=[&](int u){vector<int>w;while(u){w.push_back(last[u]+1);u=parent[u];}reverse(w.begin(),w.end());return w;};
 for(int u=0;u<N;u++){
  assert(weight[u]<56);weighttotals[weight[u]]++;
  if(coverage[u])covered++;
  else{hist[len[u]]++;missingweights[weight[u]]++;
   int d=0;for(int s=0;s<7;s++)if(len[L[u][s]]<len[u])d|=1<<s;common&=d;
   if(first<0||len[u]<len[first])first=u;
   if(!(d&64)&&(firstno7<0||len[u]<len[firstno7]))firstno7=u;}
 }
 for(auto x:weighttotals)assert(x==51840);
 assert(covered==1689999&&N-covered==1213041&&common==0);
 ofstream out(argv[2]);out<<"{\n\"status\":\"PASS\",\n\"weyl_order\":"<<N<<",\n";
 out<<"\"all_right_coxeter_relations_checked\":true,\n\"regular_action_certified_by_order_and_connectivity\":true,\n";
 out<<"\"all_left_right_commutation_squares_checked\":true,\n\"all128_parabolic_longests_reconstructed\":true,\n";
 out<<"\"seven_families_replayed_by_queue\":true,\n\"every_coverage_bit_matches\":true,\n";
 out<<"\"covered_count\":"<<covered<<",\n\"missing_count\":"<<N-covered<<",\n\"family_counts\":[";
 for(int i=0;i<7;i++){if(i)out<<",";out<<counts[i];}out<<"],\n";
 out<<"\"common_missing_left_descents\":"<<common<<",\n\"first_missing_word\":\"";
 for(int x:getword(first))out<<x;out<<"\",\n\"first_missing_without_left7_word\":\"";
 for(int x:getword(firstno7))out<<x;out<<"\",\n\"missing_by_length\":[";
 for(int i=0;i<64;i++){if(i)out<<",";out<<hist[i];}out<<"],\n\"missing_by_weight_index\":[";
 for(int i=0;i<56;i++){if(i)out<<",";out<<missingweights[i];}out<<"]\n}\n";
 cerr<<"PASS: every source-head coverage bit independently replayed.\n";
}
