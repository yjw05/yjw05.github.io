#!/usr/bin/env python3
"""Independent E7/E8 raw-mark audit via Cartan linear algebra and parity cosets."""
from collections import Counter, deque
from fractions import Fraction
from itertools import product
from pathlib import Path
import json

HERE = Path(__file__).resolve().parent
DATA = json.loads((HERE.parent / "geometry/exceptional_central_marks.json").read_text())


def solve_and_det(A):
    n = len(A)
    a = [[Fraction(x) for x in row] + [Fraction(2)] for row in A]
    det = Fraction(1)
    for i in range(n):
        p = next(j for j in range(i, n) if a[j][i])
        if p != i:
            a[p], a[i] = a[i], a[p]
            det = -det
        v = a[i][i]
        det *= v
        a[i] = [x / v for x in a[i]]
        for j in range(n):
            if i != j:
                v = a[j][i]
                a[j] = [x - v * y for x, y in zip(a[j], a[i])]
    sol = [row[-1] for row in a]
    assert all(x.denominator == 1 for x in sol)
    return [int(x) for x in sol], int(det)


results = {}
for n in (7, 8):
    edges = [(1, 3), (3, 4), (2, 4)] + [(i, i + 1) for i in range(4, n)]
    A = [[2 * int(i == j) for j in range(n)] for i in range(n)]
    for i, j in edges:
        A[i - 1][j - 1] = A[j - 1][i - 1] = -1
    rho2, det = solve_and_det(A)
    assert det == (2 if n == 7 else 1)
    kernel = [b for b in product(range(2), repeat=n)
              if all(sum(a * x for a, x in zip(row, b)) % 2 == 0 for row in A)]
    assert len(kernel) == det
    marks = sorted(tuple((p + 2 * b) % 4 for p, b in zip(parity, bits))
                   for parity in kernel for bits in product(range(2), repeat=n))
    assert len(marks) == len(set(marks)) == 256
    ix = {b: j for j, b in enumerate(marks)}
    actions, white = [], []
    for b in marks:
        colors = [sum(x * y for x, y in zip(row, b)) % 4 for row in A]
        assert set(colors) <= {0, 2}
        row = []
        for i, color in enumerate(colors):
            c = list(b)
            c[i] = (c[i] + color) % 4  # plus = minus for 0/2
            row.append(ix[tuple(c)])
        actions.append(row)
        white.append([x == 0 for x in colors])
    unseen = set(range(256))
    orbits = []
    while unseen:
        seed = min(unseen)
        q, orb = deque([seed]), {seed}
        while q:
            for nxt in actions[q.popleft()]:
                if nxt not in orb:
                    orb.add(nxt)
                    q.append(nxt)
        unseen.difference_update(orb)
        orbits.append(sorted(orb))
    tau = tuple(2 * r % 4 for r in rho2)
    actual = {}
    raw = {}
    for orb in orbits:
        b = marks[orb[0]]
        raw_norm = tuple(2 * x % 4 for x in b)
        actual_norm = tuple((2 * x + z) % 4 for x, z in zip(b, tau))
        for i in orb:
            assert tuple(2 * x % 4 for x in marks[i]) == raw_norm
            assert tuple((2 * x + z) % 4 for x, z in zip(marks[i], tau)) == actual_norm
        raw.setdefault(str(raw_norm), []).append(len(orb))
        actual.setdefault(str(actual_norm), []).append(len(orb))
    source = DATA[f"E{n}"]
    assert source["cartan_matrix"] == A
    assert source["raw_marks"] == [list(b) for b in marks]
    assert source["simple_actions"] == actions
    assert source["white"] == white
    assert source["two_rho_coroot_simple_coordinates"] == rho2
    assert source["tau_squared_fundamental_phases_mod4"] == list(tau)
    assert sorted(source["orbit_sizes"]) == sorted(map(len, orbits))
    assert {tuple(o["indices"]) for o in source["orbits"]} == {tuple(o) for o in orbits}
    assert source["supported_sector_count"] == sum(len(o) ** 2 for o in orbits)
    results[f"E{n}"] = dict(
        status="PASS", method="Cartan solve A*(2rho)=2 and parity-kernel cosets",
        cartan_determinant=det, parity_kernel=[list(b) for b in kernel],
        two_rho_coroot_coordinates=rho2, tau_squared_phase_mod4=list(tau),
        full_raw_mark_count=256, orbit_sizes=sorted(map(len, orbits)),
        supported_sector_count=sum(len(o) ** 2 for o in orbits),
        raw_square_orbits=raw, actual_norm_orbits=actual,
        every_mark_action_and_color_compared=True)
print(json.dumps(results, indent=2))
(HERE / "exceptional_mark_independent_audit.json").write_text(json.dumps(results, indent=2) + "\n")
