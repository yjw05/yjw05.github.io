// Whole-positive actual-zero closure using canonical heads, strong covers,
// and higher-mu SUPPORT GUARDS that omit Bruhat and every KL value.
// A high-gap output v must have DL(u) subset DL(v), DR(u) subset DR(v),
// the acting s as a descent, odd gap >=3. Superset zeta gives the union of
// unknown guarded outputs. An empty union plus known positive outputs
// licenses the actual white inverse. No maximum-excluded bit is used.
#define main graph_engine_entry
#include "mark_orbit_graph.cpp"
#undef main
struct Guard{
 Group&W;Marks&M;Engine&E;int k,all=127;vector<uint64_t>fast,raw;array<int,64>row{};array<int,65>begin{};vector<uint64_t>hist;uint64_t inverse_rows=0,inverse_bits=0,forward_edges=0;
 Guard(Group&w,Marks&m,Engine&e):W(w),M(m),E(e),k(m.orbit.size()){
  fast.resize(128*8*256);for(int D=0;D<128;D++)for(int b=0;b<8;b++)for(int x=1;x<256;x++){int t=__builtin_ctz(x),prev=x&(x-1),c=8*b+t;fast[((D*8+b)*256)+x]=fast[((D*8+b)*256)+prev]|(c<(int)M.P[D].cls.size()?M.P[D].cls[c]:0);}
  row.fill(-1);for(int i=0;i<k;i++)row[M.orbit[i]]=i;raw.resize(W.res.size()*k);int pos=0;for(int L=0;L<=64;L++){while(pos<(int)W.res.size()&&W.len[W.res[pos]]<L)pos++;begin[L]=pos;}
 }
 uint64_t expand(uint64_t x,int D)const{uint64_t z=0;int b=0;while(x){z|=fast[((D*8+b)*256)+(x&255)];x>>=8;b++;}return z;}
 void rebuild(int ri){int w=W.res[ri],D=W.dl[w];for(size_t i=0;i<M.P[D].cls.size();i++){uint64_t value=expand(E.zero[E.offset[ri]+i],W.dr[w]),marks=M.P[D].cls[i];while(marks){int y=__builtin_ctzll(marks);raw[(size_t)ri*k+row[y]]=value;marks&=marks-1;}}}
 uint64_t known(int w,int y)const{return W.seed[w]?M.full:raw[(size_t)W.ri[w]*k+y];}
 void forward(){for(int pass=0;;pass++){bool changed=false;fill(E.nextdirty.begin(),E.nextdirty.end(),0);for(size_t i=0;i<W.res.size();i++)if(E.dirty[i]){int w=W.res[i];for(uint64_t j=E.edgesoff[i];j<E.edgesoff[i+1];j++){auto e=E.edges[j];if(E.transfer(E.zero,w,e.v,e.mask&all,e.mask>>7)){changed=true;forward_edges++;int v=W.ri[e.v];if(v>(int)i)E.dirty[v]=1;else E.nextdirty[v]=1;}}}if(!changed)break;E.dirty.swap(E.nextdirty);}fill(E.dirty.begin(),E.dirty.end(),0);}
 uint64_t inverse_pass(int pass){
  vector<uint64_t>old=E.zero;for(size_t i=0;i<W.res.size();i++)rebuild(i);const size_t zsize=(size_t)(1<<14)*k;vector<uint64_t>bucket0(zsize),bucket1(zsize),zeta(zsize);uint64_t changed_rows=0,changed_bits=0,tested=0;
  for(int L=0;L<64;L++){
   if(L>=3){int ell=L-3;auto&bucket=(ell&1)?bucket1:bucket0;for(int ri=begin[ell];ri<begin[ell+1];ri++){int v=W.res[ri],dl=W.dl[v],dr=W.dr[v],mask=(dl<<7)|dr;auto*b=&bucket[(size_t)mask*k];for(size_t i=0;i<M.P[dl].cls.size();i++){uint64_t unknown=M.full&~expand(old[E.offset[ri]+i],dr);if(!unknown)continue;uint64_t marks=M.P[dl].cls[i];while(marks){int y=__builtin_ctzll(marks);b[row[y]]|=unknown;marks&=marks-1;}}}
    zeta=bucket;for(int bit=0;bit<14;bit++)for(int mask=0;mask<(1<<14);mask++)if(!(mask>>bit&1)){auto*a=&zeta[(size_t)mask*k];auto*b=&zeta[(size_t)(mask|(1<<bit))*k];for(int i=0;i<k;i++)a[i]|=b[i];}
   }else fill(zeta.begin(),zeta.end(),0);
   for(int ri=begin[L];ri<begin[L+1];ri++){
    int w=W.res[ri],dl=W.dl[w],dr=W.dr[w];bool already=true;for(int y=0;y<k;y++)already&=raw[(size_t)ri*k+y]==M.full;if(already)continue;
    for(int side=0;side<2;side++)for(int s=0;s<7;s++){
     int D=side?dl:dr;if(D>>s&1)continue;int reqL=dl|(side?(1<<s):0),reqR=dr|(side?0:(1<<s));auto*g=&zeta[(size_t)((reqL<<7)|reqR)*k];array<uint64_t,64>candidate{};uint64_t active=0;for(int y=0;y<k;y++){
      uint64_t white=side?(M.white[M.orbit[y]][s]?M.full:0):M.wm[1<<s];uint64_t bits=M.full&~raw[(size_t)ri*k+y]&white&~g[y];if(bits){candidate[y]=bits;active|=1ULL<<y;}}
     if(!active)continue;tested++;int head=side?W.L[w][s]:W.R[w][s];
     auto restrict_to=[&](int v){if(W.seed[v])return;uint64_t ys=active;while(ys){int y=__builtin_ctzll(ys);ys&=ys-1;candidate[y]&=known(v,y);if(!candidate[y])active&=~(1ULL<<y);}};
     restrict_to(head);for(uint64_t j=W.off[w];j<W.off[w+1]&&active;j++){int v=W.low[j];if((side?W.dl[v]:W.dr[v])>>s&1)restrict_to(v);}if(!active)continue;
     changed_rows++;uint64_t ys=active;while(ys){int y=__builtin_ctzll(ys);ys&=ys-1;int i=M.P[dl].part[M.orbit[y]];uint64_t projected=M.project(candidate[y],dr),delta=projected&~E.zero[E.offset[ri]+i];changed_bits+=__builtin_popcountll(delta);E.zero[E.offset[ri]+i]|=projected;}
     E.dirty[ri]=1;rebuild(ri);
    }
   }
  }
  inverse_rows+=changed_rows;inverse_bits+=changed_bits;cerr<<"Guard inverse pass "<<pass<<": "<<changed_rows<<" productive rows, "<<changed_bits<<" new compressed actual-zero bits; "<<tested<<" rows survive coarse guard\n";return changed_bits;
 }
 void run(const string&out,int maxpasses){
  hist.push_back(E.count_raw_unknown(E.zero));cerr<<"Guard initial raw unknown "<<hist.back()<<"\n";for(int pass=0;pass<maxpasses&&hist.back();pass++){auto b=inverse_pass(pass);forward();hist.push_back(E.count_raw_unknown(E.zero));cerr<<"Guard after actual forward closure: raw unknown "<<hist.back()<<" compressed "<<E.count_quotient_unknown(E.zero)<<"\n";if(!b)break;}
  ofstream f(out+".json");f<<"{\"scope\":\"Actual zeros only. Higher-gap support guards omit Bruhat and all mu values; no maximum-excluded state is used as zero.\",\"rank\":7,\"mark_orbit_size\":"<<k<<",\"productive_white_inverse_rows\":"<<inverse_rows<<",\"white_inverse_new_compressed_bits\":"<<inverse_bits<<",\"forward_product_edge_updates\":"<<forward_edges<<",\"raw_unknown_history\":[";for(size_t i=0;i<hist.size();i++){if(i)f<<',';f<<hist[i];}f<<"],\"remaining_compressed_unknowns\":"<<E.count_quotient_unknown(E.zero)<<",\"complete\":"<<(hist.back()?"false":"true")<<"}\n";ofstream z(out+"_zero.bin",ios::binary);z.write((char*)E.zero.data(),E.zero.size()*8);
 }
};
int main(int argc,char**argv){assert(argc==6);Group W(7);Marks M(7,argv[1],stoi(argv[2]));Engine E(W,M);E.build(true);ifstream f(string(argv[3])+"_zero.bin",ios::binary);f.read((char*)E.zero.data(),E.zero.size()*8);assert(f);fill(E.dirty.begin(),E.dirty.end(),0);Guard G(W,M,E);G.run(argv[4],stoi(argv[5]));return 0;}
