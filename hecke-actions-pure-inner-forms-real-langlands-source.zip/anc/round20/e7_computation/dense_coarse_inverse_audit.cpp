// Independent actual-zero solver: dense raw matrices, direct reflection
// transports, and direct SUBMASK enumeration for higher-mu guard union.
// No descent-orbit transfer and no superset-zeta transform in propagation.
#define DENSE_AS_LIBRARY
#include "dense_raw_audit.cpp"
struct AuditGuard{
 Group&W;Marks&M;Dense&D;int k;array<int,65>begin{};vector<uint64_t>history;uint64_t newrows=0;
 AuditGuard(Group&w,Marks&m,Dense&d):W(w),M(m),D(d),k(m.orbit.size()){int p=0;for(int L=0;L<=64;L++){while(p<(int)W.res.size()&&W.len[W.res[p]]<L)p++;begin[L]=p;}}
 void initial(const string&prefix){D.build();ifstream f(prefix+"_zero.bin",ios::binary);size_t words=0;for(int w:W.res)words+=M.P[W.dl[w]].cls.size();vector<uint64_t>bits;rd(f,bits,words);size_t j=0;for(int w:W.res){auto*out=D.ptr(w);for(int i=0;i<k;i++)out[i]=M.expand(bits[j+M.P[W.dl[w]].part[M.orbit[i]]],W.dr[w]);j+=M.P[W.dl[w]].cls.size();}fill(D.dirty.begin(),D.dirty.end(),0);}
 void forward(){for(;;){bool change=false;fill(D.next.begin(),D.next.end(),0);for(size_t i=0;i<W.res.size();i++)if(D.dirty[i]){int w=W.res[i];D.saturate(w);for(uint64_t j=D.off[i];j<D.off[i+1];j++){auto e=D.edges[j];if(D.move(w,e.v,e.mask&127,e.mask>>7)){change=true;int v=W.ri[e.v];if(v>(int)i)D.dirty[v]=1;else D.next[v]=1;}}}if(!change)break;D.dirty.swap(D.next);}fill(D.dirty.begin(),D.dirty.end(),0);}
 uint64_t pass(int pn){vector<uint64_t>snapshot=D.a;size_t sz=(1<<14)*(size_t)k;vector<uint64_t>g0(sz),g1(sz),delta(sz);vector<int>touched;vector<uint8_t>seen(1<<14);uint64_t productive=0;
  for(int L=0;L<64;L++){
   if(L>=3){int ell=L-3;auto&guard=(ell&1)?g1:g0;fill(delta.begin(),delta.end(),0);fill(seen.begin(),seen.end(),0);touched.clear();for(int ri=begin[ell];ri<begin[ell+1];ri++){int v=W.res[ri],mask=(int(W.dl[v])<<7)|W.dr[v];bool nonempty=false;auto*b=&delta[(size_t)mask*k];for(int y=0;y<k;y++){uint64_t unknown=M.full&~snapshot[(size_t)ri*k+y];b[y]|=unknown;nonempty|=unknown!=0;}if(nonempty&&!seen[mask]){seen[mask]=1;touched.push_back(mask);}}
    for(int mask:touched){auto*b=&delta[(size_t)mask*k];int sub=mask;for(;;){auto*a=&guard[(size_t)sub*k];for(int y=0;y<k;y++)a[y]|=b[y];if(sub==0)break;sub=(sub-1)&mask;}}
   }
   // For L<3 there are no high-gap outputs; g0,g1 are still zero.
   auto&guard=((L+1)&1)?g1:g0;
   for(int ri=begin[L];ri<begin[L+1];ri++){int w=W.res[ri],dl=W.dl[w],dr=W.dr[w];auto*out=D.ptr(w);bool done=true;for(int y=0;y<k;y++)done&=out[y]==M.full;if(done)continue;
    for(int side=0;side<2;side++)for(int s=0;s<7;s++){
     if((side?dl:dr)>>s&1)continue;int reqL=dl|(side?(1<<s):0),reqR=dr|(side?0:(1<<s));auto*g=&guard[(size_t)((reqL<<7)|reqR)*k];array<uint64_t,64>can{};uint64_t active=0;for(int y=0;y<k;y++){uint64_t wh=side?(M.white[M.orbit[y]][s]?M.full:0):D.white[s];can[y]=M.full&~out[y]&wh&~g[y];if(can[y])active|=1ULL<<y;}if(!active)continue;
     auto restrict=[&](int v){if(W.seed[v])return;auto*b=D.ptr(v);uint64_t ys=active;while(ys){int y=__builtin_ctzll(ys);ys&=ys-1;can[y]&=b[y];if(!can[y])active&=~(1ULL<<y);}};
     restrict(side?W.L[w][s]:W.R[w][s]);for(uint64_t j=W.off[w];j<W.off[w+1]&&active;j++){int v=W.low[j];if((side?W.dl[v]:W.dr[v])>>s&1)restrict(v);}if(!active)continue;productive++;while(active){int y=__builtin_ctzll(active);active&=active-1;out[y]|=can[y];}D.saturate(w);D.dirty[ri]=1;
    }
   }
  }
  newrows+=productive;cerr<<"Independent dense guard pass "<<pn<<": "<<productive<<" productive rows\n";return productive;
 }
 void run(const string&start,const string&out,int limit){initial(start);history.push_back(D.unknown());for(int p=0;p<limit&&history.back();p++){auto productive=pass(p);forward();history.push_back(D.unknown());cerr<<"Independent dense true unknown "<<history.back()<<"\n";if(!productive)break;}ofstream f(out+".json");f<<"{\"passed\":"<<(history.back()?"false":"true")<<",\"method\":\"Independent dense raw-mark coefficient matrices; explicit simple-reflection invariance; coarse guards constructed by direct submask enumeration, no zeta transform; genuine white inverses and positive forward products only\",\"mark_orbit_size\":"<<k<<",\"productive_white_inverse_rows\":"<<newrows<<",\"raw_unknown_history\":[";for(size_t i=0;i<history.size();i++){if(i)f<<',';f<<history[i];}f<<"],\"complete_actual_zero\":"<<(history.back()?"false":"true")<<"}\n";}
};
int main(int argc,char**argv){assert(argc==6);Group W(7);Marks M(7,argv[1],stoi(argv[2]));Dense D(W,M);AuditGuard A(W,M,D);A.run(argv[3],argv[4],stoi(argv[5]));return A.history.back()==0?0:2;}
