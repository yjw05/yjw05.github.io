// Descent-parabolic quotient of two-endpoint actual-zero and maximum graphs.
// Only guaranteed canonical heads and gap-one strong covers are used.
#include <algorithm>
#include <array>
#include <cassert>
#include <chrono>
#include <cstdint>
#include <fstream>
#include <iostream>
#include <map>
#include <numeric>
#include <string>
#include <vector>
using namespace std;
using Row=array<int32_t,7>;
template<class T> void rd(ifstream&f,vector<T>&v,size_t n){v.resize(n);f.read((char*)v.data(),sizeof(T)*n);assert(f);}
struct Group{
 int n,N;vector<Row>R,L;vector<uint8_t>len,seed,dl,dr;vector<int32_t>parent,last;
 vector<uint64_t>off;vector<int32_t>low,res,ri;
 Group(int rank):n(rank){
  if(n==7){ifstream f("round19/geometry/e7_head_tables.bin",ios::binary);int32_t h[5];f.read((char*)h,sizeof(h));assert(h[0]==0x45374844&&h[1]==1&&h[2]==7&&h[3]==2903040&&h[4]==56);N=h[3];rd(f,R,N);rd(f,L,N);rd(f,len,N);rd(f,parent,N);vector<uint8_t>ll;rd(f,ll,N);last.assign(ll.begin(),ll.end());f.seekg(128*sizeof(int32_t),ios::cur);rd(f,seed,N);vector<uint8_t>wi;rd(f,wi,N);char extra;assert(!f.get(extra));assert(*max_element(len.begin(),len.end())==63);}
  else{assert(n==6);N=51840;R.resize(N);L.resize(N);len.resize(N);seed.resize(N);parent.resize(N);last.resize(N);ifstream f("round19/root_e6_audit/root_tables.bin",ios::binary);for(int w=0;w<N;w++){int32_t a[13];f.read((char*)a,sizeof(a));assert(f);len[w]=a[0];for(int s=0;s<n;s++){R[w][s]=a[s+1];L[w][s]=a[s+7];}}ifstream si("round19/root_e6/root_e6_seed_labels.txt");int w;while(si>>w)seed[w]=1;parent[0]=-1;last[0]=-1;for(int w=1;w<N;w++)for(int s=0;s<n;s++)if(len[R[w][s]]<len[w]){parent[w]=R[w][s];last[w]=s;break;}}
  assert(is_sorted(len.begin(),len.end()));dl.resize(N);dr.resize(N);ri.assign(N,-1);for(int w=0;w<N;w++){for(int s=0;s<n;s++){dl[w]|=(len[L[w][s]]<len[w])<<s;dr[w]|=(len[R[w][s]]<len[w])<<s;}if(!seed[w]){ri[w]=res.size();res.push_back(w);}}
  off.resize(N+1);low.reserve((size_t)N*16);for(int w=1;w<N;w++){off[w]=low.size();int u=parent[w],s=last[w];assert(u<w&&len[u]+1==len[w]&&R[u][s]==w);low.push_back(u);for(uint64_t j=off[u];j<off[u+1];j++){int x=low[j],v=R[x][s];if(len[v]>len[x])low.push_back(v);}sort(low.begin()+off[w],low.end());assert(unique(low.begin()+off[w],low.end())==low.end());}off[N]=low.size();
  if(n==6)assert(low.size()==459588);cerr<<"Group "<<N<<"; residual "<<res.size()<<"; strong covers "<<low.size()<<"\n";
 }
 string word(int w){string z;while(w){z.push_back('1'+last[w]);w=parent[w];}reverse(z.begin(),z.end());return z;}
};
struct Partition{vector<uint64_t>cls;array<uint8_t,64>part{};};
struct Marks{
 int n;uint64_t full=0;vector<int>orbit;array<array<int,7>,64>act{},white{};vector<Partition>P;vector<uint64_t>wm;
 Marks(int rank,const string&path,int start):n(rank){ifstream f(path);int nm,ns,nr;f>>nm>>ns>>nr;assert(nm==64&&nr==n);for(int a=0;a<64;a++){for(int s=0;s<n;s++)f>>act[a][s];for(int s=0;s<n;s++)f>>white[a][s];}orbit.push_back(start);full|=1ULL<<start;for(size_t i=0;i<orbit.size();i++)for(int s=0;s<n;s++){int b=act[orbit[i]][s];if(!(full>>b&1)){full|=1ULL<<b;orbit.push_back(b);}}sort(orbit.begin(),orbit.end());
  P.resize(1<<n);wm.resize(1<<n);for(int D=0;D<(1<<n);D++){for(int a:orbit)for(int s=0;s<n;s++)if((D>>s&1)&&white[a][s])wm[D]|=1ULL<<a;uint64_t seen=0;for(int a:orbit)if(!(seen>>a&1)){vector<int>q{a};uint64_t cc=1ULL<<a;for(size_t i=0;i<q.size();i++)for(int s=0;s<n;s++)if(D>>s&1){int b=act[q[i]][s];if(!(cc>>b&1)){cc|=1ULL<<b;q.push_back(b);}}int k=P[D].cls.size();P[D].cls.push_back(cc);for(int b:q)P[D].part[b]=k;seen|=cc;}assert(seen==full);}
  cerr<<"Mark orbit "<<orbit.size()<<"; full mask "<<full<<"\n";
 }
 uint64_t project(uint64_t raw,int D)const{uint64_t z=0;while(raw){int a=__builtin_ctzll(raw);z|=1ULL<<P[D].part[a];raw&=raw-1;}return z;}
 uint64_t expand(uint64_t cols,int D)const{uint64_t z=0;while(cols){int a=__builtin_ctzll(cols);z|=P[D].cls[a];cols&=cols-1;}return z;}
};
struct Edge{int32_t v;uint16_t mask;};
struct Engine{
 Group&W;Marks&M;vector<uint64_t>offset;vector<uint64_t>zero,reach;vector<uint64_t>edgesoff;vector<Edge>edges;vector<uint8_t>dirty,nextdirty;
 uint64_t compressed_states=0;int all;
 Engine(Group&w,Marks&m):W(w),M(m),all((1<<w.n)-1){offset.resize(W.res.size()+1);for(size_t i=0;i<W.res.size();i++){int u=W.res[i];offset[i+1]=offset[i]+M.P[W.dl[u]].cls.size();compressed_states+=M.P[W.dl[u]].cls.size()*M.P[W.dr[u]].cls.size();}zero.resize(offset.back());dirty.resize(W.res.size());nextdirty.resize(W.res.size());cerr<<"Compressed scalar states "<<compressed_states<<"; matrix words "<<zero.size()<<"; array MB "<<zero.size()*8/1000000.0<<"\n";}
 // Project a marked edge from source partition product to target product.
 // left/right masks indicate nodes for which this canonical output is guaranteed.
 bool transfer(vector<uint64_t>&a,int src,int dst,int lm,int rm,bool source_full=false){
  if(W.seed[dst])return false;int sr=W.ri[src],tr=W.ri[dst];assert(source_full||sr>=0);int sl=W.dl[src],sd=W.dr[src],tl=W.dl[dst],td=W.dr[dst];auto&sp=M.P[sl];auto&tp=M.P[tl];uint64_t *out=&a[offset[tr]];bool changed=false;uint64_t leftwhite=M.wm[lm],rightwhite=M.wm[rm];
  for(size_t i=0;i<sp.cls.size();i++){
   uint64_t b=source_full?M.full:M.expand(a[offset[sr]+i],sd);if(!b)continue;uint64_t ordinary=M.project(b,td),special=M.project(b&rightwhite,td);
   if(!ordinary)continue;uint64_t raw=sp.cls[i];for(size_t j=0;j<tp.cls.size();j++){uint64_t meet=raw&tp.cls[j];if(!meet)continue;uint64_t add=(meet&leftwhite)?ordinary:special;uint64_t dif=add&~out[j];if(dif){out[j]|=dif;changed=true;}}
  }
  return changed;
 }
 void build(bool covers){
  edgesoff.resize(W.res.size()+1);vector<pair<int,uint16_t>>tmp;
  for(int w=0;w<W.N;w++){
   tmp.clear();for(int s=0;s<W.n;s++){if(!(W.dl[w]>>s&1))tmp.push_back({W.L[w][s],uint16_t(1<<s)});if(!(W.dr[w]>>s&1))tmp.push_back({W.R[w][s],uint16_t(1<<(s+W.n))});}
   if(covers)for(uint64_t j=W.off[w];j<W.off[w+1];j++){int v=W.low[j],lm=W.dl[v]&~W.dl[w],rm=W.dr[v]&~W.dr[w];if(lm||rm)tmp.push_back({v,uint16_t(lm|(rm<<W.n))});}
   sort(tmp.begin(),tmp.end());vector<pair<int,uint16_t>>uniq;for(auto [v,mask]:tmp){if(!uniq.empty()&&uniq.back().first==v)uniq.back().second|=mask;else uniq.push_back({v,mask});}
   if(W.seed[w]){for(auto[v,mask]:uniq)if(!W.seed[v]&&transfer(zero,w,v,mask&all,mask>>W.n,true))dirty[W.ri[v]]=1;}
   else{int k=W.ri[w];edgesoff[k]=edges.size();for(auto[v,mask]:uniq)edges.push_back({v,mask});}
  }
  edgesoff[W.res.size()]=edges.size();cerr<<"Residual guaranteed edges "<<edges.size()<<"\n";
 }
 uint64_t count_raw_unknown(const vector<uint64_t>&a){uint64_t total=0;for(size_t k=0;k<W.res.size();k++){int w=W.res[k],dl=W.dl[w],dr=W.dr[w];for(size_t i=0;i<M.P[dl].cls.size();i++)total+=(uint64_t)__builtin_popcountll(M.P[dl].cls[i])*(M.orbit.size()-__builtin_popcountll(M.expand(a[offset[k]+i],dr)));}return total;}
 uint64_t count_quotient_unknown(const vector<uint64_t>&a){uint64_t z=0;for(auto x:a)z+=__builtin_popcountll(x);return compressed_states-z;}
 vector<uint64_t> p1,p2;
 void solve(bool run_maximum=true){
  for(int pass=0;;pass++){
   bool changed=false;uint64_t processed=0;fill(nextdirty.begin(),nextdirty.end(),0);
   for(size_t k=0;k<W.res.size();k++)if(dirty[k]){processed++;int w=W.res[k];for(uint64_t j=edgesoff[k];j<edgesoff[k+1];j++){auto e=edges[j];if(transfer(zero,w,e.v,e.mask&all,e.mask>>W.n)){changed=true;int v=W.ri[e.v];if(v>(int)k)dirty[v]=1;else nextdirty[v]=1;}}}
   p1.push_back(count_raw_unknown(zero));cerr<<"Actual-zero pass "<<pass<<": raw unknown "<<p1.back()<<", quotient "<<count_quotient_unknown(zero)<<", processed "<<processed<<"\n";if(!changed)break;dirty.swap(nextdirty);
  }
  reach=zero;
  if(!run_maximum)return;
  // Reverse graph edge propagation; each sweep processes all rows. A seed
  // target is a genuine zero and supplies a reverse edge immediately.
  for(int pass=0;;pass++){
   bool changed=false;for(int k=(int)W.res.size()-1;k>=0;k--){int w=W.res[k];for(uint64_t j=edgesoff[k];j<edgesoff[k+1];j++){auto e=edges[j];changed|=transfer(reach,e.v,w,e.mask&all,e.mask>>W.n,W.seed[e.v]);}}
   p2.push_back(count_raw_unknown(reach));cerr<<"Maximum-exclusion pass "<<pass<<": raw possible "<<p2.back()<<", quotient "<<count_quotient_unknown(reach)<<"\n";if(!changed)break;
  }
 }
 void output(const string&path,bool save){
  ofstream f(path+".json");f<<"{\"rank\":"<<W.n<<",\"weyl_order\":"<<W.N<<",\"source_labels\":"<<W.N-W.res.size()<<",\"mark_orbit_size\":"<<M.orbit.size()<<",\"mark_orbit\":[";for(size_t i=0;i<M.orbit.size();i++){if(i)f<<',';f<<M.orbit[i];}f<<"],\"strong_covers\":"<<W.low.size()<<",\"compressed_scalar_states\":"<<compressed_states<<",\"matrix_words\":"<<zero.size()<<",\"guaranteed_edges\":"<<edges.size()<<",\"phase1_raw_unknown\":[";for(size_t i=0;i<p1.size();i++){if(i)f<<',';f<<p1[i];}f<<"],\"phase2_raw_possible_maxima\":[";for(size_t i=0;i<p2.size();i++){if(i)f<<',';f<<p2[i];}f<<"],\"remaining_quotient_states\":"<<count_quotient_unknown(reach)<<",\"sample_possible_maxima\":[";
  int count=0;for(size_t k=0;k<W.res.size()&&count<100;k++){int w=W.res[k],dl=W.dl[w],dr=W.dr[w];for(size_t i=0;i<M.P[dl].cls.size()&&count<100;i++){uint64_t unknown=M.full&~M.expand(reach[offset[k]+i],dr);if(unknown){if(count++)f<<',';f<<"{\"label\":"<<w<<",\"word\":\""<<W.word(w)<<"\",\"left_descent\":"<<dl<<",\"right_descent\":"<<dr<<",\"left_class\":"<<M.P[dl].cls[i]<<",\"unknown_right_marks\":"<<unknown<<"}";}}}f<<"],\"phase2_not_used_as_actual_zeros\":true}\n";
  if(save){ofstream z(path+"_zero.bin",ios::binary),r(path+"_reach.bin",ios::binary);z.write((char*)zero.data(),zero.size()*8);r.write((char*)reach.data(),reach.size()*8);}
 }
};
int main(int argc,char**argv){assert(argc==7||argc==8);int n=stoi(argv[1]);Group W(n);Marks M(n,argv[2],stoi(argv[3]));Engine E(W,M);E.build(stoi(argv[5]));E.solve(argc==7);E.output(argv[4],stoi(argv[6]));return 0;}
