"""Exact graph quotient by central translation; no categorical identification.

The phases and full actions are retained in Round XIX.  Projection factors out
the central radical in each parity branch.  All source labels are uniform in
the marks, so both zero reachability and maximum exclusion are invariant under
independent central translation in the two endpoints.
"""
from pathlib import Path
import json

base = Path(__file__).resolve().parents[2]
d = json.loads((base / 'round19/geometry/exceptional_central_marks.json').read_text())['E7']
b = [tuple(x) for x in d['raw_marks']]
index = {x:i for i,x in enumerate(b)}
A = d['cartan_matrix']
p = (0,1,0,0,1,0,1)
z = tuple(2*x for x in p)
act, white = [], []
for x in b:
    ac, wh = [], []
    for s in range(7):
        alpha = sum(A[s][j]*x[j] for j in range(7)) % 4
        assert alpha in (0,2)
        y = list(x); y[s] = (y[s]-alpha)%4
        ac.append(index[tuple(y)]); wh.append(int(alpha==0))
    act.append(ac); white.append(wh)
central = [index[tuple((x[j]+z[j])%4 for j in range(7))] for x in b]
for a in range(256):
    assert central[central[a]] == a and central[a] != a
    for s in range(7):
        assert central[act[a][s]] == act[central[a]][s]
        assert white[a][s] == white[central[a]][s]

def proj(x):
    parity = x[1]%2
    c = [(x[j]-parity*p[j])//2 for j in range(7)]
    q = 0; k=0
    for j in range(7):
        if j==1: continue
        q |= ((c[j] ^ (p[j]*c[1]))&1)<<k
        k+=1
    return parity,q

fibres={}
for a,x in enumerate(b): fibres.setdefault(proj(x),[]).append(a)
assert len(fibres)==128 and all(len(v)==2 for v in fibres.values())
for v in fibres.values(): assert central[v[0]]==v[1]
data=[]
for parity in range(2):
    qa=[]; qw=[]
    for q in range(64):
        v=fibres[parity,q]; a=v[0]
        qa.append([proj(b[act[a][s]])[1] for s in range(7)])
        qw.append(white[a])
        for aa in v:
            assert [proj(b[act[aa][s]])[1] for s in range(7)] == qa[-1]
            assert white[aa] == qw[-1]
    seen=set(); orbits=[]
    for q in range(64):
        if q in seen: continue
        orb={q}; todo=[q]
        for x in todo:
            for y in qa[x]:
                if y not in orb: orb.add(y); todo.append(y)
        seen.update(orb); orbits.append(sorted(orb))
    data.append({'parity':parity,'action':qa,'white':qw,'orbits':orbits})

assert sorted(map(len,data[0]['orbits'])) == [1,63]
assert sorted(map(len,data[1]['orbits'])) == [28,36]
for parity,x in enumerate(data):
    fn=Path(__file__).with_name(f'e7_quotient_marks_{parity}.txt')
    lines=['64 0 7']
    lines += [' '.join(map(str,a+w)) for a,w in zip(x['action'],x['white'])]
    fn.write_text('\n'.join(lines)+'\n')
out={'passed':True,'scope':'Graph quotient only; each actual norm branch retained separately.',
     'raw_mark_count':256,'quotient_count':128,'central_fibres':2,
     'projection':[list(proj(x)) for x in b],'central_translation':central,
     'branches':data,
     'sector_lift_multiplicities':{'parity0_nontrivial':2,'parity1_28':4,'parity1_36':4}}
Path(__file__).with_name('e7_mark_quotient_audit.json').write_text(json.dumps(out,indent=2)+'\n')
print('Full 256 raw marks audited. Quotient orbits:',[[len(o) for o in x['orbits']] for x in data])
