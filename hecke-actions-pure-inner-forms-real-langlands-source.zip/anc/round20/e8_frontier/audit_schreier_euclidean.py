"""Independent E8 Schreier audit in the explicit Euclidean root model.

Does not import the root-permutation implementation used by the generator.
All vectors are twice their Euclidean value, so root operations are integral.
"""
from pathlib import Path
from fractions import Fraction
from itertools import combinations,product
import hashlib,json

HERE=Path(__file__).resolve().parent
data=json.loads((HERE/'schreier_transversal.json').read_text())
n=8
simple=[(1,-1,-1,-1,-1,-1,-1,1),(2,2,0,0,0,0,0,0)]
for j in range(6):
    a=[0]*8;a[j]=-2;a[j+1]=2;simple.append(tuple(a))
assert len(simple)==8
def dot(x,y):return sum(a*b for a,b in zip(x,y))
assert all(dot(a,a)==8 for a in simple)
A=[[dot(a,b)//4 for b in simple] for a in simple]
assert {(i+1,j+1) for i in range(8) for j in range(i+1,8) if A[i][j]==-1}=={(1,3),(2,4),(3,4),(4,5),(5,6),(6,7),(7,8)}

roots=[]
for i,j in combinations(range(8),2):
    for a,b in product((-2,2),repeat=2):
        x=[0]*8;x[i]=a;x[j]=b;roots.append(tuple(x))
for x in product((-1,1),repeat=8):
    if sum(v<0 for v in x)%2==0:roots.append(tuple(x))
assert len(roots)==len(set(roots))==240 and all(dot(x,x)==8 for x in roots)
rootset=set(roots)
def reflect(x,s):
    a=simple[s];v=dot(x,a);assert v%4==0
    y=tuple(xi-(v//4)*ai for xi,ai in zip(x,a));assert y in rootset
    return y

# Exact inverse of the Euclidean simple-root basis matrix.
matrix=[[Fraction(simple[j][i]) for j in range(8)]+[Fraction(int(i==j)) for j in range(8)] for i in range(8)]
for i in range(8):
    p=next(j for j in range(i,8) if matrix[j][i]);matrix[i],matrix[p]=matrix[p],matrix[i]
    v=matrix[i][i];matrix[i]=[x/v for x in matrix[i]]
    for j in range(8):
        if j!=i:
            v=matrix[j][i];matrix[j]=[a-v*b for a,b in zip(matrix[j],matrix[i])]
inv=[r[8:] for r in matrix]
coeff={}
for x in roots:
    c=[sum(inv[i][j]*x[j] for j in range(8)) for i in range(8)]
    assert all(a.denominator==1 for a in c)
    coeff[x]=tuple(map(int,c));assert all(a>=0 for a in c) or all(a<=0 for a in c)
positive=[x for x in roots if all(a>=0 for a in coeff[x])]
assert len(positive)==120
theta=(0,0,0,0,0,0,2,2)
assert theta in roots and coeff[theta]==(2,3,4,6,5,4,3,2)
assert [dot(theta,a)//4 for a in simple]==[0]*7+[1]
assert theta==max(positive,key=lambda x:sum(coeff[x]))

def apply_word(word,x):
    for s in reversed(word):x=reflect(x,s-1)
    return x
def inverse_word(word,x):
    for s in word:x=reflect(x,s-1)
    return x
def images(word):return tuple(apply_word(word,a) for a in simple)
def apply_images(im,x):
    c=coeff[x]
    y=tuple(sum(c[j]*im[j][i] for j in range(8)) for i in range(8))
    assert y in rootset
    return y
def right(im,s):return tuple(tuple(im[j][i]-A[s][j]*im[s][i] for i in range(8)) for j in range(8))
def left(im,s):return tuple(reflect(x,s) for x in im)

words=data['words'];parents=data['parent'];last=data['last_zero_based'];T=data['right_schreier_transition']
assert len(words)==len(parents)==len(last)==len(T)==240
representatives=[images(w) for w in words]
gamma=[inverse_word(w,theta) for w in words]
assert len(set(gamma))==240 and set(gamma)==rootset
ix={g:i for i,g in enumerate(gamma)}
lengths=[]
for q,w in enumerate(words):
    im=representatives[q]
    for i in range(8):
        for j in range(8):assert dot(im[i],im[j])==dot(simple[i],simple[j])
    length=sum(all(a<=0 for a in coeff[apply_images(im,x)]) for x in positive)
    assert length==len(w);lengths.append(length)
    assert all(all(a>=0 for a in coeff[inverse_word(w,simple[i])]) for i in range(7))
    if q==0:assert w==[] and parents[q]==last[q]==-1
    else:
        p=parents[q];assert 0<=p<q and w==words[p]+[last[q]+1]
        assert right(representatives[p],last[q])==im

# Independent BFS on explicit Euclidean roots verifies minimal coset distance.
dist={theta:0};queue=[theta]
for x in queue:
    for s in range(8):
        y=reflect(x,s)
        if y not in dist:dist[y]=dist[x]+1;queue.append(y)
assert len(dist)==240
assert [dist[g] for g in gamma]==lengths
moving=fixed=0
for q in range(240):
    for s in range(8):
        t,i=T[q][s]
        assert t==ix[reflect(gamma[q],s)]
        actual=right(representatives[q],s)
        if i<0:
            assert i==-1 and t!=q and actual==representatives[t]
            assert abs(lengths[t]-lengths[q])==1;moving+=1
        else:
            assert 0<=i<7 and t==q and actual==left(representatives[q],i);fixed+=1
        assert T[t][s]==[q,i]
assert moving==912 and fixed==1008 and max(lengths)==57

# Small completely independent checks of the left-s8 recurrence.  A sample
# E7 element is a short word in nodes1..7, not a precomputed E7 label. The
# factor-normal form is maintained by the independently checked table.
def right_factor(u,q,s):
    t,i=T[q][s]
    return (u if i<0 else u+[i+1]),t
samples=[[],[1],[7],[1,3,4,2,5,6,7],[7,6,5,4,3,1,2,4,5,6,7]]
recurrence_checks=0
for u in samples:
    # Base: s8 * u, built by right multiplication along u.
    v,q=[],1
    assert words[1]==[8]
    for s in u:v,q=right_factor(v,q,s-1)
    assert images([8]+u)==images(v+words[q])
    base=(v,q)
    slabs=[base]
    for q0 in range(1,240):
        p=parents[q0];a,b=slabs[p]
        slabs.append(right_factor(a,b,last[q0]))
    for q0,(v,t) in enumerate(slabs):
        assert images([8]+u+words[q0])==images(v+words[t]);recurrence_checks+=1

N7=2903040;N8=N7*240
result={
 'passed':True,
 'method':'Explicit Euclidean E8 roots (+/-e_i+/-e_j and even half-sign vectors), exact rational simple-basis inversion, and integral reflection matrices; no import of generator root-permutation code.',
 'euclidean_roots':240,'positive_roots':120,'highest_root_simple_coordinates':list(coeff[theta]),
 'highest_root_doubled_euclidean_coordinates':list(theta),'simple_gram_matrix':A,
 'transversal_representatives':240,'every_reduced_length_checked_by_120_positive_roots':True,
 'every_left_minimality_checked_on_E7_simple_roots':True,'independent_euclidean_root_BFS_distances_match':True,
 'matrix_transition_checks':1920,'linear_basis_vectors_per_transition':8,
 'moving_coset_transitions':moving,'fixed_internal_simple_transitions':fixed,
 'maximum_transversal_length':57,'left_s8_recurrence_sample_matrix_checks':recurrence_checks,
 'E7_order':N7,'derived_E8_order':N8,
 'one_uint32_left_s8_table_bytes':4*N8,'one_uint32_left_s8_table_decimal_GB':4*N8/1e9,
 'one_uint32_left_s8_table_GiB':4*N8/(1024**3),
 'full_16_uint32_adjacency_tables_bytes':16*4*N8,
 'E7_right_left_tables_bytes':14*4*N7,
 'packed_240_by_8_transition_bytes':240*8*2,
 'left_s8_base_only_bytes':4*N7,
 'full_E8_table_built':False,'ordinary_vanishing_claimed':False,
 'source_json_sha256':hashlib.sha256((HERE/'schreier_transversal.json').read_bytes()).hexdigest(),
}
(HERE/'schreier_transversal_euclidean_audit.json').write_text(json.dumps(result,indent=2)+'\n')
print(json.dumps(result,indent=2))
