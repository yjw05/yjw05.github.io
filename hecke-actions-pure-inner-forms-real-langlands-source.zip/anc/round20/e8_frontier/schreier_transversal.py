#!/usr/bin/env python3
r"""Exact 240-state Schreier model for W(E7)\W(E8).

Checks every transition as a permutation of all 240 Euclidean/simple roots.
The resulting factor coordinates encode 696729600 E8 elements using the
existing 2903040-element E7 table and this small transition table. This is
an infrastructure result, not an E8 source or marked-vanishing certificate.
"""
from pathlib import Path
import importlib.util
import json

ROOT = Path(__file__).resolve().parents[2]
spec = importlib.util.spec_from_file_location('small', ROOT/'round19/geometry/exceptional_small_inputs.py')
mod = importlib.util.module_from_spec(spec)
spec.loader.exec_module(mod)
G = mod.SmallExceptional(8)
highest = max((G.roots[i] for i in G.pos), key=sum)
assert tuple(sum(G.A[i][j]*highest[j] for j in range(8)) for i in range(8)) == (0,0,0,0,0,0,0,1)

# q = r_q^{-1}(highest), r_q minimal in its LEFT W(E7)-coset.
weights = [highest]
idx = {highest: 0}
reps = [G.id]
words = [[]]
parents = [-1]
last = [-1]
for q in range(240):
    assert q < len(weights)
    for s in range(8):
        beta = G.reflect_root(weights[q],s)
        if beta not in idx:
            idx[beta] = len(weights)
            weights.append(beta)
            reps.append(G.right(reps[q],s))
            words.append(words[q]+[s+1])
            parents.append(q)
            last.append(s)
assert len(weights) == 240

trans = []
moving, fixed = 0, 0
for q, r in enumerate(reps):
    left, right = G.descents(r)
    assert all(i == 7 for i in left)
    assert G.length(r) == len(words[q])
    row = []
    for s in range(8):
        t = idx[G.reflect_root(weights[q],s)]
        product = G.right(r,s)
        if t != q:
            assert product == reps[t]
            assert abs(len(words[t])-len(words[q])) == 1
            row.append([t,-1])
            moving += 1
        else:
            choices = [i for i in range(7) if G.left(r,i) == product]
            assert len(choices) == 1
            row.append([q,choices[0]])
            fixed += 1
    trans.append(row)

for q in range(240):
    for s in range(8):
        t,i=trans[q][s]
        back,j=trans[t][s]
        assert back == q and j == i

result = {
    'scope':'Exact factor-coordinate infrastructure only; no E8 ordinary claim.',
    'E7_order':2903040, 'cosets':240, 'E8_order':696729600,
    'all_1920_transitions_checked_on_240_roots':True,
    'moving_coset_transitions':moving, 'fixed_coset_internal_simple_transitions':fixed,
    'maximum_transversal_length':max(map(len,words)),
    'factor_convention':'w = u r_q; encode q * 2903040 + E7_label(u)',
    'right_action':'If transition(q,s)=(q2,-1), (u,q)->(u,q2); otherwise (q,i) and (u,q)->(u*s_i,q).',
    'words':words, 'parent':parents, 'last_zero_based':last,
    'right_schreier_transition':trans,
}
dest=Path(__file__).with_suffix('.json')
dest.write_text(json.dumps(result,separators=(',',':'))+'\n')
print(json.dumps({k:v for k,v in result.items() if k not in ['words','parent','last_zero_based','right_schreier_transition']},indent=2))
