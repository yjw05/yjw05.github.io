// Independent exact replay of every finite level forest. Uses full raw mark
// actions and union-find intersections, not binary ColorParts or search code.
#define E8_RAW_AUDIT_LIBRARY
#include "audit_e8_low_terminal_certificate.cpp"
#include <unordered_map>
#include <sstream>
struct ForestUF{
 vector<uint32_t>parent;vector<uint8_t>rank,zero;
 ForestUF(size_t n):parent(n),rank(n),zero(n){for(uint32_t i=0;i<n;i++)parent[i]=i;}
 uint32_t find(uint32_t a){uint32_t r=a;while(parent[r]!=r)r=parent[r];while(parent[a]!=a){uint32_t b=parent[a];parent[a]=r;a=b;}return r;}
 void join(uint32_t a,uint32_t b){a=find(a);b=find(b);if(a==b)return;if(rank[a]<rank[b])swap(a,b);parent[b]=a;zero[a]|=zero[b];if(rank[a]==rank[b])rank[a]++;}
 void kill(uint32_t a){zero[find(a)]=1;}
};
struct Audit{
 Model&W;RawParts&P;vector<uint8_t>&source;int orbit;
 array<vector<int>,256>sink;
 array<array<bool,256>,256>nonsink{};
 Audit(Model&w,RawParts&p,vector<uint8_t>&z,int o):W(w),P(p),source(z),orbit(o){
  for(int D=0;D<256;D++)for(int a=0;a<256;a++)if(P.rep[D][a]==a){
   bool normal=false;for(int s=0;s<8;s++)if(D>>s&1)for(int j=0;j<4;j++)normal|=bool(P.classes[D][a][j]&P.whitebits[s][j]);
   nonsink[D][a]=normal;int whole=P.rep[255][a],size=0;for(auto bits:P.classes[255][whole])size+=__builtin_popcountll(bits);
   if(!normal&&size==orbit)sink[D].push_back(a);
  }
 }
 uint64_t key(uint32_t w,int a,int b){return uint64_t(w)|(uint64_t(a)<<32)|(uint64_t(b)<<40);}
 bool valid_head(uint64_t child,uint64_t head,int length){
  uint32_t w=uint32_t(child),h=uint32_t(head);if(w>=M||h>=M)return false;
  uint32_t q=w/N,u=w-q*N,hq=h/N,hu=h-hq*N;int a=uint8_t(child>>32),b=uint8_t(child>>40),aa=uint8_t(head>>32),bb=uint8_t(head>>40);
  if(W.length(w)!=length||W.length(h)!=length+1)return false;
  int D=W.left_desc(w,u,length),E=W.right_desc(u,q),d=W.left_desc(h,hu,length+1),e=W.right_desc(hu,hq);
  if(P.rep[D][a]!=a||P.rep[E][b]!=b||P.rep[d][aa]!=aa||P.rep[e][bb]!=bb)return false;
  for(int s=0;s<8;s++){
   if(!(D>>s&1)&&(s<7?q*N+W.L[u][s]:W.F[w])==h&&P.meet(D,a,d,aa,s)&&P.meet(E,b,e,bb))return true;
   if(!(E>>s&1)&&W.right(w,s)==h&&P.meet(D,a,d,aa)&&P.meet(E,b,e,bb,s))return true;
  }
  return false;
 }
 array<uint64_t,7>run(int length,const string&prefix,bool allow_residual=false){
  auto t=chrono::steady_clock::now();vector<uint64_t>nodes;nodes.reserve(20000000);
  for(int q=0;q<240;q++){
   int ul=length-W.qlen[q];if(ul<0||ul>63)continue;
   for(uint32_t u=W.cut[ul];u<W.cut[ul+1];u++){
    uint32_t w=q*N+u;if(source[w])continue;int D=W.left_desc(w,u,length),E=W.right_desc(u,q);
    for(int a:sink[D])for(int b:sink[E])nodes.push_back(key(w,a,b));
   }
  }
  unordered_map<uint64_t,uint32_t>id;id.max_load_factor(.9);id.reserve(nodes.size());for(uint32_t i=0;i<nodes.size();i++)assert(id.emplace(nodes[i],i).second);
  ForestUF uf(nodes.size());ifstream f(prefix+"_L"+to_string(length)+"_forest.bin",ios::binary);assert(f);
  uint64_t row[4],rows=0,equalities=0,sourceheads=0,ordinaryparents=0;
  while(f.read((char*)row,sizeof(row))){
   uint64_t kind=row[0],p=row[1],q=row[2],h=row[3];auto it=id.find(p);assert(it!=id.end());assert(valid_head(p,h,length));
   if(kind==0){auto jt=id.find(q);assert(jt!=id.end());assert(valid_head(q,h,length));uf.join(it->second,jt->second);equalities++;}
   else if(kind==1){assert(source[uint32_t(h)]&&q==0);uf.kill(it->second);sourceheads++;}
   else{
    assert(kind==2&&valid_head(q,h,length));uint32_t v=uint32_t(q),vq=v/N,vu=v-vq*N;int a=uint8_t(q>>32),b=uint8_t(q>>40),D=W.left_desc(v,vu,length),E=W.right_desc(vu,vq);
    assert(source[v]||nonsink[D][a]||nonsink[E][b]);uf.kill(it->second);ordinaryparents++;
   }
   rows++;
  }
  assert(f.eof()&&f.gcount()==0);
  uint64_t unresolved=0;unordered_set<uint64_t>unknown;unordered_set<uint32_t>unknown_components;
  for(uint32_t i=0;i<nodes.size();i++)if(!uf.zero[uf.find(i)]){unresolved++;unknown.insert(nodes[i]);unknown_components.insert(uf.find(i));}
  if(allow_residual){
   ifstream core(prefix+"_L"+to_string(length)+"_remaining.tsv");assert(core);string line;getline(core,line);unordered_set<uint64_t>expected;
   while(getline(core,line)){istringstream row(line);int ci,l,D,E,a,b,rawa,rawb;uint32_t w;string word;row>>ci>>w>>l>>D>>E>>a>>b>>rawa>>rawb>>word;assert(row&&l==length&&w<M&&ci>=0&&0<=a&&a<256&&0<=b&&b<256);uint32_t q=w/N,u=w-q*N;assert(D==W.left_desc(w,u,length)&&E==W.right_desc(u,q));assert(rawa==W.mark[255^a]&&rawb==W.mark[255^b]&&word==W.word(w));assert(expected.insert(key(w,a,b)).second);}
   assert(expected==unknown);
  }else assert(unresolved==0);
  cerr<<"FOREST AUDIT orbit "<<orbit<<" length "<<length<<" sinks "<<nodes.size()<<" events "<<rows<<" unresolved "<<unresolved<<" PASS elapsed "<<chrono::duration<double>(chrono::steady_clock::now()-t).count()<<" s\n";
  return{nodes.size(),rows,equalities,sourceheads,ordinaryparents,unresolved,unknown_components.size()};
 }
};
int main(int argc,char**argv){
 assert(argc>=3&&argc<=5);int orbit=stoi(argv[1]),maximum=stoi(argv[2]),minimum=argc>=4?stoi(argv[3]):0;bool partial=argc==5&&string(argv[4])=="--allow-residual";assert((orbit==120||orbit==135)&&0<=minimum&&minimum<=maximum&&maximum<=120&&(!partial||minimum==maximum));
 Model W;RawParts P;string base="round21/computation/";W.read_F(base+"e8_L8.bin");vector<uint8_t>source;{ifstream f(base+"e8_source_families.bin",ios::binary);rd(f,source,M);}
 Audit audit(W,P,source,orbit);string prefix=base+"e8_lazy_levelwise_"+to_string(orbit);string suffix=minimum==0&&maximum==120?"":"_L"+to_string(minimum)+"_"+to_string(maximum);ofstream out(base+(partial?"e8_levelwise_forest_partial_audit_":"e8_levelwise_forest_independent_audit_")+to_string(orbit)+suffix+".json");
 out<<"{\"status\":\""<<(partial?"PASS_PARTIAL_LEVEL":"PASS")<<"\",\"scope\":\"Every recorded graph relation is verified; ordinary concentration requires ordinary lower lengths and zero unresolved components\",\"prior_lengths_assumed_ordinary_below\":"<<minimum<<",\"orbit\":"<<orbit<<",\"lowest_verified_length\":"<<minimum<<",\"highest_verified_length\":"<<maximum<<",\"independent_full_raw_mark_partitions\":true,\"every_sink_target_reconstructed\":true,\"every_forest_relation_checked\":true,\"levels\":[";bool first=true;
 uint64_t states=0,events=0;
 for(int l=minimum;l<=maximum;l++){
  auto a=audit.run(l,prefix,partial);states+=a[0];events+=a[1];if(!first)out<<',';first=false;out<<"{\"length\":"<<l<<",\"sink_states\":"<<a[0]<<",\"forest_events\":"<<a[1]<<",\"equalities\":"<<a[2]<<",\"source_head_boundaries\":"<<a[3]<<",\"ordinary_predecessor_boundaries\":"<<a[4]<<",\"unresolved_states\":"<<a[5]<<",\"unresolved_equivalence_components\":"<<a[6]<<'}';out.flush();
 }
 out<<"],\"total_sink_states\":"<<states<<",\"total_forest_events\":"<<events<<"}\n";
 cerr<<"ALL FORESTS AUDIT PASS orbit "<<orbit<<" through "<<maximum<<" states "<<states<<" events "<<events<<"\n";
}
