// Independent proof verifier: raw mark union-find and bitset intersections.
// Imports only the retained group input/model, not the search/ColorParts code.
#define main primary_entry_not_called
#include "e8_source_terminal.cpp"
#undef main
#include <unordered_set>
using Bits=array<uint64_t,4>;
struct RawParts{
 array<array<int,8>,256>act{},white{};array<int,256>black{},raw_of_black{};
 array<Bits,8>whitebits{};array<array<Bits,256>,256>classes{};
 array<array<uint8_t,256>,256>rep{};
 RawParts(){
  ifstream f("round19/geometry/e8_central_marks.txt");int n,m,r;f>>n>>m>>r;assert(n==256&&m==32626&&r==8);
  for(int a=0;a<256;a++){
   for(int s=0;s<8;s++)f>>act[a][s];
   for(int s=0;s<8;s++){f>>white[a][s];black[a]|=(!white[a][s])<<s;if(white[a][s])whitebits[s][a/64]|=1ULL<<(a%64);}
   raw_of_black[black[a]]=a;
  }
  for(int D=0;D<256;D++){
   array<int,256>uf;for(int a=0;a<256;a++)uf[a]=a;
   auto root=[&](int a){while(uf[a]!=a)a=uf[a];return a;};
   for(int a=0;a<256;a++)for(int s=0;s<8;s++)if(D>>s&1){int x=root(a),y=root(act[a][s]);uf[x]=y;}
   array<int,256>least;least.fill(256);for(int a=0;a<256;a++)least[root(a)]=min(least[root(a)],black[a]);
   for(int a=0;a<256;a++){int c=least[root(a)];rep[D][black[a]]=c;classes[D][c][a/64]|=1ULL<<(a%64);}
  }
 }
 bool meet(int D,int a,int E,int b,int s=-1)const{
  for(int i=0;i<4;i++){uint64_t z=classes[D][a][i]&classes[E][b][i];if(s>=0)z&=whitebits[s][i];if(z)return true;}return false;
 }
};
#ifndef E8_RAW_AUDIT_LIBRARY
int main(){
 Model W;RawParts P;string base="round21/computation/";W.read_F(base+"e8_L8.bin");vector<uint8_t>source;
 {ifstream f(base+"e8_source_families.bin",ios::binary);rd(f,source,M);}
 unordered_set<uint64_t>proved;proved.reserve(1000000);uint64_t events=0;
 ifstream in(base+"e8_terminals_le32_head_proof.bin",ios::binary);uint64_t row[2];
 while(in.read((char*)row,sizeof(row))){
  uint64_t p=row[0],c=row[1];uint32_t w=uint32_t(p),v=uint32_t(c),q=w/N,u=w-q*N,vq=v/N,vu=v-vq*N;
  assert(w<M&&v<M);assert(source[v]||proved.count(c));
  int l=W.length(w);assert(W.length(v)==l-1);
  int D=W.left_desc(w,u,l),E=W.right_desc(u,q),d=W.left_desc(v,vu,l-1),e=W.right_desc(vu,vq);
  int a=uint8_t(p>>32),b=uint8_t(p>>40),aa=uint8_t(c>>32),bb=uint8_t(c>>40);
  assert(P.rep[D][a]==a&&P.rep[E][b]==b&&P.rep[d][aa]==aa&&P.rep[e][bb]==bb);
  bool valid=false;
  for(int s=0;s<8&&!valid;s++){
   if((D>>s&1)&&(s<7?q*N+W.L[u][s]:W.F[w])==v&&P.meet(D,a,d,aa,s)&&P.meet(E,b,e,bb))valid=true;
   if((E>>s&1)&&W.right(w,s)==v&&P.meet(D,a,d,aa)&&P.meet(E,b,e,bb,s))valid=true;
  }
  assert(valid);proved.insert(p);events++;
 }
 assert(in.eof()&&in.gcount()==0);
 ifstream targetfile(base+"e8_terminals_le32_targets.bin",ios::binary);unordered_set<uint64_t>targets;uint64_t k;
 while(targetfile.read((char*)&k,8)){assert(proved.count(k));assert(targets.insert(k).second);}assert(targetfile.eof()&&targetfile.gcount()==0);
 uint64_t count=0;
 for(int q=0;q<240;q++){
  int maxu=32-W.qlen[q];if(maxu<0)continue;
  for(uint32_t u=0;u<W.cut[min(maxu+1,64)];u++){
   uint32_t w=q*N+u;if(source[w])continue;int D=W.left_desc(w,u,W.length(w)),E=W.right_desc(u,q);
   if(W.orbit[D]!=W.orbit[E])continue;
   uint64_t state=uint64_t(w)|(uint64_t(255^D)<<32)|(uint64_t(255^E)<<40);
   assert(P.rep[D][255^D]==(255^D)&&P.rep[E][255^E]==(255^E));assert(targets.count(state));count++;
  }
 }
 assert(count==targets.size()&&count==345068);
 ofstream out(base+"e8_terminals_le32_independent_audit.json");out<<"{\"status\":\"PASS\",\"targets\":"<<count<<",\"proof_events\":"<<events<<",\"distinct_proved_states\":"<<proved.size()<<",\"independent_raw_mark_union_find\":true,\"all_target_labels_reconstructed\":true,\"all_head_events_checked\":true}\n";
 cerr<<"LOW TERMINAL CERTIFICATE AUDIT PASS targets "<<count<<" events "<<events<<" states "<<proved.size()<<"\n";
}
#endif
