"""Independent invariant-form test for E8 terminal-sector support."""
from pathlib import Path
import json
ROOT=Path(__file__).resolve().parents[2]
data=json.loads((ROOT/'round19/geometry/exceptional_central_marks.json').read_text())['E8']
edges=[(0,2),(2,3),(1,3),(3,4),(4,5),(5,6),(6,7)]
A=[[int((i,j) in edges or (j,i) in edges) for j in range(8)] for i in range(8)]
# Binary solve black=A*c, in simple-coroot coordinates c.
rows=[sum(A[i][j]<<j for j in range(8)) | (1<<(8+i)) for i in range(8)]
for j in range(8):
    p=next(i for i in range(j,8) if rows[i]>>j&1)
    rows[j],rows[p]=rows[p],rows[j]
    for i in range(8):
        if i!=j and rows[i]>>j&1:rows[i]^=rows[j]
assert [r&255 for r in rows]==[1<<i for i in range(8)]
inv=[r>>8 for r in rows]
def quadratic_c(c):
    return (c.bit_count()+sum(((c>>i)&1)*((c>>j)&1) for i,j in edges))%2
def quadratic_black(b):
    c=sum(((r&b).bit_count()%2)<<i for i,r in enumerate(inv))
    return quadratic_c(c)
linear=[i for i in range(8) if quadratic_black(1<<i)]
bilinear=[(i,j) for i in range(8) for j in range(i+1,8)
          if quadratic_black((1<<i)|(1<<j))^quadratic_black(1<<i)^quadratic_black(1<<j)]
orbit={i:o['size'] for o in data['orbits'] for i in o['indices']}
hist={1:0,120:0,135:0}
for mark,phase in enumerate(data['raw_marks']):
    c=sum((v//2)<<i for i,v in enumerate(phase))
    b=sum((not v)<<i for i,v in enumerate(data['white'][mark]))
    q=quadratic_black(b)
    assert q==quadratic_c(c)
    typ=1 if b==0 else 120 if q else 135
    assert typ==orbit[mark];hist[typ]+=1
    for s,target in enumerate(data['simple_actions'][mark]):
        newb=sum((not v)<<i for i,v in enumerate(data['white'][target]))
        assert quadratic_black(newb)==q
assert hist=={1:1,120:120,135:135}
out={'status':'PASS','binary_inverse_rows':inv,
     'quadratic_in_black_colors_linear_nodes':[i+1 for i in linear],
     'quadratic_in_black_colors_pairs':[[i+1,j+1] for i,j in bilinear],
     'orbit_sizes':hist,'all_256_marks_checked':True,'all_2048_simple_actions_checked':True,
     'scope':'Sector support invariant only; no ordinary conclusion.'}
Path(__file__).with_suffix('.json').write_text(json.dumps(out,indent=2)+'\n')
print(json.dumps(out,indent=2))
