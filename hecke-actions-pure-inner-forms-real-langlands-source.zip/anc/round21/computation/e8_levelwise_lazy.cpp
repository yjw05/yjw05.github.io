// Demand-driven complete level graph. A discovered boundary certifies every
// sink on the finite search tree; remaining edges need not be explored.
#define E8_LEVEL_LIBRARY
#include "e8_levelwise_sink_graph.cpp"
#include <cstdio>
#include <sstream>
struct LazyLevel:Level8{
 using Level8::Level8;
 array<uint64_t,9>run_lazy(int length,const string&pref,bool certificate){
  auto t=chrono::steady_clock::now();vector<uint64_t>nodes;nodes.reserve(20000000);
  for(int q=0;q<240;q++){
   int ul=length-W.qlen[q];if(ul<0||ul>63)continue;
   for(uint32_t u=W.cut[ul];u<W.cut[ul+1];u++){
    uint32_t w=q*N+u;if(source[w])continue;int D=W.left_desc(w,u,length);if(sink[D].empty())continue;int E=W.right_desc(u,q);
    for(int a:sink[D])for(int b:sink[E])nodes.push_back(key(w,a,b));
   }
  }
  unordered_map<uint64_t,uint32_t>id;id.max_load_factor(.9);id.reserve(nodes.size());for(uint32_t i=0;i<nodes.size();i++)id.emplace(nodes[i],i);
  vector<uint8_t>status(nodes.size()); // 0 unseen,1 proved,2 complete failed,3 current search.
  vector<uint32_t>queue;unordered_set<uint64_t>seenheads;seenheads.reserve(1024);
  ofstream proof;if(certificate)proof.open(pref+"_L"+to_string(length)+"_forest.bin",ios::binary);
  uint64_t events=0,heads=0,components=0,failed=0,maxsearch=0,sourcebounds=0,normalbounds=0,knownbounds=0;
  auto emit=[&](uint64_t kind,uint64_t a,uint64_t b,uint64_t h){events++;if(certificate){uint64_t row[4]={kind,a,b,h};proof.write((char*)row,sizeof(row));assert(proof);}};
  ofstream remaining;bool rem_open=false;int remcomp=0;
  for(uint32_t start=0;start<nodes.size();start++)if(!status[start]){
   components++;queue.clear();seenheads.clear();queue.push_back(start);status[start]=3;bool boundary=false;
   for(size_t at=0;at<queue.size()&&!boundary;at++){
    uint32_t origin=queue[at];uint64_t k=nodes[origin];uint32_t w=uint32_t(k),q=w/N,u=w-q*N;int a=uint8_t(k>>32),b=uint8_t(k>>40),D=W.left_desc(w,u,length),E=W.right_desc(u,q);
    for(int side=0;side<2&&!boundary;side++)for(int s=0;s<8&&!boundary;s++)if(!((side?E:D)>>s&1)&&((side?P.white[E][b]:P.white[D][a])>>s&1)){
     uint32_t h=side?W.right(w,s):(s<7?q*N+W.L[u][s]:W.F[w]);assert(W.length(h)==length+1);
     uint32_t hq=h/N,hu=h-hq*N;int d=W.left_desc(h,hu,length+1),e=W.right_desc(hu,hq);
     auto ha=project(D,a,d,side?-1:s),hb=project(E,b,e,side?s:-1);
     for(int aa:ha){if(boundary)break;for(int bb:hb){if(boundary)break;uint64_t hk=key(h,aa,bb);
      if(source[h]){emit(1,k,0,hk);sourcebounds++;boundary=true;break;}
      if(!seenheads.insert(hk).second)continue;
      heads++;
      for(int hs=0;hs<2&&!boundary;hs++)for(int tnode=0;tnode<8&&!boundary;tnode++)if(((hs?e:d)>>tnode&1)&&((hs?P.white[e][bb]:P.white[d][aa])>>tnode&1)){
       uint32_t v=hs?W.right(h,tnode):(tnode<7?hq*N+W.L[hu][tnode]:W.F[h]);assert(W.length(v)==length);
       uint32_t vq=v/N,vu=v-vq*N;int vd=W.left_desc(v,vu,length),ve=W.right_desc(vu,vq);
       auto va=project(d,aa,vd,hs?-1:tnode),vb=project(e,bb,ve,hs?tnode:-1);
       for(int aaa:va){if(boundary)break;for(int bbb:vb){if(boundary)break;uint64_t vk=key(v,aaa,bbb);
        if(source[v]||(P.white[vd][aaa]&vd)||(P.white[ve][bbb]&ve)){emit(2,k,vk,hk);normalbounds++;boundary=true;break;}
        auto where=id.find(vk);assert(where!=id.end());uint32_t child=where->second;
        if(status[child]==1){emit(0,k,vk,hk);knownbounds++;boundary=true;break;}
        assert(status[child]!=2); // A previously exhausted component has no edge out.
        if(!status[child]){emit(0,k,vk,hk);status[child]=3;queue.push_back(child);}
       }}
      }
     }}
    }
   }
   maxsearch=max(maxsearch,uint64_t(queue.size()));
   if(boundary){for(uint32_t x:queue)status[x]=1;}
   else{
    if(!rem_open){remaining.open(pref+"_L"+to_string(length)+"_remaining.tsv");remaining<<"component\tcode\tlength\tDL\tDR\tleft_black\tright_black\tleft_raw\tright_raw\tword\n";rem_open=true;}
    for(uint32_t x:queue){status[x]=2;failed++;uint64_t k=nodes[x];uint32_t w=uint32_t(k),q=w/N,u=w-q*N;int a=uint8_t(k>>32),b=uint8_t(k>>40);remaining<<remcomp<<'\t'<<w<<'\t'<<length<<'\t'<<int(W.left_desc(w,u,length))<<'\t'<<int(W.right_desc(u,q))<<'\t'<<a<<'\t'<<b<<'\t'<<W.mark[255^a]<<'\t'<<W.mark[255^b]<<'\t'<<W.word(w)<<'\n';}
    remcomp++;
   }
  }
  cerr<<"LAZY orbit "<<orbit<<" length "<<length<<" states "<<nodes.size()<<" examinedheads "<<heads<<" remaining "<<failed<<" components "<<remcomp<<" maxsearch "<<maxsearch<<" events "<<events<<" elapsed "<<chrono::duration<double>(chrono::steady_clock::now()-t).count()<<" s\n";
  return{nodes.size(),heads,failed,uint64_t(remcomp),maxsearch,events,sourcebounds,normalbounds,knownbounds};
 }
};
int main(int argc,char**argv){
 assert(argc>=3&&argc<=6);int orbit=stoi(argv[1]),maxlen=stoi(argv[2]),minlen=0;bool certificate=false,keep_going=false;
 for(int i=3;i<argc;i++){string arg=argv[i];if(arg=="--certificate")certificate=true;else if(arg=="--continue-conditional")keep_going=true;else minlen=stoi(arg);}
 assert((orbit==120||orbit==135)&&0<=minlen&&minlen<=maxlen&&maxlen<=120);
 Model W;ColorParts P;string base="round21/computation/";W.read_F(base+"e8_L8.bin");vector<uint8_t>source;{ifstream f(base+"e8_source_families.bin",ios::binary);rd(f,source,M);}
 LazyLevel solver(W,P,source,orbit);string pref=base+"e8_lazy_levelwise_"+to_string(orbit),path=pref+(minlen?"_L"+to_string(minlen)+"_"+to_string(maxlen):"")+".json";vector<string>records;
 for(int l=minlen;l<=maxlen;l++){
  auto a=solver.run_lazy(l,pref,certificate);ostringstream row;row<<"{\"length\":"<<l<<",\"sink_states\":"<<a[0]<<",\"heads_examined\":"<<a[1]<<",\"remaining_states\":"<<a[2]<<",\"remaining_components\":"<<a[3]<<",\"maximum_search_nodes\":"<<a[4]<<",\"forest_events\":"<<a[5]<<",\"source_head_boundaries\":"<<a[6]<<",\"ordinary_predecessor_boundaries\":"<<a[7]<<",\"previously_proved_boundaries\":"<<a[8]<<'}';records.push_back(row.str());
  {ofstream out(path+".tmp");out<<"{\"orbit\":"<<orbit<<",\"scope\":\"Each level graph is conditional on ordinary lower lengths; global induction requires every earlier obstruction resolved\",\"certificate\":"<<(certificate?"true":"false")<<",\"continue_past_unresolved\":"<<(keep_going?"true":"false")<<",\"prior_lengths_assumed_ordinary_below\":"<<minlen<<",\"requested_range\":["<<minlen<<','<<maxlen<<"],\"completed_range\":["<<minlen<<','<<l<<"],\"levels\":[";for(size_t i=0;i<records.size();i++){if(i)out<<',';out<<records[i];}out<<"]}\n";assert(out);}
  assert(rename((path+".tmp").c_str(),path.c_str())==0);
  if(a[2]&&!keep_going)break;
 }
}
