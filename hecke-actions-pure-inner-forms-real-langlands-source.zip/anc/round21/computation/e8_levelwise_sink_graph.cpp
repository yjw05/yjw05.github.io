// Whole-positive-complex induction by length, with sink vertices only.
// At level L every lower canonical term of Cs Bw has length<L, hence is
// ordinary by induction. Shared transported heads identify zero predicates.
#define E8_HEAD_SEARCH_LIBRARY
#include "e8_terminal_head_search.cpp"
#include <unordered_map>
struct UF8{
 vector<uint32_t>p;vector<uint8_t>zero,rank;
 UF8(size_t n):p(n),zero(n),rank(n){for(size_t i=0;i<n;i++)p[i]=i;}
 uint32_t find(uint32_t a){while(p[a]!=a){p[a]=p[p[a]];a=p[a];}return a;}
 void join(uint32_t a,uint32_t b){a=find(a);b=find(b);if(a==b)return;if(rank[a]<rank[b])swap(a,b);p[b]=a;zero[a]|=zero[b];if(rank[a]==rank[b])rank[a]++;}
 void kill(uint32_t a){zero[find(a)]=1;}
};
struct Level8{
 Model&W;ColorParts&P;vector<uint8_t>&source;int orbit;
 array<vector<uint8_t>,256>sink;
 Level8(Model&w,ColorParts&p,vector<uint8_t>&z,int o):W(w),P(p),source(z),orbit(o){
  for(int D=0;D<256;D++)for(int a=0;a<256;a++)if(P.rep[D][a]==a&&W.orbit[255^a]==orbit&&!(P.white[D][a]&D))sink[D].push_back(a);
 }
 uint64_t key(uint32_t w,int a,int b)const{return uint64_t(w)|(uint64_t(a)<<32)|(uint64_t(b)<<40);}
 vector<uint8_t>project(int D,int a,int d,int s=-1){
  array<bool,256>seen{};vector<uint8_t>out;
  for(int x:P.members[D][a])if(s<0||!(x>>s&1)){int y=P.rep[d][x];if(!seen[y]){seen[y]=true;out.push_back(y);}}
  return out;
 }
 array<uint64_t,8>run(int length,const string&pref){
  auto t=chrono::steady_clock::now();vector<uint64_t>nodes;unordered_map<uint64_t,uint32_t>id;
  for(int q=0;q<240;q++){
   int ul=length-W.qlen[q];if(ul<0||ul>63)continue;
   for(uint32_t u=W.cut[ul];u<W.cut[ul+1];u++){
    uint32_t w=q*N+u;if(source[w])continue;int D=W.left_desc(w,u,length);if(sink[D].empty())continue;int E=W.right_desc(u,q);
    for(int a:sink[D])for(int b:sink[E]){uint64_t k=key(w,a,b);id[k]=nodes.size();nodes.push_back(k);}
   }
  }
  UF8 uf(nodes.size());unordered_map<uint64_t,uint32_t>heads;uint64_t edges=0,sourceBoundary=0,nonsinkBoundary=0;
  for(uint32_t j=0;j<nodes.size();j++){
   auto k=nodes[j];uint32_t w=uint32_t(k),q=w/N,u=w-q*N;int a=uint8_t(k>>32),b=uint8_t(k>>40),D=W.left_desc(w,u,length),E=W.right_desc(u,q);
   for(int side=0;side<2;side++)for(int s=0;s<8;s++)if(!((side?E:D)>>s&1)){
    if(!((side?P.white[E][b]:P.white[D][a])>>s&1))continue;
    uint32_t h=side?W.right(w,s):(s<7?q*N+W.L[u][s]:W.F[w]);assert(W.length(h)==length+1);
    if(source[h]){uf.kill(j);sourceBoundary++;continue;}
    uint32_t hq=h/N,hu=h-hq*N;int d=W.left_desc(h,hu,length+1),e=W.right_desc(hu,hq);
    auto aa=project(D,a,d,side?-1:s),bb=project(E,b,e,side?s:-1);
    for(int c:aa)for(int f:bb){auto[where,inserted]=heads.emplace(key(h,c,f),j);if(!inserted)uf.join(j,where->second);edges++;}
   }
  }
  for(auto[hk,origin]:heads){
   if(uf.zero[uf.find(origin)])continue;
   uint32_t h=uint32_t(hk),q=h/N,u=h-q*N;int a=uint8_t(hk>>32),b=uint8_t(hk>>40),D=W.left_desc(h,u,length+1),E=W.right_desc(u,q);
   for(int side=0;side<2;side++)for(int s=0;s<8;s++)if((side?E:D)>>s&1){
    if(!((side?P.white[E][b]:P.white[D][a])>>s&1))continue;
    uint32_t v=side?W.right(h,s):(s<7?q*N+W.L[u][s]:W.F[h]);assert(W.length(v)==length);
    if(source[v]){uf.kill(origin);nonsinkBoundary++;continue;}
    uint32_t vq=v/N,vu=v-vq*N;int d=W.left_desc(v,vu,length),e=W.right_desc(vu,vq);
    auto aa=project(D,a,d,side?-1:s),bb=project(E,b,e,side?s:-1);
    for(int c:aa)for(int f:bb){
     if((P.white[d][c]&d)||(P.white[e][f]&e)){uf.kill(origin);nonsinkBoundary++;}
     else{auto pos=id.find(key(v,c,f));assert(pos!=id.end());uf.join(origin,pos->second);}
    }
   }
  }
  map<uint32_t,vector<uint32_t>>comps;uint64_t remain=0;
  for(uint32_t i=0;i<nodes.size();i++)if(!uf.zero[uf.find(i)]){comps[uf.find(i)].push_back(i);remain++;}
  uint64_t largest=0;for(auto&[_,c]:comps)largest=max(largest,uint64_t(c.size()));
  if(remain){
   ofstream f(pref+"_L"+to_string(length)+"_remaining.tsv");f<<"component\tcode\tlength\tDL\tDR\tleft_black\tright_black\tleft_raw\tright_raw\tword\n";int ci=0;
   for(auto&[_,c]:comps){for(int i:c){uint64_t k=nodes[i];uint32_t w=uint32_t(k),q=w/N,u=w-q*N;int a=uint8_t(k>>32),b=uint8_t(k>>40);f<<ci<<'\t'<<w<<'\t'<<length<<'\t'<<int(W.left_desc(w,u,length))<<'\t'<<int(W.right_desc(u,q))<<'\t'<<a<<'\t'<<b<<'\t'<<W.mark[255^a]<<'\t'<<W.mark[255^b]<<'\t'<<W.word(w)<<'\n';}ci++;}
  }
  cerr<<"LEVEL orbit "<<orbit<<" length "<<length<<" sinks "<<nodes.size()<<" heads "<<heads.size()<<" remaining "<<remain<<" components "<<comps.size()<<" elapsed "<<chrono::duration<double>(chrono::steady_clock::now()-t).count()<<" s\n";
  return{nodes.size(),heads.size(),edges,remain,comps.size(),largest,sourceBoundary,nonsinkBoundary};
 }
};
#ifndef E8_LEVEL_LIBRARY
int main(int argc,char**argv){
 assert(argc==3);int orbit=stoi(argv[1]),maxlen=stoi(argv[2]);assert(orbit==120||orbit==135);
 Model W;ColorParts P;string base="round21/computation/";W.read_F(base+"e8_L8.bin");vector<uint8_t>source;{ifstream f(base+"e8_source_families.bin",ios::binary);rd(f,source,M);}
 Level8 solver(W,P,source,orbit);string pref=base+"e8_levelwise_"+to_string(orbit);ofstream out(pref+".json");
 out<<"{\"orbit\":"<<orbit<<",\"scope\":\"Whole-positive-complex induction by length; stop at first unresolved sink component\",\"levels\":[";bool first=true;
 for(int l=0;l<=maxlen;l++){
  auto a=solver.run(l,pref);if(!first)out<<',';first=false;out<<"{\"length\":"<<l<<",\"sink_states\":"<<a[0]<<",\"head_states\":"<<a[1]<<",\"head_incidences\":"<<a[2]<<",\"remaining_states\":"<<a[3]<<",\"remaining_components\":"<<a[4]<<",\"largest_remaining_component\":"<<a[5]<<",\"source_head_boundaries\":"<<a[6]<<",\"ordinary_predecessor_boundaries\":"<<a[7]<<'}';out.flush();if(a[3])break;
 }
 out<<"]}\n";
}
#endif
