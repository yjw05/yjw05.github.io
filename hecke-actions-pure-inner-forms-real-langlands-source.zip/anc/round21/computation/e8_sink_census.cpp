#define E8_HEAD_SEARCH_LIBRARY
#include "e8_terminal_head_search.cpp"
int main(){
 Model W;ColorParts P;string base="round21/computation/";W.read_F(base+"e8_L8.bin");vector<uint8_t>source;
 {ifstream f(base+"e8_source_families.bin",ios::binary);rd(f,source,M);}
 array<bool,256>ind{};array<array<int,3>,256>cnt{};
 array<vector<int>,256>sinkrep;array<int,8>adj{};
 for(auto[i,j]:vector<pair<int,int>>{{0,2},{2,3},{1,3},{3,4},{4,5},{5,6},{6,7}}){adj[i]|=1<<j;adj[j]|=1<<i;}
 ofstream part(base+"e8_sink_mark_partitions.json");part<<"{\"partitions\":[";bool first=true;
 for(int D=0;D<256;D++){
  ind[D]=true;for(int s=0;s<8;s++)if((D>>s&1)&&(adj[s]&D))ind[D]=false;if(!ind[D])continue;
  for(int b=0;b<256;b++)if((b&D)==D&&P.rep[D][b]==b){
   int o=W.orbit[255^b],oi=o==1?0:o==120?1:2;cnt[D][oi]++;sinkrep[D].push_back(b);
   assert(P.members[D][b].size()==(1u<<__builtin_popcount((unsigned)D)));
  }
  int size=__builtin_popcount((unsigned)D);int expect120[]={120,28,6,1,0},expect135[]={135,36,10,3,1};
  assert(size<=4&&cnt[D][1]==expect120[size]&&cnt[D][2]==expect135[size]);assert(cnt[D][0]==int(D==0));
  if(!first)part<<',';first=false;part<<"{\"D\":"<<D<<",\"size\":"<<size<<",\"classes_1_120_135\":["<<cnt[D][0]<<','<<cnt[D][1]<<','<<cnt[D][2]<<"],\"black_representatives\":[";
  for(size_t j=0;j<sinkrep[D].size();j++){if(j)part<<',';part<<sinkrep[D][j];}part<<"]}";
 }
 part<<"]}\n";
 uint64_t labels=0,reslabels=0,states=0,resstates=0;array<uint64_t,3>orb{},resorb{};
 array<uint64_t,121>bylen{},labelslen{};array<uint64_t,5>bycl{};array<uint64_t,25>sizes{},labelssizes{};
 array<uint64_t,65536>pairs{};auto t=chrono::steady_clock::now();
 ofstream sample(base+"e8_sink_samples.tsv");sample<<"code\tlength\tDL\tDR\tcompressed_sink_states\tword\n";array<int,121>sampled{};
 for(int q=0;q<240;q++){
  for(uint32_t u=0;u<N;u++){
   if(!ind[W.dl[u]])continue; // Necessary, allowing the eighth descent later.
   uint32_t w=q*N+u;int l=W.qlen[q]+W.len[u],D=W.left_desc(w,u,l);if(!ind[D])continue;
   int E=W.right_desc(u,q);if(!ind[E])continue;
   uint64_t n=0;for(int i=0;i<3;i++){uint64_t z=uint64_t(cnt[D][i])*cnt[E][i];orb[i]+=z;n+=z;}
   if(!n)continue;labels++;states+=n;
   if(source[w])continue;
   reslabels++;resstates+=n;bylen[l]+=n;labelslen[l]++;bycl[W.qcl[q]]+=n;
   int size=__builtin_popcount((unsigned)D)*5+__builtin_popcount((unsigned)E);sizes[size]+=n;labelssizes[size]++;pairs[D*256+E]++;
   for(int i=0;i<3;i++)resorb[i]+=uint64_t(cnt[D][i])*cnt[E][i];
   if(sampled[l]<5){sampled[l]++;sample<<w<<'\t'<<l<<'\t'<<D<<'\t'<<E<<'\t'<<n<<'\t'<<W.word(w)<<'\n';}
  }
  if(q%40==0||q==239)cerr<<"sink census q "<<q<<" labels "<<reslabels<<" states "<<resstates<<" elapsed "<<chrono::duration<double>(chrono::steady_clock::now()-t).count()<<" s\n";
 }
 ofstream ps(base+"e8_sink_descent_pairs.tsv");ps<<"DL\tDR\tresidual_labels\tstates_per_label\n";for(int D=0;D<256;D++)for(int E=0;E<256;E++)if(pairs[D*256+E])ps<<D<<'\t'<<E<<'\t'<<pairs[D*256+E]<<'\t'<<cnt[D][1]*cnt[E][1]+cnt[D][2]*cnt[E][2]<<'\n';
 ofstream out(base+"e8_sink_census.json");out<<"{\n\"scope\":\"Exact black-independent-descent sink census; no new sink zeros claimed\",\n\"all_sink_labels\":"<<labels<<",\n\"residual_sink_labels\":"<<reslabels<<",\n\"all_compressed_sink_states\":"<<states<<",\n\"residual_compressed_sink_states\":"<<resstates<<",\n\"all_sink_states_by_orbits_1_120_135\":";arr(out,orb.data(),3);out<<",\n\"residual_sink_states_by_orbits_1_120_135\":";arr(out,resorb.data(),3);
 out<<",\n\"residual_sink_states_by_length\":";arr(out,bylen.data(),121);out<<",\n\"residual_sink_labels_by_length\":";arr(out,labelslen.data(),121);out<<",\n\"residual_sink_states_by_doublecoset\":";arr(out,bycl.data(),5);out<<",\n\"residual_sink_states_by_descent_sizes_5_by_5\":";arr(out,sizes.data(),25);out<<",\n\"residual_sink_labels_by_descent_sizes_5_by_5\":";arr(out,labelssizes.data(),25);out<<",\n\"elapsed_seconds\":"<<chrono::duration<double>(chrono::steady_clock::now()-t).count()<<"\n}\n";
 cerr<<"SINK CENSUS FINAL residual labels "<<reslabels<<" states "<<resstates<<"\n";
}
