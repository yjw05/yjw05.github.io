// Independent upward-scatter source replay. Shared audited group model;
// opposite propagation direction and independent quadratic mark support.
#define main primary_entry_not_called
#include "e8_source_terminal.cpp"
#undef main
int main(){
 Model W;string base="round21/computation/";W.read_F(base+"e8_L8.bin");W.parabolics();
 vector<uint8_t>expected,actual(M);{ifstream f(base+"e8_source_families.bin",ios::binary);rd(f,expected,M);char x;assert(!f.get(x));}
 for(int J=0;J<256;J++)actual[W.w0[J]]=255;
 auto t=chrono::steady_clock::now();uint64_t examined=0;
 for(int l=0;l<=120;l++){
  for(int q=0;q<240;q++){
   int ul=l-W.qlen[q];if(ul<0||ul>63)continue;uint32_t qb=q*N;
   for(uint32_t u=W.cut[ul];u<W.cut[ul+1];u++){
    uint32_t w=qb+u;assert(actual[w]==expected[w]);examined++;uint8_t a=actual[w];if(!a)continue;
    for(int s=0;s<7;s++)if(!(W.dl[u]>>s&1))actual[qb+W.L[u][s]]|=a&uint8_t(~(1<<s));
    uint32_t left8=W.F[w];if(W.length(left8)>l)actual[left8]|=a&127;
    for(int s=0;s<8;s++){
     int i=W.qi[q][s];bool ascent=i<0?W.qlen[W.qt[q][s]]>W.qlen[q]:!(W.dr[u]>>i&1);
     if(ascent)actual[W.right(w,s)]|=a&uint8_t(~(1<<s));
    }
   }
  }
  if(l%10==0||l==120)cerr<<"audit length "<<l<<" checked "<<examined<<" elapsed "<<chrono::duration<double>(chrono::steady_clock::now()-t).count()<<" s\n";
 }
 assert(examined==M&&actual==expected);
 // Reconstruct support from the E8 root-lattice quadratic form, not mark orbits.
 int adj[8][8]{};for(auto [i,j]:vector<pair<int,int>>{{0,2},{2,3},{1,3},{3,4},{4,5},{5,6},{6,7}})adj[i][j]=adj[j][i]=1;
 uint16_t rows[8];for(int i=0;i<8;i++){rows[i]=1<<(8+i);for(int j=0;j<8;j++)rows[i]|=adj[i][j]<<j;}
 for(int j=0;j<8;j++){int p=j;while(!(rows[p]>>j&1))p++;assert(p<8);swap(rows[p],rows[j]);for(int i=0;i<8;i++)if(i!=j&&(rows[i]>>j&1))rows[i]^=rows[j];}
 array<int,256>orbit{};for(int D=0;D<256;D++){
  int b=255^D,c=0;for(int i=0;i<8;i++)c|=(__builtin_popcount((rows[i]>>8)&b)&1)<<i;
  int v=__builtin_popcount(c);for(int i=0;i<8;i++)for(int j=0;j<i;j++)v+=adj[i][j]*((c>>i)&1)*((c>>j)&1);
  orbit[D]=b==0?1:(v&1)?120:135;assert(orbit[D]==W.orbit[D]);
 }
 uint64_t terminal=0,residual=0;array<uint64_t,3>orbterm{},orbres{};
 for(int q=0;q<240;q++)for(uint32_t u=0;u<N;u++){
  uint32_t w=q*N+u;int l=W.qlen[q]+W.len[u];int ld=W.dl[u]|((W.length(W.F[w])<l)<<7),rd=0;
  for(int s=0;s<8;s++){uint32_t v=W.right(w,s);rd|=(W.length(v)<l)<<s;}
  if(orbit[ld]!=orbit[rd])continue;
  int oi=orbit[ld]==1?0:orbit[ld]==120?1:2;
  terminal++;orbterm[oi]++;if(!actual[w]){residual++;orbres[oi]++;}
 }
 ofstream f(base+"e8_source_terminal_independent_audit.json");
 f<<"{\n\"status\":\"PASS\",\n\"all_source_family_bytes_compared\":"<<M<<",\n\"independent_source_algorithm\":\"Ascending-length upward scatter, compared with lower-predecessor gather\",\n\"independent_mark_support\":\"Root-lattice quadratic form and binary Cartan inversion\",\n\"supported_terminal_labels\":"<<terminal<<",\n\"residual_supported_terminal_labels\":"<<residual<<",\n\"terminal_by_mark_orbits_1_120_135\":";arr(f,orbterm.data(),3);f<<",\n\"residual_terminal_by_mark_orbits_1_120_135\":";arr(f,orbres.data(),3);f<<",\n\"elapsed_seconds\":"<<chrono::duration<double>(chrono::steady_clock::now()-t).count()<<"\n}\n";
 cerr<<"AUDIT PASS source bytes "<<M<<" terminals "<<terminal<<" residual "<<residual<<"\n";
}
