// Exact all-E8 same-I source-head and descent-matching terminal census.
// No KL coefficient, higher Bruhat relation, or ordinary propagation is used.
#include <algorithm>
#include <array>
#include <cassert>
#include <chrono>
#include <cstdint>
#include <fstream>
#include <iostream>
#include <map>
#include <string>
#include <vector>
using namespace std;
using Row=array<uint32_t,7>;
constexpr uint32_t N=2903040, Q=240, M=N*Q;
template<class T>void rd(ifstream&f,vector<T>&v,size_t n){v.resize(n);f.read((char*)v.data(),n*sizeof(T));assert(f);}
struct Model{
 vector<Row>R,L; vector<uint8_t>len,last,dl,dr;vector<int32_t>parent;
 array<uint32_t,65>cut{};array<int,240>qlen{},qp{},qa{},qneg{},qcl{};
 array<array<int,8>,240>qt{},qi{};
 array<int,256>mark{},orbit{};array<uint32_t,256>w0{};
 vector<uint32_t>F,comp7;
 Model(){
  ifstream f("round19/geometry/e7_head_tables.bin",ios::binary);int32_t h[5];f.read((char*)h,sizeof(h));
  assert(h[0]==0x45374844&&h[1]==1&&h[2]==7&&h[3]==N&&h[4]==56);
  rd(f,R,N);rd(f,L,N);rd(f,len,N);rd(f,parent,N);rd(f,last,N);
  assert(is_sorted(len.begin(),len.end())&&len.back()==63);dl.resize(N);dr.resize(N);
  for(uint32_t u=0;u<N;u++)for(int s=0;s<7;s++){
   dl[u]|=(len[L[u][s]]<len[u])<<s;dr[u]|=(len[R[u][s]]<len[u])<<s;
  }
  for(int l=0;l<65;l++)cut[l]=lower_bound(len.begin(),len.end(),l)-len.begin();
  ifstream small("round21/computation/e8_factor_small.txt");int a,b,c;small>>a>>b>>c;assert(a==240&&b==8&&c==256);
  for(int q=0;q<240;q++){
   small>>qlen[q]>>qp[q]>>qa[q]>>qneg[q]>>qcl[q];
   for(int s=0;s<8;s++)small>>qt[q][s]>>qi[q][s];
   assert(q==0||qp[q]<q);assert(qlen[q]+qlen[qneg[q]]==57||qneg[q]>q);
  }
  for(int D=0;D<256;D++){small>>a>>mark[D]>>orbit[D];assert(a==D);}
  assert(small);for(int q=0;q<240;q++)assert(qlen[q]+qlen[qneg[q]]==57&&qneg[qneg[q]]==q);
  comp7.resize(N);comp7[0]=N-1;assert(len[N-1]==63);
  for(uint32_t u=1;u<N;u++)comp7[u]=R[comp7[parent[u]]][last[u]];
  for(uint32_t u=0;u<N;u++)assert(comp7[comp7[u]]==u&&len[comp7[u]]+len[u]==63);
 }
 inline uint32_t right(uint32_t w,int s)const{
  uint32_t q=w/N,u=w-q*N;int i=qi[q][s];
  return i<0?qt[q][s]*N+u:q*N+R[u][i];
 }
 inline int length(uint32_t w)const{uint32_t q=w/N;return qlen[q]+len[w-q*N];}
 inline uint8_t right_desc(uint32_t u,int q)const{
  uint8_t z=0;for(int s=0;s<8;s++){int i=qi[q][s];z|=(i<0?(qlen[qt[q][s]]<qlen[q]):bool(dr[u]>>i&1))<<s;}return z;
 }
 inline uint8_t left_desc(uint32_t w,uint32_t u,int l)const{return dl[u]|((length(F[w])<l)<<7);}
 inline uint32_t complement(uint32_t u,int q)const{return qneg[q]*N+comp7[u];}
 string word(uint32_t w)const{
  uint32_t q=w/N,u=w-q*N;string a,b;
  while(u){a.push_back('1'+last[u]);u=parent[u];}reverse(a.begin(),a.end());
  while(q){b.push_back('1'+qa[q]);q=qp[q];}reverse(b.begin(),b.end());return a+b;
 }
 void make_F(int slabs,const string&path){
  auto t=chrono::steady_clock::now();F.resize((size_t)slabs*N);F[0]=N;
  for(uint32_t u=1;u<N;u++)F[u]=right(F[parent[u]],last[u]);
  for(int q=1;q<slabs;q++){
   uint32_t*dst=F.data()+(size_t)q*N;const uint32_t*src=F.data()+(size_t)qp[q]*N;int s=qa[q];
   for(uint32_t u=0;u<N;u++)dst[u]=right(src[u],s);
   if(q%20==0||q+1==slabs)cerr<<"L8 slabs "<<q+1<<" / "<<slabs<<" elapsed "<<chrono::duration<double>(chrono::steady_clock::now()-t).count()<<" s\n";
  }
  if(slabs==240){
   for(uint32_t w=0;w<M;w++){assert(F[F[w]]==w);assert(abs(length(F[w])-length(w))==1);}
   cerr<<"L8 full involution and all length differences checked\n";
  }
  ofstream out(path,ios::binary);out.write((char*)F.data(),F.size()*sizeof(uint32_t));assert(out);
 }
 void read_F(const string&path){ifstream f(path,ios::binary);rd(f,F,M);char x;assert(!f.get(x));}
 void parabolics(){
  for(int J=0;J<256;J++){
   uint32_t w=0;for(;;){uint32_t next=w;for(int s=0;s<8;s++)if(J>>s&1){uint32_t v=right(w,s);if(length(v)>length(w)){next=v;break;}}if(next==w)break;w=next;}
   w0[J]=w;uint32_t q=w/N,u=w-q*N;assert(left_desc(w,u,length(w))==J&&right_desc(u,q)==J);
  }
  assert(length(w0[255])==120);
 }
};
struct Stats{
 uint64_t total=0,covered=0,term=0,resid=0,comp_source=0,nearmax=0;
 array<uint64_t,8>families{};array<uint64_t,121>bylen{},term_len{};
 array<uint64_t,5>cltotal{},clres{},clterm{};
 array<uint64_t,256*256>pairs{},res_pairs{};
 array<uint64_t,256>maskcounts{};array<uint64_t,3>orbit_term{},orbit_res{};
};
void arr(ostream&o,const uint64_t*a,int n){o<<'[';for(int i=0;i<n;i++){if(i)o<<',';o<<a[i];}o<<']';}
int main(int argc,char**argv){
 assert(argc>=2);string mode=argv[1];Model W;const string base="round21/computation/";
 if(mode=="build_l8"){assert(argc==3);int slabs=stoi(argv[2]);W.make_F(slabs,base+(slabs==240?"e8_L8.bin":"e8_L8_benchmark.bin"));return 0;}
 assert(mode=="source");W.read_F(base+"e8_L8.bin");W.parabolics();vector<uint8_t>source(M);
 for(int J=0;J<256;J++)source[W.w0[J]]=255;
 auto started=chrono::steady_clock::now();Stats st;
 for(int l=0;l<=120;l++){
  uint64_t covered_before=st.covered, count=0;
  for(int q=0;q<240;q++){
   int ul=l-W.qlen[q];if(ul<0||ul>63)continue;uint32_t qb=q*N;
   for(uint32_t u=W.cut[ul];u<W.cut[ul+1];u++){
    uint32_t w=qb+u;uint8_t ld=W.left_desc(w,u,l),rd=W.right_desc(u,q),a=source[w];
    // Gather only lower-length same-I left/right weak predecessors.
    if(a!=255){
     uint32_t bits=ld&127;while(bits&&a!=255){int s=__builtin_ctz(bits);bits&=bits-1;a|=source[qb+W.L[u][s]]&uint8_t(~(1<<s));}
     if((ld&128)&&a!=255)a|=source[W.F[w]]&127;
     bits=rd;while(bits&&a!=255){int s=__builtin_ctz(bits);bits&=bits-1;a|=source[W.right(w,s)]&uint8_t(~(1<<s));}
     source[w]=a;
    }
    st.total++;count++;st.maskcounts[a]++;st.cltotal[W.qcl[q]]++;
    if(a){st.covered++;for(int s=0;s<8;s++)st.families[s]+=a>>s&1;}
    else{st.bylen[l]++;st.clres[W.qcl[q]]++;}
    bool supported=W.orbit[ld]==W.orbit[rd];
    if(supported){
     int oi=W.orbit[ld]==1?0:W.orbit[ld]==120?1:2;st.term++;st.orbit_term[oi]++;st.pairs[ld*256+rd]++;
     if(!a){st.resid++;st.orbit_res[oi]++;st.res_pairs[ld*256+rd]++;st.term_len[l]++;st.clterm[W.qcl[q]]++;st.nearmax+=__builtin_popcount(ld)==7||__builtin_popcount(rd)==7;}
    }
   }
  }
  cerr<<"length "<<l<<" elements "<<count<<" source "<<st.covered-covered_before<<" residual_term_total "<<st.resid<<" elapsed "<<chrono::duration<double>(chrono::steady_clock::now()-started).count()<<" s\n";
 }
 assert(st.total==M);ofstream so(base+"e8_source_families.bin",ios::binary);so.write((char*)source.data(),source.size());assert(so);so.close();
 ofstream samples(base+"e8_residual_terminal_samples.tsv");samples<<"code\tlength\tcoset\tdoublecoset\tleft_descent\tright_descent\torbit\tcomplement_source\tword\n";
 array<int,256*256>sampled{};uint64_t complement_source_all=0,residual_both=0;
 for(int q=0;q<240;q++)for(uint32_t u=0;u<N;u++){
  uint32_t w=q*N+u;if(source[w])continue;bool c=source[W.complement(u,q)];complement_source_all+=c;
  int l=W.qlen[q]+W.len[u],ld=W.left_desc(w,u,l),rd=W.right_desc(u,q);if(W.orbit[ld]!=W.orbit[rd])continue;
  st.comp_source+=c;residual_both+=!c;int p=ld*256+rd;
  if(sampled[p]<3){samples<<w<<'\t'<<l<<'\t'<<q<<'\t'<<W.qcl[q]<<'\t'<<ld<<'\t'<<rd<<'\t'<<W.orbit[ld]<<'\t'<<c<<'\t'<<W.word(w)<<'\n';sampled[p]++;}
 }
 ofstream pairs(base+"e8_descent_pair_census.tsv");pairs<<"left_descent\tright_descent\torbit\tterminal_labels\tresidual_terminal_labels\n";
 for(int a=0;a<256;a++)for(int b=0;b<256;b++){int p=a*256+b;if(st.pairs[p])pairs<<a<<'\t'<<b<<'\t'<<W.orbit[a]<<'\t'<<st.pairs[p]<<'\t'<<st.res_pairs[p]<<'\n';}
 ofstream out(base+"e8_source_terminal_census.json");
 out<<"{\n\"scope\":\"Exact all-E8 same-I source heads and supported descent-matching terminal census; no additional ordinary deduction.\",\n\"weyl_order\":"<<M<<",\n\"source_labels\":"<<st.covered<<",\n\"residual_labels\":"<<M-st.covered<<",\n\"source_family_counts\":";arr(out,st.families.data(),8);
 out<<",\n\"supported_terminal_labels\":"<<st.term<<",\n\"residual_supported_terminal_labels\":"<<st.resid<<",\n\"terminal_by_mark_orbits_1_120_135\":";arr(out,st.orbit_term.data(),3);
 out<<",\n\"residual_terminal_by_mark_orbits_1_120_135\":";arr(out,st.orbit_res.data(),3);
 out<<",\n\"residual_labels_with_source_complement\":"<<complement_source_all<<",\n\"residual_terminals_with_source_complement\":"<<st.comp_source<<",\n\"residual_terminals_with_residual_complement\":"<<residual_both<<",\n\"residual_terminals_with_seven_descents_on_either_side\":"<<st.nearmax;
 out<<",\n\"doublecoset_totals\":";arr(out,st.cltotal.data(),5);out<<",\n\"doublecoset_residual_labels\":";arr(out,st.clres.data(),5);out<<",\n\"doublecoset_residual_terminals\":";arr(out,st.clterm.data(),5);
 out<<",\n\"residual_labels_by_length\":";arr(out,st.bylen.data(),121);out<<",\n\"residual_terminals_by_length\":";arr(out,st.term_len.data(),121);
 out<<",\n\"source_family_mask_counts\":";arr(out,st.maskcounts.data(),256);out<<",\n\"elapsed_seconds\":"<<chrono::duration<double>(chrono::steady_clock::now()-started).count()<<"\n}\n";
 cerr<<"FINAL source "<<st.covered<<" / "<<M<<" residual supported terminal "<<st.resid<<"\n";
 return 0;
}
