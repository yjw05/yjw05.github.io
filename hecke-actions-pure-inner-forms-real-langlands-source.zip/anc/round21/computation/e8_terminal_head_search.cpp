// Bounded backward search for ACTUAL ordinary terminal coefficients.
// Quotients black descent transports at fixed w, then uses white positive
// head arrows to strictly lower labels. Unknown budget exits prove nothing.
#define main primary_entry_not_called
#include "e8_source_terminal.cpp"
#undef main
#include <unordered_set>
struct ColorParts{
 array<array<uint8_t,8>,256>act{};
 array<array<uint8_t,256>,256>rep{},white{};
 array<array<vector<uint8_t>,256>,256>members;
 ColorParts(){
  array<int,8>adj{};for(auto[i,j]:vector<pair<int,int>>{{0,2},{2,3},{1,3},{3,4},{4,5},{5,6},{6,7}}){adj[i]|=1<<j;adj[j]|=1<<i;}
  for(int b=0;b<256;b++)for(int s=0;s<8;s++)act[b][s]=b^((b>>s&1)?adj[s]:0);
  for(int D=0;D<256;D++){
   array<bool,256>seen{};
   for(int b=0;b<256;b++)if(!seen[b]){
    vector<uint8_t>todo{uint8_t(b)};seen[b]=true;
    for(size_t k=0;k<todo.size();k++)for(int s=0;s<8;s++)if(D>>s&1){int c=act[todo[k]][s];if(!seen[c]){seen[c]=true;todo.push_back(c);}}
    for(int c:todo){rep[D][c]=b;white[D][b]|=uint8_t(~c);}
    members[D][b]=move(todo);
   }
  }
 }
};
struct Search{
 Model&W;ColorParts&P;vector<uint8_t>&source;
 unordered_set<uint64_t>yes,no;uint64_t calls=0,budget_exits=0;
 ofstream*proof=nullptr;uint64_t proof_events=0;
 static constexpr size_t maxcache=3000000;
 Search(Model&w,ColorParts&p,vector<uint8_t>&s):W(w),P(p),source(s){yes.reserve(1000000);no.reserve(1000000);}
 uint64_t key(uint32_t w,int a,int b)const{return uint64_t(w)|(uint64_t(a)<<32)|(uint64_t(b)<<40);}
 void remember(uint64_t state,uint64_t child){
  if(yes.size()<maxcache)yes.insert(state);
  if(proof){uint64_t row[2]={state,child};proof->write((char*)row,sizeof(row));assert(*proof);proof_events++;}
 }
 int solve(uint32_t w,int a,int b,int&budget){
  if(source[w])return 1;
  uint32_t q=w/N,u=w-q*N;int l=W.qlen[q]+W.len[u],D=W.left_desc(w,u,l),E=W.right_desc(u,q);
  a=P.rep[D][a];b=P.rep[E][b];uint64_t state=key(w,a,b);
  if(yes.count(state))return 1;
  if(no.count(state))return 0;
  if(budget<=0){budget_exits++;return -1;}budget--;calls++;
  int lm=P.white[D][a]&D,rm=P.white[E][b]&E;
  vector<pair<uint32_t,int>>steps;
  for(int s=0;s<8;s++){
   if(lm>>s&1){uint32_t v=s<7?q*N+W.L[u][s]:W.F[w];if(source[v]){
    uint32_t vq=v/N,vu=v-vq*N;int d=W.left_desc(v,vu,l-1),e=W.right_desc(vu,vq),aa=a;
    for(int c:P.members[D][a])if(!(c>>s&1)){aa=c;break;}
    remember(state,key(v,P.rep[d][aa],P.rep[e][b]));return 1;
   }steps.push_back({v,s});}
   if(rm>>s&1){uint32_t v=W.right(w,s);if(source[v]){
    uint32_t vq=v/N,vu=v-vq*N;int d=W.left_desc(v,vu,l-1),e=W.right_desc(vu,vq),bb=b;
    for(int c:P.members[E][b])if(!(c>>s&1)){bb=c;break;}
    remember(state,key(v,P.rep[d][a],P.rep[e][bb]));return 1;
   }steps.push_back({v,s+8});}
  }
  vector<uint64_t>children;
  for(auto[v,side]:steps){
   int s=side%8;uint32_t vq=v/N,vu=v-vq*N;int d=W.left_desc(v,vu,l-1),e=W.right_desc(vu,vq);
   array<bool,256>as{},bs{};vector<int>av,bv;
   for(int aa:P.members[D][a])if(side>=8||!(aa>>s&1)){int c=P.rep[d][aa];if(!as[c]){as[c]=true;av.push_back(c);}}
   for(int bb:P.members[E][b])if(side<8||!(bb>>s&1)){int c=P.rep[e][bb];if(!bs[c]){bs[c]=true;bv.push_back(c);}}
   for(int aa:av)for(int bb:bv)children.push_back(key(v,aa,bb));
  }
  sort(children.begin(),children.end());children.erase(unique(children.begin(),children.end()),children.end());
  bool unknown=false;
  // Known successful children first; this also avoids spending bounded budget.
  for(uint64_t c:children)if(yes.count(c)){remember(state,c);return 1;}
  for(uint64_t c:children){
   int result=solve(uint32_t(c),uint8_t(c>>32),uint8_t(c>>40),budget);
   if(result==1){remember(state,c);return 1;}
   unknown|=result<0;if(budget<=0){unknown=true;break;}
  }
  if(!unknown&&no.size()<maxcache)no.insert(state);
  return unknown?-1:0;
 }
};
#ifndef E8_HEAD_SEARCH_LIBRARY
int main(int argc,char**argv){
 assert(argc==4);int maxlen=stoi(argv[1]),budget_per=stoi(argv[2]);uint64_t max_targets=stoull(argv[3]);
 Model W;ColorParts P;string base="round21/computation/";W.read_F(base+"e8_L8.bin");vector<uint8_t>source,unknown;
 {ifstream f(base+"e8_source_families.bin",ios::binary);rd(f,source,M);}
 {ifstream f(base+"e8_white_terminal_unknown.bin",ios::binary);rd(f,unknown,(M+7)/8);}
 Search S(W,P,source);uint64_t targets=0,proved=0,exhausted=0,cutoff=0;array<uint64_t,121>pr{},ex{},cu{};
 ofstream examples(base+"e8_head_search_examples.tsv");examples<<"code\tlength\tresult\tused_budget\tword\n";
 auto t=chrono::steady_clock::now();
 for(int l=0;l<=maxlen&&targets<max_targets;l++){
  for(int q=0;q<240&&targets<max_targets;q++){
   int ul=l-W.qlen[q];if(ul<0||ul>63)continue;
   for(uint32_t u=W.cut[ul];u<W.cut[ul+1]&&targets<max_targets;u++){
    uint32_t w=q*N+u;if(!(unknown[w>>3]>>(w&7)&1))continue;targets++;
    int D=W.left_desc(w,u,l),E=W.right_desc(u,q),budget=budget_per;
    int r=S.solve(w,255^D,255^E,budget);if(r==1){proved++;pr[l]++;}else if(r==0){exhausted++;ex[l]++;}else{cutoff++;cu[l]++;}
    if(targets<=200||(r!=1&&exhausted+cutoff<=200))examples<<w<<'\t'<<l<<'\t'<<r<<'\t'<<budget_per-budget<<'\t'<<W.word(w)<<'\n';
   }
  }
  if(pr[l]+ex[l]+cu[l])cerr<<"head search length "<<l<<" targets "<<targets<<" proved "<<proved<<" exhausted "<<exhausted<<" cutoff "<<cutoff<<" cache "<<S.yes.size()<<'/'<<S.no.size()<<" calls "<<S.calls<<" elapsed "<<chrono::duration<double>(chrono::steady_clock::now()-t).count()<<" s\n";
 }
 ofstream out(base+"e8_terminal_head_search.json");out<<"{\n\"scope\":\"Bounded actual-zero search by black descent equivalence and white positive heads only; failed/budget-limited searches are NOT nonvanishing claims\",\n\"maximum_target_length\":"<<maxlen<<",\n\"budget_per_target\":"<<budget_per<<",\n\"target_limit\":"<<max_targets<<",\n\"targets_examined\":"<<targets<<",\n\"additional_terminals_proved_zero\":"<<proved<<",\n\"complete_head_search_no_path\":"<<exhausted<<",\n\"budget_cutoff\":"<<cutoff<<",\n\"proved_by_length\":";arr(out,pr.data(),121);out<<",\n\"exhausted_by_length\":";arr(out,ex.data(),121);out<<",\n\"cutoff_by_length\":";arr(out,cu.data(),121);out<<",\n\"successful_cached_states\":"<<S.yes.size()<<",\n\"exhausted_cached_states\":"<<S.no.size()<<",\n\"calls\":"<<S.calls<<",\n\"elapsed_seconds\":"<<chrono::duration<double>(chrono::steady_clock::now()-t).count()<<"\n}\n";
 if(max_targets<=100){
  vector<uint64_t>states(S.no.begin(),S.no.end());sort(states.begin(),states.end());
  ofstream dag(base+"e8_first_terminal_head_failure_dag.json");dag<<"{\"scope\":\"Complete backward white-head/descent orbit graph for exhaustive failures; no nonvanishing conclusion\",\"states\":[";
  for(size_t k=0;k<states.size();k++){
   uint64_t key=states[k];uint32_t w=uint32_t(key),q=w/N,u=w-q*N;int a=uint8_t(key>>32),b=uint8_t(key>>40),l=W.length(w),D=W.left_desc(w,u,l),E=W.right_desc(u,q);
   assert(P.rep[D][a]==a&&P.rep[E][b]==b);if(k)dag<<',';
   dag<<"{\"key\":"<<key<<",\"code\":"<<w<<",\"length\":"<<l<<",\"word\":\""<<W.word(w)<<"\",\"DL\":"<<D<<",\"DR\":"<<E<<",\"left_black\":"<<a<<",\"right_black\":"<<b<<",\"left_raw_index\":"<<W.mark[255^a]<<",\"right_raw_index\":"<<W.mark[255^b]<<",\"orbit\":"<<W.orbit[255^a]<<",\"children\":[";
   map<uint64_t,array<int,4>>children;
   for(int side=0;side<2;side++)for(int s=0;s<8;s++)if((side?E:D)>>s&1){
    uint32_t v=side?W.right(w,s):(s<7?q*N+W.L[u][s]:W.F[w]);uint32_t vq=v/N,vu=v-vq*N;int d=W.left_desc(v,vu,l-1),e=W.right_desc(vu,vq);
    for(int aa:P.members[D][a])for(int bb:P.members[E][b])if(!((side?bb:aa)>>s&1)){
     uint64_t child=S.key(v,P.rep[d][aa],P.rep[e][bb]);children.emplace(child,array<int,4>{side,s+1,aa,bb});
    }
   }
   bool first=true;for(auto[child,wit]:children){assert(S.no.count(child));if(!first)dag<<',';first=false;dag<<"{\"key\":"<<child<<",\"side\":\""<<(wit[0]?"R":"L")<<"\",\"simple\":"<<wit[1]<<",\"left_black_before_head\":"<<wit[2]<<",\"right_black_before_head\":"<<wit[3]<<'}';}dag<<"]}";
  }
  dag<<"]}\n";
 }
}
#endif
