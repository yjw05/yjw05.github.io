"""Extract the small unanchored L64 equality tree and a word dictionary.

This does not resolve the core. Its equality relations are conditional only
on the already verified lower-length ordinary theorem.
"""
from pathlib import Path
import csv
import hashlib
import json
import mmap
import struct

ROOT=Path(__file__).resolve().parents[2]
HERE=Path(__file__).resolve().parent
rows=list(csv.DictReader((HERE/'e8_lazy_levelwise_135_L64_remaining.tsv').open(),delimiter='\t'))
core={int(r['code'])|(int(r['left_black'])<<32)|(int(r['right_black'])<<40) for r in rows}
assert len(core)==len(rows)==35419
edges=[];codes={k&0xffffffff for k in core}
with (HERE/'e8_lazy_levelwise_135_L64_forest.bin').open('rb') as f:
    data=mmap.mmap(f.fileno(),0,access=mmap.ACCESS_READ)
    for kind,a,b,h in struct.iter_unpack('<QQQQ',data):
        if a not in core:continue
        assert kind==0 and b in core
        edges.append((kind,a,b,h));codes.add(h&0xffffffff)
    data.close()
assert len(edges)==len(core)-1
dest=HERE/'e8_L64_core_forest.bin'
with dest.open('wb') as f:
    for row in edges:f.write(struct.pack('<QQQQ',*row))
sch=json.loads((ROOT/'round20/e8_frontier/schreier_transversal.json').read_text())
N=2903040
with (ROOT/'round19/geometry/e7_head_tables.bin').open('rb') as f:
    data=mmap.mmap(f.fileno(),0,access=mmap.ACCESS_READ)
    def word(code):
        q,u=divmod(code,N);letters=[]
        while u:
            letters.append(data[20+61*N+u]+1)
            u=struct.unpack_from('<i',data,20+57*N+4*u)[0]
        return ''.join(map(str,letters[::-1]+sch['words'][q]))
    words={str(c):word(c) for c in sorted(codes)}
    data.close()
for r in rows:assert words[r['code']]==r['word']
(HERE/'e8_L64_core_words.json').write_text(json.dumps(words,separators=(',',':'))+'\n')
with (HERE/'e8_L64_core_words.txt').open('w') as f:
    f.write(f'{len(words)}\n')
    for c,w in words.items():f.write(f'{c} {w}\n')
with (HERE/'e8_L64_core_keys.bin').open('wb') as f:
    for k in sorted(core):f.write(struct.pack('<Q',k))
out={'scope':'Conditional equality component, not an ordinary-vanishing certificate by itself.',
     'length':64,'states':len(core),'equality_edges':len(edges),'word_dictionary_elements':len(words),
     'core_forest_bytes':dest.stat().st_size,'core_forest_sha256':hashlib.sha256(dest.read_bytes()).hexdigest()}
(HERE/'e8_L64_core_extraction.json').write_text(json.dumps(out,indent=2)+'\n')
print(json.dumps(out,indent=2))
