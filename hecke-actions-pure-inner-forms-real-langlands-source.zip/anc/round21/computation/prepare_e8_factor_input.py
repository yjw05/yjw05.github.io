"""Prepare small, exact E8 Schreier and mark input; no large enumeration."""
from pathlib import Path
import importlib.util
import json

ROOT=Path(__file__).resolve().parents[2]
src=json.loads((ROOT/'round20/e8_frontier/schreier_transversal.json').read_text())
marks=json.loads((ROOT/'round19/geometry/exceptional_central_marks.json').read_text())['E8']
spec=importlib.util.spec_from_file_location('small',ROOT/'round19/geometry/exceptional_small_inputs.py')
small=importlib.util.module_from_spec(spec);spec.loader.exec_module(small)
G=small.SmallExceptional(8)
theta=max((G.roots[i] for i in G.pos),key=sum)
weights=[]
for word in src['words']:
    a=theta
    for s in word:a=G.reflect_root(a,s-1)
    weights.append(a)
assert len(set(weights))==240
index={a:i for i,a in enumerate(weights)}
neg=[index[tuple(-x for x in a)] for a in weights]
classes=[-1]*240
cl=0
for q in range(240):
    if classes[q]>=0:continue
    todo=[q];classes[q]=cl
    for p in todo:
        for s in range(7):
            t=src['right_schreier_transition'][p][s][0]
            if classes[t]<0:classes[t]=cl;todo.append(t)
    cl+=1
assert cl==5
assert [classes.count(i) for i in range(5)]==[1,56,126,56,1]
white_to_mark=[-1]*256
orbit=[-1]*256
for o in marks['orbits']:
    for y in o['indices']:orbit[y]=o['size']
for y,col in enumerate(marks['white']):
    mask=sum(int(v)<<s for s,v in enumerate(col))
    assert white_to_mark[mask]<0
    white_to_mark[mask]=y
assert min(white_to_mark)>=0
dest=Path(__file__).with_name('e8_factor_small.txt')
with dest.open('w') as out:
    out.write('240 8 256\n')
    for q,word in enumerate(src['words']):
        row=[len(word),src['parent'][q],src['last_zero_based'][q],neg[q],classes[q]]
        for t,i in src['right_schreier_transition'][q]:row.extend([t,i])
        out.write(' '.join(map(str,row))+'\n')
    for mask,y in enumerate(white_to_mark):out.write(f'{mask} {y} {orbit[y]}\n')
print(json.dumps({'file':str(dest),'cosets':240,'color_patterns':256,'doublecoset_sizes':[classes.count(i) for i in range(5)]}))
