"""Exact independent root verification of the small E8/E7 factor model.

This validates every right Schreier transition on all 240 roots. It does
not use the generated 696-million-entry L8 table or source masks.
"""
from pathlib import Path
import importlib.util
import json

ROOT = Path(__file__).resolve().parents[2]
HERE = Path(__file__).resolve().parent
spec = importlib.util.spec_from_file_location("small_roots", ROOT / "round19/geometry/exceptional_small_inputs.py")
small = importlib.util.module_from_spec(spec)
spec.loader.exec_module(small)
G = small.SmallExceptional(8)
sch = json.loads((ROOT / "round20/e8_frontier/schreier_transversal.json").read_text())
words = sch["words"]
assert len(words) == 240
perms = [G.word_element(w) for w in words]
assert len(set(perms)) == 240
theta = max((G.roots[i] for i in G.pos), key=sum)
ti = G.ri[theta]

# A left E7 coset is distinguished by r_q^{-1}(theta).  The stabilizer of
# theta is the Weyl group on nodes1..7; all eight simple roots are retained.
coset_labels = []
for q, (word, p) in enumerate(zip(words, perms)):
    assert G.length(p) == len(word)
    dl, _ = G.descents(p)
    assert not (set(dl) & set(range(7)))
    inv = [0]*240
    for i, j in enumerate(p):
        inv[j] = i
    coset_labels.append(inv[ti])
    if q:
        parent, last = sch["parent"][q], sch["last_zero_based"][q]
        assert parent < q and G.right(perms[parent], last) == p
        assert len(word) == len(words[parent])+1
assert len(set(coset_labels)) == 240
for s in range(7):
    assert G.reflect_root(theta, s) == theta
assert G.reflect_root(theta, 7) != theta
transitions = 0
for q, p in enumerate(perms):
    for s, (t, i) in enumerate(sch["right_schreier_transition"][q]):
        expected = G.right(p, s)
        if i < 0:
            actual = perms[t]
        else:
            assert t == q and 0 <= i < 7
            actual = G.left(p, i)
        assert expected == actual
        transitions += 1
assert words[0] == [] and words[1] == [8]
out = {"status": "PASS", "root_count": len(G.roots), "minimal_left_cosets": len(words),
       "all_right_transitions_verified_on_all_roots": transitions,
       "cosets_distinguished_by_inverse_highest_root": True,
       "left_minimality_checked": True, "parent_words_checked": True,
       "E7_simple_generators_fix_highest_root": True,
       "scope": "Exact small factor model; the retained E7 Cayley table is a separate audited input."}
(HERE / "e8_schreier_model_independent_audit.json").write_text(json.dumps(out, indent=2)+"\n")
print(json.dumps(out, indent=2))
