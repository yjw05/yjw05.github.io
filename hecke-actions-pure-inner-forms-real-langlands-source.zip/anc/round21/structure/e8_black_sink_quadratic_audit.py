"""Independent root-lattice quadratic audit of black descent-mark classes."""
from pathlib import Path
import itertools,json,collections
ROOT=Path(__file__).resolve().parents[2]
n=8;edges=[(0,2),(2,3),(1,3),(3,4),(4,5),(5,6),(6,7)]
neighbors=[0]*n
for i,j in edges:neighbors[i]|=1<<j;neighbors[j]|=1<<i

def Q(x):return (x.bit_count()+sum(((x>>i)&1)*((x>>j)&1) for i,j in edges))%2

def B(x,y):return Q(x^y)^Q(x)^Q(y)

def colors(x):return sum(((x&neighbors[i]).bit_count()%2)<<i for i in range(n))
assert len({colors(x) for x in range(256)})==256
assert collections.Counter(Q(x) for x in range(256))=={0:136,1:120}
assert sum((-1)**Q(x) for x in range(256))==16
rows=[]
for D in range(1,256):
 if any(D>>i&1 and D>>j&1 for i,j in edges):continue
 d=D.bit_count();assert d<=4
 X=[x for x in range(256) if colors(x)&D==D]
 classes={}
 for x in X:classes.setdefault(x&~D,[]).append(x)
 assert len(classes)==2**(8-2*d)
 counts=collections.Counter()
 for rep,cl in classes.items():
  assert len(cl)==2**d
  assert all(Q(x)==Q(rep) for x in cl)
  for x in cl:
   for i in range(n):
    if D>>i&1:assert x^(1<<i) in cl
  counts[Q(rep)]+=1
 total=2**(8-2*d);gauss=2**(4-d)
 assert counts[0]==(total+gauss)//2 and counts[1]==(total-gauss)//2
 # Independent Fourier character-sum identity, for every l in the span L.
 for l in range(256):
  if l&~D:continue
  inner=sum((-1)**(Q(x)^B(x,l)) for x in range(256))
  assert inner==((-1)**Q(l))*16
 assert sum((-1)**Q(x) for x in X)==16
 rows.append({'D':D,'dimension':d,'black_raw_marks':len(X),'orbit120_classes':counts[1],'orbit135_classes':counts[0]})
out={'passed':True,'quadratic_form':'Q(x)=sum_i x_i + sum_{edges} x_i*x_j mod2 in the simple-root lattice','Arf_invariant':0,'all_independent_nonempty_descent_sets':len(rows),'independent_sets_by_size':dict(collections.Counter(r['dimension'] for r in rows)),'class_counts_by_d':{str(d):{'orbit120':(2**(8-2*d)-2**(4-d))//2,'orbit135':(2**(8-2*d)+2**(4-d))//2} for d in range(1,5)},'rows':rows}
p=ROOT/'round21/structure/e8_black_sink_quadratic_audit.json';p.write_text(json.dumps(out,indent=2)+'\n');print(json.dumps({k:v for k,v in out.items() if k!='rows'},indent=2))
