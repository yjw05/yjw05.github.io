#!/usr/bin/env python3
"""Fresh S4/S5 computation of same-I positive canonical source supports.

The only geometric assumptions are the same-I source theorem and actual
unshifted canonical decompositions at a central completion.  No old
certificate or Kazhdan--Lusztig table is imported.
"""
from collections import defaultdict
from functools import lru_cache
from itertools import combinations, permutations
from pathlib import Path
import json


def audit(n):
    size = n + 1
    identity = tuple(range(1, size + 1))
    elements = list(permutations(identity))

    def length(p):
        return sum(p[i] > p[j] for i in range(size) for j in range(i + 1, size))

    def right(p, s):
        q = list(p)
        q[s - 1], q[s] = q[s], q[s - 1]
        return tuple(q)

    def left(p, s):
        return tuple(s + 1 if a == s else s if a == s + 1 else a for a in p)

    def multiply(p, q):
        return tuple(p[a - 1] for a in q)

    @lru_cache(None)
    def word(p):
        if p == identity:
            return ()
        s = next(s for s in range(1, size) if p[s - 1] > p[s])
        return word(right(p, s)) + (s,)

    @lru_cache(None)
    def bruhat(p, q):
        return all(sum(p[k] >= j for k in range(i)) <=
                   sum(q[k] >= j for k in range(i))
                   for i in range(1, size + 1) for j in range(1, size + 1))

    ascending = sorted(elements, key=lambda p: (length(p), p))
    lower = {q: tuple(p for p in ascending if bruhat(p, q)) for q in elements}

    def poly_add(a, b, shift=0, scale=1):
        out = list(a) + [0] * max(0, len(b) + shift - len(a))
        for i, value in enumerate(b):
            out[i + shift] += scale * value
        while out and out[-1] == 0:
            out.pop()
        return tuple(out)

    @lru_cache(None)
    def kl(x, w):
        if not bruhat(x, w):
            return ()
        if x == w:
            return (1,)
        s = next(s for s in range(1, size) if length(left(w, s)) < length(w))
        sw, sx = left(w, s), left(x, s)
        c = int(length(sx) < length(x))
        p = poly_add((), kl(sx, sw), 1 - c)
        p = poly_add(p, kl(x, sw), c)
        for z in lower[sw]:
            if z == sw or not bruhat(x, z) or length(left(z, s)) >= length(z):
                continue
            diff = length(sw) - length(z)
            if diff % 2 != 1:
                continue
            pz = kl(z, sw)
            mu = pz[(diff - 1) // 2] if (diff - 1) // 2 < len(pz) else 0
            if mu:
                p = poly_add(p, kl(x, z), (length(w) - length(z)) // 2, -mu)
        assert p and p[0] == 1 and all(a >= 0 for a in p)
        assert len(p) - 1 <= (length(w) - length(x) - 1) // 2
        return p

    canon = {w: {x: sum(kl(x, w)) for x in lower[w]} for w in ascending}
    # A separate q-polynomial check: P_{x,w}=P_{x^-1,w^-1}.
    def inverse(p):
        out = [0] * size
        for i, a in enumerate(p):
            out[a - 1] = i + 1
        return tuple(out)
    for w in elements:
        for x in lower[w]:
            assert kl(x, w) == kl(inverse(x), inverse(w))

    def convolve(a, b):
        out = defaultdict(int)
        for x, ax in a.items():
            for y, by in b.items():
                out[multiply(x, y)] += ax * by
        return dict(out)

    def expand(character):
        remain = dict(character)
        result = {}
        for w in reversed(ascending):
            coefficient = remain.get(w, 0)
            assert coefficient >= 0
            if coefficient:
                result[w] = coefficient
                for x, value in canon[w].items():
                    remain[x] = remain.get(x, 0) - coefficient * value
        assert all(v == 0 for v in remain.values())
        return result

    # Check every rank-one canonical multiplication independently at v=1.
    checked_products = 0
    for w in elements:
        for s in range(1, size):
            sw = left(w, s)
            expansion = expand(convolve(canon[right(identity, s)], canon[w]))
            if length(sw) < length(w):
                expected = {w: 2}
            else:
                expected = {sw: 1}
                for z in lower[w]:
                    diff = length(w) - length(z)
                    if diff % 2 != 1 or length(left(z, s)) >= length(z):
                        continue
                    pz = kl(z, w)
                    mu = pz[(diff - 1) // 2] if (diff - 1) // 2 < len(pz) else 0
                    if mu:
                        expected[z] = mu
            assert expansion == expected
            checked_products += 1

    subsets = [tuple(c) for k in range(size) for c in combinations(range(1, size), k)]
    stable = [I for I in subsets if tuple(sorted(size - i for i in I)) == I and len(I) < n]
    parabolics = {I: [p for p in elements if set(word(p)) <= set(I)] for I in subsets}
    longest = {I: max(parabolics[I], key=length) for I in subsets}
    # Literal endpoint Bott--Samelson words, avoiding a global canonical lift.
    bs = {}
    for p in elements:
        character = {identity: 1}
        for s in word(p):
            character = convolve(character, {identity: 1, right(identity, s): 1})
        bs[p] = character
    witnesses, heads, head_witnesses = {}, set(), {}
    source_count = 0
    for I in stable:
        for J in subsets:
            for u in parabolics[I]:
                for v in parabolics[I]:
                    character = convolve(convolve(bs[u], canon[longest[J]]), bs[v])
                    expansion = expand(character)
                    head = max(expansion, key=length)
                    heads.add(head)
                    head_witnesses.setdefault(head, {
                        "I": I, "J": J, "left_word": word(u), "right_word": word(v),
                        "top_multiplicity": character[head],
                        "source_word": word(u) + word(longest[J]) + word(v),
                    })
                    source_count += 1
                    for w, coefficient in expansion.items():
                        witnesses.setdefault(w, {
                            "I": I, "J": J, "left_word": word(u), "right_word": word(v),
                            "multiplicity": coefficient, "source_head": head,
                            "standard_character": {''.join(map(str, x)): c for x, c in character.items()},
                            "canonical_expansion": {''.join(map(str, x)): c for x, c in expansion.items()},
                        })
    # Four actual three-parabolic ordinary sources, with invariant right end.
    anchor_factors = {
        3: [((1, 2), (3,), (2,)), ((2, 3), (1,), (2,))],
        4: [((1, 2, 3), (4,), (2, 3)), ((2, 3, 4), (1,), (2, 3))],
    }[n]
    covered = dict(head_witnesses)
    anchors = []
    for factors in anchor_factors:
        assert tuple(sorted(size - s for s in factors[-1])) == factors[-1]
        character = {identity: 1}
        for J in factors:
            character = convolve(character, canon[longest[J]])
        top = max(character, key=length)
        assert all(bruhat(x, top) for x in character)
        assert character[top] > 0
        anchor = {"top": top, "parabolic_factors": factors,
                  "top_multiplicity": character[top],
                  "standard_character": {''.join(map(str, x)): c for x, c in character.items()}}
        anchors.append(anchor)
        covered[top] = {"kind": "invariant_end_anchor", "index": len(anchors) - 1}

    @lru_cache(None)
    def all_reduced_words(p):
        if p == identity:
            return ((),)
        return tuple(w + (s,) for s in range(1, size)
                     if p[s - 1] > p[s]
                     for w in all_reduced_words(right(p, s)))

    def demazure(letters):
        p = identity
        for s in letters:
            if p[s - 1] < p[s]:
                p = right(p, s)
        return p

    events = []
    while True:
        changed = False
        for p in ascending:
            if p in covered:
                continue
            found = False
            for letters in all_reduced_words(p):
                left_options = [letters[0]]
                right_options = [letters[-1]]
                if letters[0] in (1, n):
                    left_options.append(size - letters[0])
                if letters[-1] in (1, n):
                    right_options.append(size - letters[-1])
                for a in left_options:
                    for b in right_options:
                        target_word = (a,) + letters[1:-1] + (b,)
                        target = demazure(target_word)
                        if all(x in covered for x in lower[target]):
                            event = {"top": p, "source_reduced_word": letters,
                                     "target_word": target_word, "target_top": target,
                                     "lower_interval": lower[target]}
                            events.append(event)
                            covered[p] = {"kind": "padding", "index": len(events) - 1}
                            found = changed = True
                            break
                    if found:
                        break
                if found:
                    break
        if not changed:
            break

    assert len(covered) == len(elements), (n, [p for p in ascending if p not in covered])
    result = {
        "type": f"outer A{n}", "weyl_order": len(elements),
        "checked_rank_one_products": checked_products,
        "same_I_types": stable, "literal_sources_checked": source_count,
        "source_heads": len(heads), "positive_canonical_source_support": len(witnesses),
        "missing": [p for p in ascending if p not in witnesses],
        "witnesses": {''.join(map(str, p)): w for p, w in witnesses.items()},
        "head_witnesses": {''.join(map(str, p)): w for p, w in head_witnesses.items()},
        "invariant_end_anchors": anchors,
        "padding_events": events,
        "final_covered": len(covered),
        "all_tops_covered": len(covered) == len(elements),
    }
    return result


if __name__ == "__main__":
    out = Path(__file__).resolve().parent
    for n in (3, 4):
        result = audit(n)
        path = out / f"outer_a{n}_fresh_source_certificate.json"
        path.write_text(json.dumps(result, indent=2) + "\n")
        print(json.dumps({k: v for k, v in result.items()
                          if k not in {"witnesses", "head_witnesses", "padding_events", "invariant_end_anchors"}}))
        print(json.dumps({"anchors": [{k: v for k, v in a.items() if k != "standard_character"}
                                      for a in result["invariant_end_anchors"]],
                          "padding_events": len(result["padding_events"])}))
