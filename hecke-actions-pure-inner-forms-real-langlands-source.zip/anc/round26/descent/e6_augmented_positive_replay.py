#!/usr/bin/env python3
"""Exact nonnegative elimination using independently rebuilt E6 rows.

No candidate profile or weighted union-find certificate is imported.  Every
round rebuilds a rational graph from the full reconstructed endpoint rows.
Additional zero labels are the independently regenerated all-J same-I sources.
"""
from collections import defaultdict, deque
from fractions import Fraction
from pathlib import Path
import hashlib
import json
import time

HERE = Path(__file__).resolve().parent
ROOT = HERE.parent.parent
started = time.time()
row_path = HERE / "e6_residual_rows_replay.txt"
source_path = HERE / "e6_same_I_sources.txt"
missing_path = HERE / "e6_inputs/e6_endpoint_missing.txt"
rows = []
for line in row_path.read_text().splitlines():
    values = list(map(int, line.split()))
    assert len(values) % 2 == 0
    rows.append(list(zip(values[::2], values[1::2])))
states = list(map(int, missing_path.read_text().split()))
source_labels = set(map(int, source_path.read_text().split()))
assert len(rows) == 90782 and len(states) == 15663 and len(source_labels) == 19892
component = {x: x for x in states}
weight = {x: Fraction(1) for x in states}
dead = {x for x in states if x // 10 in source_labels}
initial_extra_zero_states = len(dead)
ledger = []

def reduced_rows():
    answer = []
    for ri, row in enumerate(rows):
        out = defaultdict(Fraction)
        for x, coefficient in row:
            if component[x] not in dead:
                out[component[x]] += coefficient * weight[x]
        out = {x: coefficient for x, coefficient in out.items() if coefficient}
        if out:
            answer.append((ri, out))
    return answer

while True:
    active = {component[x] for x in states if component[x] not in dead}
    if not active:
        break
    reduced = reduced_rows()
    graph = {x: [] for x in active}
    force_zero = set()
    one_sign_rows = []
    for ri, row in reduced:
        if len({coefficient > 0 for coefficient in row.values()}) == 1:
            force_zero.update(row)
            one_sign_rows.append(ri)
        elif len(row) == 2:
            (x, a), (y, b) = row.items()
            ratio = -a / b
            assert ratio > 0
            graph[x].append((y, ratio, ri))
            graph[y].append((x, 1 / ratio, ri))
    root_of, relative, members_of = {}, {}, {}
    cycle_rows = []
    for root in sorted(active):
        if root in root_of:
            continue
        root_of[root], relative[root] = root, Fraction(1)
        queue, members, inconsistent = deque([root]), [], False
        while queue:
            x = queue.popleft()
            members.append(x)
            for y, ratio, ri in graph[x]:
                expected = relative[x] * ratio
                if y in root_of:
                    assert root_of[y] == root
                    if relative[y] != expected:
                        inconsistent = True
                        cycle_rows.append(ri)
                else:
                    root_of[y], relative[y] = root, expected
                    queue.append(y)
        members_of[root] = members
        if inconsistent or any(x in force_zero for x in members):
            force_zero.update(members)
    live_after = sum(not any(x in force_zero for x in members)
                     for members in members_of.values())
    ledger.append({"active_before": len(active), "two_term_components": len(members_of),
                   "active_after": live_after, "one_sign_rows": len(one_sign_rows),
                   "inconsistent_cycles": len(cycle_rows),
                   "one_sign_row_sha256": hashlib.sha256(json.dumps(one_sign_rows).encode()).hexdigest()})
    old_dead = set(dead)
    dead = set()
    for x in states:
        r = component[x]
        if r in old_dead:
            dead.add(r)
            continue
        component[x] = root_of[r]
        weight[x] *= relative[r]
        if r in force_zero:
            dead.add(root_of[r])
    print(ledger[-1], flush=True)
    if live_after >= len(active):
        break

remaining = [x for x in states if component[x] not in dead]
out = {"passed": not remaining,
       "method": "Full exact rational positive graph, using regenerated same-I/all-J source zeros; no primitive profile imported.",
       "old_residual_states": len(states), "old_residual_rows": len(rows),
       "new_source_zero_states": initial_extra_zero_states,
       "remaining_states": len(remaining), "rounds": ledger,
       "input_sha256": {p.name: hashlib.sha256(p.read_bytes()).hexdigest()
                         for p in (row_path, source_path, missing_path)},
       "seconds": time.time()-started}
(HERE / "e6_augmented_positive_replay.json").write_text(json.dumps(out, indent=2)+"\n")
assert not remaining, out
print("PASS all 518400 marked outer-E6 coefficients", flush=True)
