#include "e6_root_permutation.hpp"
#include <set>
#include <sstream>
struct Product {vector<pair<int,int>>terms;};
int main(int argc,char**argv){assert(argc==7);Group W;W.down.clear();W.down.shrink_to_fit();vector<char>base(W.N);ifstream bi(argv[1]);int x;while(bi>>x)base[x]=1;assert(accumulate(base.begin(),base.end(),0)==26242);
 vector<vector<pair<int,int>>>mu(W.N);ifstream mi(argv[2]);assert(mi);set<pair<int,int>>seen_mu;string line;int y,u,c;
 while(getline(mi,line)){
  if(line.find_first_not_of(" \t\r")==string::npos)continue;
  istringstream row(line);string extra;assert(row>>y>>u>>c);assert(!(row>>extra));
  assert(0<=y&&y<W.N&&0<=u&&u<W.N&&c>0);assert(seen_mu.emplace(y,u).second);
  mu[u].push_back({y,c});
 }
 assert(mi.eof());assert(seen_mu.size()==84837);
 vector<Product>P(W.N*12);for(int u=0;u<W.N;u++)for(int side=0;side<2;side++)for(int s=0;s<6;s++){
  auto&p=P[u*12+side*6+s].terms;int v=side?W.L[u][s]:W.R[u][s];if(W.len[v]<W.len[u]){if(!base[u])p.push_back({u,2});}
  else{if(!base[v])p.push_back({v,1});for(int z:W.low[u])if(!base[z]&&((side?W.dl[z]:W.dr[z])>>s&1))p.push_back({z,1});for(auto[z,m]:mu[u])if((side?W.dl[z]:W.dr[z])>>s&1)p.push_back({z,m});}sort(p.begin(),p.end());
 }
 vector<pair<int,int>>sectors;int sec[4][4];for(auto&r:sec)for(int&v:r)v=-1;for(int z=0;z<4;z++)for(int y=0;y<4;y++)if((z==0)==(y==0)){sec[z][y]=sectors.size();sectors.push_back({z,y});}assert(sectors.size()==10);int th[6]={5,1,4,3,2,0};
 auto white=[](int m,int s){assert(s==1||s==3);return s==1?!(m&2):!(m&1);};auto action=[](int m,int s){return s==1?m^((m&2)>>1):m^((m&1)<<1);};
 auto equation=[&](int kind,int u,int side,int s,int a,int b){map<int,int>row;for(auto[w,n]:P[u*12+side*6+s].terms)row[w*10+a]+=n;auto[z,y]=sectors[a];int m=side?z:y;
  if(kind==0){assert(white(m,s)&&a==b);if(!base[u])row[u*10+a]-=2;}
  else if(kind==1){assert(!white(m,s));int mm=action(m,s);assert(b==(side?sec[mm][y]:sec[z][mm]));for(auto[w,n]:P[u*12+side*6+s].terms)row[w*10+b]-=n;}
  else{assert(kind==2&&a==b&&(s==0||s==2));for(auto[w,n]:P[u*12+side*6+th[s]].terms)row[w*10+a]-=n;}
  for(auto it=row.begin();it!=row.end();)if(!it->second)it=row.erase(it);else++it;return row;
 };
 vector<char>known(W.N*10);for(int w=0;w<W.N;w++)if(base[w])for(int a=0;a<10;a++)known[w*10+a]=1;
 ifstream ei(argv[3]);int var,kind,side,s,a,b;int events=0;while(ei>>var>>kind>>u>>side>>s>>a>>b){assert(!known[var]);auto row=equation(kind,u,side,s,a,b);assert(row.count(var));int positive=0,negative=0;for(auto[v,n]:row)if(!known[v]){positive+=n>0;negative+=n<0;}assert((positive>0||negative>0)&&(!positive||!negative));known[var]=1;events++;}
 assert(events==240317);vector<char>expected(W.N*10,1);ifstream miss(argv[4]);while(miss>>x)expected[x]=0;assert(known==expected);assert(accumulate(known.begin(),known.end(),0)==502737);cerr<<"All "<<events<<" marked zero events independently replayed\n";
 ofstream residual(argv[5]);int eqcount=0,rescount=0;
 auto checkrow=[&](int kind,int u,int side,int s,int a,int b){auto row=equation(kind,u,side,s,a,b);if(row.empty())return;eqcount++;vector<pair<int,int>>r;for(auto[v,n]:row)if(!known[v])r.push_back({v,n});if(r.empty())return;rescount++;for(size_t j=0;j<r.size();j++){if(j)residual<<" ";residual<<r[j].first<<" "<<r[j].second;}residual<<"\n";};
 for(int u=0;u<W.N;u++)for(int side=0;side<2;side++){
  for(int s:{1,3})for(int a=0;a<10;a++){auto[z,y]=sectors[a];int m=side?z:y;if(white(m,s))checkrow(0,u,side,s,a,a);else{int mm=action(m,s),b=side?sec[mm][y]:sec[z][mm];if(a<=b)checkrow(1,u,side,s,a,b);}}
  for(int s:{0,2})for(int a=0;a<10;a++)checkrow(2,u,side,s,a,a);
 }
 assert(eqcount==1374050&&rescount==90782);ofstream out(argv[6]);out<<"{\"passed\":true,\"method\":\"Independent root-permutation product support reconstruction and ordered markwise equation/event replay.\",\"replayed_zero_events\":"<<events<<",\"all_endpoint_equations\":"<<eqcount<<",\"remaining_equations_rebuilt\":"<<rescount<<",\"remaining_states\":15663,\"known_sector_labels\":502737,\"upstream_mu_requirement\":\"All targeted coefficients independently verified by e6_mu_left_audit.cpp.\"}\n";cerr<<"PASS all equations, events and final missing states\n";
}
