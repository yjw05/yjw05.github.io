#include <algorithm>
#include <array>
#include <cassert>
#include <cstdint>
#include <fstream>
#include <iostream>
#include <map>
#include <numeric>
#include <sstream>
#include <queue>
#include <string>
#include <unordered_map>
#include <vector>
using namespace std;
using Rt=array<int8_t,6>;using Perm=array<uint8_t,72>;
struct Group {
 int A[6][6]{},N=0,nw=0;vector<Rt> roots;vector<Perm> g;array<Perm,6>s;
 unordered_map<string,int>idx;vector<array<int,6>>R,L;vector<int>len,parent,last,dl,dr;vector<vector<int>>low;vector<uint64_t>down;
 string key(const Perm&p){return string((const char*)p.data(),72);}
 Rt refl(Rt a,int i){int d=0;for(int j=0;j<6;j++)d+=A[i][j]*a[j];a[i]-=d;return a;}
 vector<int>word(int u){vector<int>w;while(u){w.push_back(last[u]);u=parent[u];}reverse(w.begin(),w.end());return w;}
 bool below(int x,int w){return down[(size_t)w*nw+x/64]>>(x%64)&1ULL;}
 Group(){
  for(int i=0;i<6;i++)A[i][i]=2;for(auto [i,j]:vector<pair<int,int>>{{0,2},{2,3},{3,4},{4,5},{1,3}})A[i][j]=A[j][i]=-1;
  map<Rt,int>ri;for(int i=0;i<6;i++){Rt a{};a[i]=1;ri[a]=0;roots.push_back(a);}
  for(size_t i=0;i<roots.size();i++)for(int j=0;j<6;j++){Rt a=refl(roots[i],j);if(!ri.count(a)){ri[a]=0;roots.push_back(a);}}
  sort(roots.begin(),roots.end());assert(roots.size()==72);for(int i=0;i<72;i++)ri[roots[i]]=i;
  for(int j=0;j<6;j++)for(int i=0;i<72;i++)s[j][i]=ri.at(refl(roots[i],j));
  Perm id{};iota(id.begin(),id.end(),0);g.push_back(id);idx.reserve(110000);idx[key(id)]=0;len.push_back(0);parent.push_back(-1);last.push_back(-1);
  for(size_t u=0;u<g.size();u++){auto p=g[u];array<int,6>row{};for(int j=0;j<6;j++){Perm q{};for(int i=0;i<72;i++)q[i]=p[s[j][i]];auto k=key(q);auto it=idx.find(k);int v;if(it==idx.end()){v=g.size();idx[k]=v;g.push_back(q);len.push_back(len[u]+1);parent.push_back(u);last.push_back(j);}else v=it->second;row[j]=v;}R.push_back(row);}
  N=g.size();assert(N==51840);L.resize(N);dl.resize(N);dr.resize(N);low.resize(N);
  vector<int>pos;vector<char>neg(72);for(int i=0;i<72;i++){bool p=true,n=true;for(int x:roots[i]){p&=x>=0;n&=x<=0;}if(p)pos.push_back(i);neg[i]=n;}assert(pos.size()==36);
  long long nc=0;for(int u=0;u<N;u++){
   int check=0;for(int i:pos)check+=neg[g[u][i]];assert(check==len[u]);
   for(int j=0;j<6;j++){Perm q{};for(int i=0;i<72;i++)q[i]=s[j][g[u][i]];L[u][j]=idx.at(key(q));dl[u]|=(len[L[u][j]]<len[u])<<j;dr[u]|=(len[R[u][j]]<len[u])<<j;}
   auto w=word(u);vector<int>c;for(size_t j=0;j<w.size();j++){int v=0;for(size_t k=0;k<w.size();k++)if(k!=j)v=R[v][w[k]];if(len[v]+1==len[u])c.push_back(v);}sort(c.begin(),c.end());c.erase(unique(c.begin(),c.end()),c.end());low[u]=move(c);nc+=low[u].size();
  }assert(nc==459588);cerr<<"Independent 72-root permutation model, lengths and "<<nc<<" deletion covers passed\n";
  nw=(N+63)/64;down.resize((size_t)N*nw);for(int u=0;u<N;u++){auto d=&down[(size_t)u*nw];d[u/64]|=1ULL<<(u%64);for(int v:low[u]){auto b=&down[(size_t)v*nw];for(int k=0;k<nw;k++)d[k]|=b[k];}}
  cerr<<"Independent deletion Bruhat intervals ready\n";
 }
};
struct LeftKL {
 Group&W;unordered_map<uint64_t,vector<int64_t>>cache;vector<int>seen;int stamp=0;long long calls=0;int64_t maxcoefficient=0,maxproduct=0;
 LeftKL(Group&w):W(w),seen(w.N){cache.reserve(2000000);}
 // No inverse/theta cache identification is used. Main recurrence is LEFT,
 // whereas the calculation being audited uses a RIGHT recurrence.
 vector<int64_t>p(int x,int w){calls++;if(!W.below(x,w))return{};if(x==w||W.len[w]-W.len[x]<=2)return{1};uint64_t k=((uint64_t)w<<16)|x;auto hit=cache.find(k);if(hit!=cache.end())return hit->second;
  int unmatched=W.dl[w]&~W.dl[x];if(unmatched){int s=__builtin_ctz(unmatched);auto a=p(W.L[x][s],w);cache.emplace(k,a);return a;}
  unmatched=W.dr[w]&~W.dr[x];if(unmatched){int s=__builtin_ctz(unmatched);auto a=p(W.R[x][s],w);cache.emplace(k,a);return a;}
  int s=__builtin_ctz(W.dl[w]),v=W.L[w][s],sx=W.L[x][s],degree=(W.len[w]-W.len[x]-1)/2;assert(W.len[sx]<W.len[x]);
  int st=++stamp;vector<int>walk,candidates;for(int z:W.low[v])if(W.len[z]>=W.len[x]&&W.below(x,z)){walk.push_back(z);seen[z]=st;}
  for(size_t i=0;i<walk.size();i++){int z=walk[i],d=W.len[v]-W.len[z];if((d&1)&&(W.dl[z]>>s&1)&&(d==1||(!(W.dl[v]&~W.dl[z])&&!(W.dr[v]&~W.dr[z]))))candidates.push_back(z);
   for(int t:W.low[z])if(W.len[t]>=W.len[x]&&seen[t]!=st&&W.below(x,t)){walk.push_back(t);seen[t]=st;}
  }
  vector<int64_t>a(degree+1);auto p1=p(sx,v),p2=p(x,v);for(size_t i=0;i<p1.size();i++)a[i]+=p1[i];for(size_t i=0;i<p2.size()&&i+1<a.size();i++)a[i+1]+=p2[i];
  for(int z:candidates){int d=W.len[v]-W.len[z];int64_t mu=1;if(d>1){auto q=p(z,v);mu=q.size()>(d-1)/2?q[(d-1)/2]:0;}if(!mu)continue;auto q=p(x,z);int shift=(W.len[w]-W.len[z])/2;for(size_t i=0;i<q.size()&&i+shift<a.size();i++){maxproduct=max(maxproduct,mu*q[i]);a[i+shift]-=mu*q[i];}}
  assert(a[0]==1);for(auto z:a){assert(z>=0);maxcoefficient=max(maxcoefficient,z);}while(a.size()>1&&a.back()==0)a.pop_back();cache.emplace(k,a);return a;
 }
 int64_t mu(int x,int w){int d=W.len[w]-W.len[x];if(d==1)return W.below(x,w);if(d<=0||!(d&1)||(W.dl[w]&~W.dl[x])||(W.dr[w]&~W.dr[x]))return 0;auto a=p(x,w);return a.size()>(d-1)/2?a[(d-1)/2]:0;}
};
int main(int argc,char**argv){assert(argc==4);Group W;vector<char>base(W.N);ifstream bi(argv[1]);int x;while(bi>>x)base[x]=1;assert(accumulate(base.begin(),base.end(),0)==26242);
 unordered_map<uint64_t,int>expected;ifstream mi(argv[2]);assert(mi);string line;int y,u,c;
 while(getline(mi,line)){
  if(line.find_first_not_of(" \t\r")==string::npos)continue;
  istringstream row(line);string extra;assert(row>>y>>u>>c);assert(!(row>>extra));
  assert(0<=y&&y<W.N&&0<=u&&u<W.N&&c>0);
  auto key=(uint64_t(u)<<16)|uint64_t(y);assert(expected.emplace(key,c).second);
 }
 assert(mi.eof());assert(expected.size()==84837);
 LeftKL K(W);long long potential=0,positive=0;int maxmu=0;
 for(int w=0;w<W.N;w++){auto d=&W.down[(size_t)w*W.nw];for(int b=0;b<W.nw;b++){auto bits=d[b];while(bits){int k=__builtin_ctzll(bits),z=b*64+k;bits&=bits-1;if(base[z]||W.len[w]-W.len[z]<3||!((W.len[w]-W.len[z])&1)||(W.dl[w]&~W.dl[z])||(W.dr[w]&~W.dr[z]))continue;potential++;auto value=K.mu(z,w);auto key=((uint64_t)w<<16)|z;int want=expected.count(key)?expected.at(key):0;if(value!=want){cerr<<"MISMATCH "<<z<<","<<w<<": "<<value<<" != "<<want<<"\n";return 2;}if(value){positive++;maxmu=max(maxmu,(int)value);}}}
  if(w%5000==0)cerr<<"left KL "<<w<<" pairs "<<potential<<" positives "<<positive<<" cache "<<K.cache.size()<<"\n";
 }
 assert(potential==481490&&positive==84837);ofstream o(argv[3]);o<<"{\"passed\":true,\"method\":\"Independent 72-root permutation group, deletion Bruhat covers, left-q KL recurrence, no inverse/theta cache quotient; all targeted zero and nonzero coefficients checked.\",\"group_order\":51840,\"strong_covers\":459588,\"targeted_pairs\":"<<potential<<",\"positive_pairs\":"<<positive<<",\"maximum_targeted_mu\":"<<maxmu<<",\"maximum_computed_polynomial_coefficient\":"<<K.maxcoefficient<<",\"maximum_subtraction_product\":"<<K.maxproduct<<",\"cache_size\":"<<K.cache.size()<<",\"recursion_calls\":"<<K.calls<<"}\n";cerr<<"PASS exhaustive left KL audit\n";
}
