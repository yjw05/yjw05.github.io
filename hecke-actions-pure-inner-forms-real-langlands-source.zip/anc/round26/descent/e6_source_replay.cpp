#include "e6_root_permutation.hpp"
// Rebuild the old ordinary seed family using the independently generated
// root-permutation group and deletion Bruhat order. Every source top gets
// a literal parabolic/endpoint witness; no old seed membership is assumed.
int main(int argc,char**argv){
 assert(argc==4);Group W;int N=W.N;const int th[6]={5,1,4,3,2,0};
 auto tm=[&](int K){int z=0;for(int s=0;s<6;s++)if(K>>s&1)z|=1<<th[s];return z;};
 vector<int>stable,allowed,w0(64);vector<vector<int>>pw(64),par(64),upper(N);vector<array<int,6>>proof(N);
 for(int K=0;K<64;K++){
  if(tm(K)==K)stable.push_back(K);int closure=K|tm(K),seen=0;bool ok=true;
  for(int s=0;s<6;s++)if((closure>>s&1)&&!(seen>>s&1)){
   vector<int>queue{s};seen|=1<<s;int component=0;
   for(size_t j=0;j<queue.size();j++){int t=queue[j];component|=1<<t;for(int r=0;r<6;r++)if(W.A[t][r]==-1&&(closure>>r&1)&&!(seen>>r&1)){seen|=1<<r;queue.push_back(r);}}
   if((K&component)!=0&&(K&component)!=component)ok=false;
  }if(ok)allowed.push_back(K);
  int u=0;while(true){int s=0;while(s<6&&(!(K>>s&1)||W.len[W.R[u][s]]<W.len[u]))s++;if(s==6)break;u=W.R[u][s];pw[K].push_back(s);}w0[K]=u;
  for(int v=0;v<N;v++)if(W.below(v,u))par[K].push_back(v);
 }
 assert(allowed.size()==32);for(int u=0;u<N;u++)for(int v:W.low[u])upper[v].push_back(u);
 vector<int>dem(N*64),ldem(N*64);
 for(int u=0;u<N;u++)for(int K=0;K<64;K++){int v=u,z=u;for(int s:pw[K]){if(W.len[W.R[v][s]]>W.len[v])v=W.R[v][s];if(W.len[W.L[z][s]]>W.len[z])z=W.L[z][s];}dem[u*64+K]=v;ldem[u*64+K]=z;}
 vector<char>base(N);vector<array<int,6>>ledger;
 auto add=[&](int w,array<int,6>p){if(!base[w]){base[w]=1;p[0]=w;ledger.push_back(p);}};
 // Four factors with admissible endpoints. A selected half of an
 // exchanged component is replaced by its stable closure up to a
 // positive finite copy; the stable-end source lemma proves ordinarity.
 for(int A:allowed)for(int B=0;B<64;B++)for(int C=0;C<64;C++){
  int u=dem[dem[w0[A]*64+B]*64+C];for(int D:allowed)add(dem[u*64+D],{0,0,A,B,C,D});
 }
 int fourcount=accumulate(base.begin(),base.end(),0);
 auto family=[&](int I,vector<int>Js,int kind){vector<char>seen(N);vector<int>queue;for(int J:Js){int u=w0[J];if(!seen[u]){seen[u]=1;queue.push_back(u);add(u,{0,kind,I,J,-1,-1});}}for(size_t z=0;z<queue.size();z++){int u=queue[z];for(int s=0;s<6;s++)if(I>>s&1)for(int side=0;side<2;side++){int v=side?W.L[u][s]:W.R[u][s];if(W.len[v]>W.len[u]&&!seen[v]){seen[v]=1;queue.push_back(v);add(v,{0,kind,I,u,s,side});}}}};
 for(int I:stable)if(I!=63){vector<int>Js;for(int J=0;J<64;J++)if(!(J&tm(J)&~I))Js.push_back(J);family(I,Js,1);}
 int beforeclosure=accumulate(base.begin(),base.end(),0);int transportcount=0;
 auto close=[&](){vector<char>good(N);vector<int>bad(N);for(int u=0;u<N;u++){for(int v:W.low[u])bad[u]+=!good[v];good[u]=base[u]&&!bad[u];}
  auto mark=[&](int u){base[u]=1;if(bad[u]||good[u])return;vector<int>queue{u};good[u]=1;for(size_t j=0;j<queue.size();j++)for(int v:upper[queue[j]]){assert(bad[v]>0);bad[v]--;if(!bad[v]&&base[v]&&!good[v]){good[v]=1;queue.push_back(v);}}};
  bool changed=true;while(changed){changed=false;for(int w=0;w<N;w++)if(!base[w]){bool found=false;for(int side=0;side<2&&!found;side++){int desc=side?W.dl[w]:W.dr[w];for(int K:allowed)if(K&&!(K&~desc)){int u=w;for(int s:pw[K])u=side?W.L[u][s]:W.R[u][s];assert(W.len[u]+W.len[w0[K]]==W.len[w]);for(int L:allowed)if(K!=L&&(K|tm(K))==(L|tm(L))){int v=side?ldem[u*64+L]:dem[u*64+L];if(good[v]){ // Validate every point in the full lower interval, not just covers.
      for(int z=0;z<N;z++)if(W.below(z,v))assert(base[z]);
      ledger.push_back({w,2,side,K,L,v});mark(w);transportcount++;changed=found=true;break;}}
    if(found)break;}}}}
 };
 close();for(int J:{33,20,2,8})family(63^J,{J},3);close();
 vector<char>expected(N);ifstream old(argv[1]);int v;while(old>>v)expected[v]=1;assert(base==expected);assert(accumulate(base.begin(),base.end(),0)==26242);
 // All-J same-I families, with one bit for each omitted theta-orbit.
 int omit[4]={33,20,2,8};vector<unsigned char>same(N);for(int J=0;J<64;J++)same[w0[J]]=15;
 for(int u=0;u<N;u++)for(int s=0;s<6;s++){int bits=0;for(int i=0;i<4;i++)if(!(omit[i]>>s&1))bits|=1<<i;bits&=same[u];for(int z:{W.L[u][s],W.R[u][s]})if(W.len[z]>W.len[u])same[z]|=bits;}
 int samecount=0,unioncount=0;for(int u=0;u<N;u++){samecount+=same[u]!=0;unioncount+=base[u]||same[u];}assert(samecount==19892&&unioncount==26760);
 ofstream sout(argv[2]);for(int u=0;u<N;u++)if(same[u])sout<<u<<"\n";
 // Exact group-algebra character of the R2 detector T, and unique top.
 int masks[5]={8,53,30,53,8};vector<long long>character(N);character[0]=1;int top=0;
 for(int K:masks){vector<long long>next(N);for(int u=0;u<N;u++)if(character[u])for(int z:par[K]){int t=u;for(int s:W.word(z))t=W.R[t][s];next[t]+=character[u];}character.swap(next);top=dem[top*64+K];}
 assert(top==39447&&same[top]);long long mass=0;int support=0;for(int u=0;u<N;u++)if(character[u]){mass+=character[u];support++;assert(W.below(u,top));}
 assert(character[top]==16&&mass==995328&&support==17104);
 ofstream o(argv[3]);o<<"{\"passed\":true,\"old_source_count\":26242,\"four_source_count\":"<<fourcount<<",\"before_transport\":"<<beforeclosure<<",\"transport_steps\":"<<transportcount<<",\"same_I_all_J\":19892,\"union_sources\":26760,\"detector\":{\"top\":39447,\"top_word\":[";auto word=W.word(top);for(size_t i=0;i<word.size();i++){if(i)o<<",";o<<word[i]+1;}o<<"],\"top_multiplicity\":16,\"standard_mass\":995328,\"standard_support\":17104},\"source_ledger\":[";for(size_t i=0;i<ledger.size();i++){if(i)o<<",";o<<"[";for(int j=0;j<6;j++){if(j)o<<",";o<<ledger[i][j];}o<<"]";}o<<"]}\n";
 cerr<<"PASS independent source reconstruction 26242, all-J 19892, union26760, detector top39447 mult16\n";
}
