#!/usr/bin/env python3
"""Independent replay using parabolic subgroup enumeration and subword Bruhat.

No Kazhdan--Lusztig calculation or producer module is imported.  This verifies
the triangular source family, both actual invariant-end anchor tops, and
every acyclic endpoint/whole-lower-interval propagation step.
"""
from collections import Counter
from functools import lru_cache
from pathlib import Path
import hashlib
import json


def replay(path):
    data = json.loads(path.read_text())
    n = int(data["type"].split("A")[1])
    m = n + 1
    e = tuple(range(1, m + 1))

    def rmult(p, s):
        return p[:s-1] + (p[s], p[s-1]) + p[s+1:]

    def mul(p, q):
        return tuple(p[i-1] for i in q)

    def ell(p):
        return sum(a > b for i, a in enumerate(p) for b in p[i+1:])

    def reduced(p):
        letters = []
        while p != e:
            s = max(s for s in range(1, m) if p[s-1] > p[s])
            p = rmult(p, s)
            letters.append(s)
        return tuple(reversed(letters))

    @lru_cache(None)
    def interval(p):
        # Independent of the producer's rank-matrix Bruhat implementation.
        values = {e}
        for s in reduced(p):
            values |= {rmult(q, s) for q in values}
        return frozenset(values)

    def subgroup(J):
        found, queue = {e}, [e]
        for p in queue:
            for s in J:
                q = rmult(p, s)
                if q not in found:
                    found.add(q)
                    queue.append(q)
        return found

    def conv(a, b):
        ans = Counter()
        for p, cp in a.items():
            for q, cq in b.items():
                ans[mul(p, q)] += cp*cq
        return ans

    def bs(word):
        ans = Counter({e: 1})
        for s in word:
            ans = conv(ans, Counter({e: 1, rmult(e, s): 1}))
        return ans

    def verify_top(char, target, multiplicity):
        assert char[target] == multiplicity > 0
        assert set(char) <= interval(target)
        assert ell(target) == max(map(ell, char))

    covered = set()
    for label, witness in data["head_witnesses"].items():
        target = tuple(map(int, label))
        I, J = set(witness["I"]), set(witness["J"])
        assert len(I) < n and {m-s for s in I} == I
        assert set(witness["left_word"]) <= I
        assert set(witness["right_word"]) <= I
        char = conv(conv(bs(witness["left_word"]), Counter({p: 1 for p in subgroup(J)})),
                    bs(witness["right_word"]))
        verify_top(char, target, witness["top_multiplicity"])
        covered.add(target)
    assert len(covered) == data["source_heads"]
    starting_count = len(covered)

    for witness in data["invariant_end_anchors"]:
        factors = witness["parabolic_factors"]
        assert len(factors) == 3
        assert {m-s for s in factors[-1]} == set(factors[-1])
        assert not (set(factors[0]) & set(factors[1]))
        char = Counter({e: 1})
        for J in factors:
            char = conv(char, Counter({p: 1 for p in subgroup(J)}))
        target = tuple(witness["top"])
        verify_top(char, target, witness["top_multiplicity"])
        assert {''.join(map(str, p)): c for p, c in char.items()} == witness["standard_character"]
        covered.add(target)

    for witness in data["padding_events"]:
        source = tuple(witness["source_reduced_word"])
        target_word = tuple(witness["target_word"])
        p = e
        for s in source:
            p = rmult(p, s)
        assert p == tuple(witness["top"]) and ell(p) == len(source)
        assert p not in covered
        assert source[1:-1] == target_word[1:-1]
        assert source[0] == target_word[0] or {source[0], target_word[0]} == {1, n}
        assert source[-1] == target_word[-1] or {source[-1], target_word[-1]} == {1, n}
        char = bs(target_word)
        target = tuple(witness["target_top"])
        verify_top(char, target, char[target])
        lower = interval(target)
        assert lower == frozenset(tuple(x) for x in witness["lower_interval"])
        assert lower <= covered
        covered.add(p)

    full = subgroup(range(1, m))
    assert covered == full
    return {"type": data["type"], "initial_heads": starting_count,
            "anchor_count": len(data["invariant_end_anchors"]),
            "padding_steps": len(data["padding_events"]), "final_count": len(covered),
            "status": "VERIFIED_FROM_SOURCE_WORDS_AND_SUBWORD_BRUHAT",
            "certificate_sha256": hashlib.sha256(path.read_bytes()).hexdigest()}


if __name__ == "__main__":
    base = Path(__file__).resolve().parent
    results = [replay(base / f"outer_a{n}_fresh_source_certificate.json") for n in (3, 4)]
    out = base / "outer_small_independent_replay.json"
    out.write_text(json.dumps(results, indent=2) + "\n")
    print(json.dumps(results, indent=2))
