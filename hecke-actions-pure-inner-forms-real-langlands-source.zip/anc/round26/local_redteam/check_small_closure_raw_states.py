"""A second closure verifier, keeping every raw endpoint pair explicitly.

Reuses only the Cartan-matrix Weyl enumeration class from the new root
audit.  It does not reuse source propagation, mark quotient classes,
sink classes, white-head class collection, previous outputs, or anchors.
Sources are independently enumerated as length-additive u*w_J*v with
u,v in the SAME maximal proper standard subgroup.  Closure is performed
on a two-length graph of raw pairs, including every intermediate head.
"""
from pathlib import Path
from itertools import product
import importlib.util
import json

module_path = Path(__file__).parents[1] / 'root_audit' / 'small_marked_closure.py'
spec = importlib.util.spec_from_file_location('root_cartan', module_path)
root = importlib.util.module_from_spec(spec)
spec.loader.exec_module(root)


def direct_sources(G):
    rank = G.r
    supports = [sum(1 << s for s in set(word)) for word in G.words]
    parabolics = [[w for w, support in enumerate(supports) if not support & ~J]
                  for J in range(1 << rank)]
    longest = [max(wj, key=G.length.__getitem__) for wj in parabolics]
    sources = [0] * len(G.mat)
    for omitted in range(rank):
        I = ((1 << rank) - 1) ^ (1 << omitted)
        for u in parabolics[I]:
            for seed in longest:
                h = seed
                for s in reversed(G.words[u]):
                    h = G.left[h][s]
                if G.length[h] != G.length[u] + G.length[seed]:
                    continue
                for v in parabolics[I]:
                    w = h
                    for s in G.words[v]:
                        w = G.right[w][s]
                    if G.length[w] == G.length[h] + G.length[v]:
                        sources[w] |= 1 << omitted
    return sources


def verify(cartan, order, name):
    G = root.RootGroup(cartan, order)
    sources = direct_sources(G)
    # Comparing two genuinely different source algorithms is an extra check.
    propagated, _ = G.sources()
    assert sources == propagated
    rank = G.r
    marks = list(range(1 << rank))
    colors = [tuple(sum(cartan[s][j] * ((p >> j) & 1)
                        for j in range(rank)) % 2 for s in range(rank))
              for p in marks]
    reflection = lambda p, s: p ^ (colors[p][s] << s)
    remaining = set(marks)
    orbits = []
    while remaining:
        start = min(remaining)
        orbit = {start}
        todo = [start]
        for p in todo:
            for s in range(rank):
                q = reflection(p, s)
                if q not in orbit:
                    orbit.add(q)
                    todo.append(q)
        remaining -= orbit
        orbits.append(sorted(orbit))
    pairs = [(p, q) for orbit in orbits for p, q in product(orbit, repeat=2)]

    # For these groups det(Cartan) is odd.  Equality of all root values
    # detects equality of full raw 2-torsion points, and M^t acts on them
    # as the inverse Weyl action.  Fixed points are the same for w,w^-1.
    # The binary Cartan map is invertible exactly when all marks have distinct colors.
    assert len(set(colors)) == len(marks)
    def moves_raw_mark(w, p):
        old = colors[p]
        new = tuple(sum(G.mat[w][i*rank+j] * old[i] for i in range(rank)) % 2
                    for j in range(rank))
        direct = p
        for s in reversed(G.words[w]):
            direct = reflection(direct, s)
        assert (new != old) == (direct != p)
        return new != old

    layers = []
    for length in range(max(G.length) + 1):
        states = [(w, p, q) for w in range(order)
                  if G.length[w] in (length, length + 1) for p, q in pairs]
        index = {state: i for i, state in enumerate(states)}
        parents = list(range(len(states)))
        anchors = set()
        def find(i):
            while i != parents[i]:
                parents[i] = parents[parents[i]]
                i = parents[i]
            return i
        def union(a, b):
            a, b = find(a), find(b)
            if a != b:
                parents[b] = a
        geometric = 0
        for idx, (w, p, q) in enumerate(states):
            if sources[w]:
                anchors.add(idx)
            if G.length[w] == length:
                white_descent = any((G.D[w] >> s & 1 and not colors[p][s]) or
                                    (G.E[w] >> s & 1 and not colors[q][s])
                                    for s in range(rank))
                if white_descent:
                    anchors.add(idx)
                if p == q and moves_raw_mark(w, p):
                    anchors.add(idx)
                    geometric += 1
            for s in range(rank):
                if G.D[w] >> s & 1 and colors[p][s]:
                    union(idx, index[w, reflection(p, s), q])
                if G.E[w] >> s & 1 and colors[q][s]:
                    union(idx, index[w, p, reflection(q, s)])
                if G.length[w] != length:
                    continue
                for h, white in ((G.left[w][s], not colors[p][s]),
                                 (G.right[w][s], not colors[q][s])):
                    if white and G.length[h] == length + 1:
                        union(idx, index[h, p, q])
        anchored = {find(i) for i in anchors}
        unresolved = [state for i, state in enumerate(states)
                      if G.length[state[0]] == length and find(i) not in anchored]
        assert not unresolved, (name, length, unresolved[:5])
        layers.append({'length': length,
                       'raw_target_states': sum(G.length[w] == length for w, p, q in states),
                       'raw_two_layer_states': len(states),
                       'diagonal_nonfix_anchors': geometric,
                       'unresolved_raw_targets': len(unresolved)})
    return {'type': name, 'weyl_order': order,
            'source_count_direct_endpoint_enumeration': sum(bool(s) for s in sources),
            'source_algorithm_matches': True,
            'raw_orbit_sizes': list(map(len, orbits)),
            'raw_target_total': sum(x['raw_target_states'] for x in layers),
            'all_layers_closed': True, 'layers': layers}


if __name__ == '__main__':
    answer = {'scope': 'Independent raw-pair closure control, conditional on the proved geometric rules.',
              'independence': 'Reuses Cartan Weyl tables only; direct same-I sources and raw two-layer graph replace all quotient-class closure logic.',
              'results': [verify([[2,-1],[-3,2]], 12, 'G2'),
                          verify([[2,-1,0,0],[-1,2,-1,0],[0,-2,2,-1],[0,0,-1,2]], 1152, 'F4')]}
    out = Path(__file__).with_name('small_closure_raw_states.json')
    out.write_text(json.dumps(answer, indent=2) + '\n')
    print(json.dumps({r['type']: {k:v for k,v in r.items() if k != 'layers'}
                      for r in answer['results']}, indent=2))
