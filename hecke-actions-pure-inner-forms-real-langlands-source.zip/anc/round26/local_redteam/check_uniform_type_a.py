"""Independent small-rank falsification attempt for the uniform gallery bound.

No prior root engines, masks, acceptance JSON, or census outputs are imported.
All Borels and simple graph fibers are represented by their actual SL_n
matrix-root spaces.  The test enumerates every reduced expression in A2/A3,
every nontrivial binary diagonal mark up to common sign, and every subword.
It verifies the virtual-cokernel calculation against the root-wise matching
matrix rank, not just the displayed skipped-letter identity.

This is a finite control, not a proof of sheaf-theoretic or derived claims.
"""

from collections import Counter
from functools import lru_cache
from itertools import permutations, product
from pathlib import Path
import json


def compose(p, q):
    return tuple(p[q[i]] for i in range(len(p)))


def simple(n, i):
    p = list(range(n))
    p[i], p[i + 1] = p[i + 1], p[i]
    return tuple(p)


@lru_cache(None)
def reduced_words(w):
    if all(w[i] == i for i in range(len(w))):
        return ((),)
    answers = []
    for i in range(len(w) - 1):
        if w[i] > w[i + 1]:
            u = compose(w, simple(len(w), i))
            answers.extend(word + (i,) for word in reduced_words(u))
    return tuple(answers)


def borel_roots(p):
    n = len(p)
    return {(p[i], p[j]) for i in range(n) for j in range(i + 1, n)}


def rank_over_q(matrix):
    """These matrices have entries -1,0,1; exact rational elimination."""
    from fractions import Fraction
    a = [list(map(Fraction, row)) for row in matrix]
    if not a:
        return 0
    pivot = 0
    for col in range(len(a[0])):
        k = next((k for k in range(pivot, len(a)) if a[k][col]), None)
        if k is None:
            continue
        a[pivot], a[k] = a[k], a[pivot]
        t = a[pivot][col]
        a[pivot] = [x / t for x in a[pivot]]
        for j in range(pivot + 1, len(a)):
            if a[j][col]:
                t = a[j][col]
                a[j] = [x - t * y for x, y in zip(a[j], a[pivot])]
        pivot += 1
        if pivot == len(a):
            break
    return pivot


def audit(n):
    identity = tuple(range(n))
    positive = borel_roots(identity)
    all_roots = {(a, b) for a in range(n) for b in range(n) if a != b}
    result = Counter()
    result['minimum_strict_gap'] = 10**6
    examples = []
    for tail in product((0, 1), repeat=n - 1):
        mark = (0,) + tail
        if not any(mark):
            continue
        even = {rho for rho in positive if mark[rho[0]] == mark[rho[1]]}
        odd = positive - even
        for w in permutations(range(n)):
            if all(mark[w[i]] == mark[i] for i in range(n)):
                continue
            for word in reduced_words(w):
                result['reduced_word_mark_pairs'] += 1
                for mask in product((False, True), repeat=len(word)):
                    prefixes = [identity]
                    tangent = []
                    quotient = []
                    v_roots = []
                    for i, applied in zip(word, mask):
                        a = prefixes[-1]
                        rho = (a[i], a[i + 1])
                        roots = borel_roots(a)
                        if applied:
                            tangent.append(rho)
                            quotient.append(rho)
                            roots.remove(rho)
                            prefixes.append(compose(a, simple(n, i)))
                        else:
                            tangent.append((rho[1], rho[0]))
                            prefixes.append(a)
                        v_roots.append(roots)
                    v = prefixes[-1]
                    if any(mark[v[i]] != mark[i] for i in range(n)):
                        continue
                    result['compatible_masks'] += 1
                    assert not all(mask)
                    inv = [v.index(i) for i in range(n)]
                    lam = tuple(n - 1 - inv[i] for i in range(n))
                    weight = lambda rho: lam[rho[0]] - lam[rho[1]]
                    orbit = {rho for rho in even if weight(rho) < 0}
                    deleted_cost = sum(-weight(rho) for rho in orbit)
                    normal_cost = sum(-weight(rho) for rho in tangent if weight(rho) < 0) - deleted_cost

                    # Actual root-by-root linear matching map L.  The Cartan
                    # block has cokernel dimension equal to the skipped count
                    # and weight zero; it cannot change the weight maximum.
                    cokernel = Counter()
                    kernel = Counter()
                    for rho in all_roots:
                        cols = [j for j, roots in enumerate(v_roots) if rho in roots]
                        rows = [j for j in range(len(word) - 1) if rho in borel_roots(prefixes[j + 1])]
                        matrix = []
                        for j in rows:
                            matrix.append([int(k == j) - int(k == j + 1) for k in cols])
                        if rho in odd:
                            matrix.append([int(k == 0) for k in cols])
                        r = rank_over_q(matrix)
                        if len(cols) - r:
                            kernel[rho] = len(cols) - r
                        if len(matrix) - r:
                            cokernel[rho] = len(matrix) - r

                    assert all(mult == 1 and rho in even and weight(rho) > 0 for rho, mult in kernel.items())
                    virtual = Counter(quotient)
                    virtual.subtract(Counter(even))
                    virtual.update(kernel)
                    assert all(virtual[rho] == cokernel[rho] for rho in all_roots)
                    actual_gain = sum(mult * -weight(rho) for rho, mult in cokernel.items() if weight(rho) < 0)
                    displayed_gain = sum(-weight((prefixes[j][i], prefixes[j][i + 1]))
                                         for j, i in enumerate(word)
                                         if mask[j] and weight((prefixes[j][i], prefixes[j][i + 1])) < 0) - deleted_cost
                    assert actual_gain == displayed_gain >= 0
                    skipped_cost = sum(weight((prefixes[j][i], prefixes[j][i + 1]))
                                       for j, i in enumerate(word)
                                       if not mask[j] and weight((prefixes[j][i], prefixes[j][i + 1])) > 0)
                    assert normal_cost - actual_gain == skipped_cost > 0
                    j = max(j for j, applied in enumerate(mask) if not applied)
                    rho = (prefixes[j][word[j]], prefixes[j][word[j] + 1])
                    assert weight(rho) > 0
                    result['minimum_strict_gap'] = min(result['minimum_strict_gap'], skipped_cost)
                    if len(examples) < 5 and deleted_cost and actual_gain:
                        examples.append({'mark': mark, 'word': tuple(i + 1 for i in word),
                                         'mask': mask, 'endpoint': tuple(i + 1 for i in v),
                                         'deleted_orbit_cost': deleted_cost,
                                         'normal_cost': normal_cost, 'exterior_gain': actual_gain,
                                         'strict_gap': skipped_cost})
    return {'type': f'A{n-1}', **result, 'examples_with_nonzero_orbit_and_exterior_cost': examples}


if __name__ == '__main__':
    result = {'purpose': 'Independent finite falsification control; not a proof certificate for the derived theorem.',
              'rank_convention': 'SL_n matrix-root matching over Q; central cocharacter translation is irrelevant.',
              'results': [audit(3), audit(4)]}
    dest = Path(__file__).with_name('uniform_type_a_control.json')
    dest.write_text(json.dumps(result, indent=2) + '\n')
    print(json.dumps(result, indent=2))
