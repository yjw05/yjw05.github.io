#include "../../round18/d5/e6_root_permutation.hpp"
#include <set>

// Reconstruct only the geometric seed ancestry.  The Weyl representation is
// the independent 72-root permutation model, not the candidate matrix engine.
// No candidate seed labels or seed flags are used until the final comparison.
struct Witness {
  int kind=-1, I=0, J=0, side=0, K=0, L=0, u=0, v=0;
  array<int,4> four{};
  vector<int> steps; // +s+1 means right multiplication, -s-1 means left.
};

int main(int argc,char**argv) {
  assert(argc==4);
  Group W;
  int th[6]={5,1,4,3,2,0};
  auto tm=[&](int m){int z=0;for(int s=0;s<6;s++)if(m>>s&1)z|=1<<th[s];return z;};
  vector<int> allowed,stable,w0(64),dem(W.N*64),ldem(W.N*64);
  vector<vector<int>> pw(64),components(64),mates(64);
  for(int m=0;m<64;m++) {
    int u=0;
    while(true){int s=0;for(;s<6;s++)if((m>>s&1)&&W.len[W.R[u][s]]>W.len[u])break;if(s==6)break;u=W.R[u][s];pw[m].push_back(s);}
    w0[m]=u;if(tm(m)==m)stable.push_back(m);
    int D=m|tm(m),seen=0;bool ok=true;
    for(int s=0;s<6;s++)if((D>>s&1)&&!(seen>>s&1)) {
      vector<int> q{s};seen|=1<<s;int block=0;
      for(size_t z=0;z<q.size();z++){int t=q[z];block|=1<<t;for(int j=0;j<6;j++)if(W.A[t][j]==-1&&(D>>j&1)&&!(seen>>j&1)){seen|=1<<j;q.push_back(j);}}
      components[m].push_back(block);
      if((m&block)!=0&&(m&block)!=block)ok=false;
    }
    if(ok)allowed.push_back(m);
  }
  assert(allowed.size()==32);
  for(int a:allowed)for(int b:allowed)if((a|tm(a))==(b|tm(b)))mates[a].push_back(b);
  for(int u=0;u<W.N;u++)for(int m=0;m<64;m++) {
    int a=u,b=u;
    for(int s:pw[m]){if(W.len[W.R[a][s]]>W.len[a])a=W.R[a][s];if(W.len[W.L[b][s]]>W.len[b])b=W.L[b][s];}
    dem[u*64+m]=a;ldem[u*64+m]=b;
  }
  vector<char> known(W.N),a(W.N);vector<Witness>wit(W.N);vector<array<int,4>>four(W.N);
  a[0]=1;for(auto&v:four)v.fill(-1);
  vector<int> fourcounts;
  for(int t=0;t<4;t++) {
    vector<char>b(W.N);vector<array<int,4>>next(W.N);
    for(int u=0;u<W.N;u++)if(a[u])for(int m=0;m<64;m++) {
      if((t==0||t==3)&&find(allowed.begin(),allowed.end(),m)==allowed.end())continue;
      int v=dem[u*64+m];if(!b[v]){b[v]=1;next[v]=four[u];next[v][t]=m;}
    }
    a.swap(b);four.swap(next);fourcounts.push_back(accumulate(a.begin(),a.end(),0));
  }
  int fourN=0;
  for(int u=0;u<W.N;u++)if(a[u]){known[u]=1;wit[u].kind=0;wit[u].four=four[u];fourN++;}
  vector<pair<string,int>>stages{{"four_parabolic_heads",fourN}};
  auto family=[&](int I,const vector<int>&Js,int kind) {
    assert(I!=63&&tm(I)==I);
    vector<char>seen(W.N);vector<int>root(W.N),parent(W.N,-1),edge(W.N);vector<int>q;
    for(int J:Js){int u=w0[J];if(!seen[u]){seen[u]=1;root[u]=J;q.push_back(u);}}
    for(size_t z=0;z<q.size();z++) {
      int u=q[z];
      if(!known[u]) {
        known[u]=1;wit[u].kind=kind;wit[u].I=I;wit[u].J=root[u];
        for(int v=u;parent[v]!=-1;v=parent[v])wit[u].steps.push_back(edge[v]);
        reverse(wit[u].steps.begin(),wit[u].steps.end());
      }
      for(int s=0;s<6;s++)if(I>>s&1)for(int side=0;side<2;side++) {
        int v=side?W.L[u][s]:W.R[u][s];
        if(W.len[v]>W.len[u]&&!seen[v]){seen[v]=1;root[v]=root[u];parent[v]=u;edge[v]=side?-s-1:s+1;q.push_back(v);}
      }
    }
  };
  for(int I:stable)if(I!=63){vector<int>Js;for(int J=0;J<64;J++)if(!(J&tm(J)&~I))Js.push_back(J);family(I,Js,1);}
  stages.push_back({"plus_same_I_oldcompression",accumulate(known.begin(),known.end(),0)});
  vector<array<int,7>>events;vector<int>passadds;
  auto close=[&](int stage) {
    while(true) {
      vector<char>good(W.N);for(int u=0;u<W.N;u++){good[u]=known[u];for(int v:W.low[u])good[u]&=good[v];}
      int adds=0;
      for(int w=0;w<W.N;w++)if(!known[w]) {
        bool done=false;
        for(int side=0;side<2&&!done;side++)for(int K:allowed)if(K&&!(K&~(side?W.dl[w]:W.dr[w]))) {
          int u=w;for(int s:pw[K])u=side?W.L[u][s]:W.R[u][s];
          assert(W.len[u]+W.len[w0[K]]==W.len[w]);
          for(int L:mates[K])if(L!=K) {
            int v=side?ldem[u*64+L]:dem[u*64+L];
            if(!good[v])continue;
            // Independently check the full Bruhat lower ideal, not just covers.
            for(int z=0;z<W.N;z++)if(W.below(z,v))assert(known[z]);
            known[w]=1;wit[w].kind=2;wit[w].side=side;wit[w].K=K;wit[w].L=L;wit[w].u=u;wit[w].v=v;
            events.push_back({stage,w,side,K,L,u,v});adds++;done=true;break;
          }
          if(done)break;
        }
      }
      passadds.push_back(adds);if(!adds)break;
    }
  };
  close(0);stages.push_back({"after_first_safe_closure",accumulate(known.begin(),known.end(),0)});
  for(int J:{33,20,2,8})family(63^J,{J},3);
  stages.push_back({"plus_stable_orbit_omissions",accumulate(known.begin(),known.end(),0)});
  close(1);stages.push_back({"after_second_safe_closure",accumulate(known.begin(),known.end(),0)});
  assert(stages.back().second==26242);
  vector<char>expected(W.N);ifstream in(argv[1]);int x;while(in>>x){assert(0<=x&&x<W.N);expected[x]=1;}assert(known==expected);
  // Replay every recorded explicit source head, independently of discovery.
  int sourcecount=0;
  for(int u=0;u<W.N;u++)if(known[u]&&wit[u].kind!=2) {
    auto&r=wit[u];int v=0;
    if(r.kind==0){for(int m:r.four)v=dem[v*64+m];}
    else {v=w0[r.J];for(int s:r.steps){assert(r.I>>(abs(s)-1)&1);int z=s>0?W.R[v][s-1]:W.L[v][-s-1];assert(W.len[z]==W.len[v]+1);v=z;}}
    assert(v==u);sourcecount++;
  }
  ofstream cert(argv[3]);cert<<"# head kind four0 four1 four2 four3 I J side K L u v steps...\n";
  for(int u=0;u<W.N;u++)if(known[u]){auto&r=wit[u];cert<<u<<" "<<r.kind;for(int m:r.four)cert<<" "<<m;cert<<" "<<r.I<<" "<<r.J<<" "<<r.side<<" "<<r.K<<" "<<r.L<<" "<<r.u<<" "<<r.v;for(int s:r.steps)cert<<" "<<s;cert<<"\n";}
  ofstream out(argv[2]);out<<"{\n\"passed\":true,\n\"method\":\"Independent 72-root permutation group; reconstruct every source family and safe lower-ideal closure before exact comparison with original base labels.\",\n\"weyl_order\":51840,\n\"admissible_endpoint_masks\":[";
  for(size_t i=0;i<allowed.size();i++){if(i)out<<",";out<<allowed[i];}out<<"],\n\"four_stage_counts\":[";
  for(size_t i=0;i<fourcounts.size();i++){if(i)out<<",";out<<fourcounts[i];}out<<"],\n\"stages\":[";
  for(size_t i=0;i<stages.size();i++){if(i)out<<",";out<<"[\""<<stages[i].first<<"\","<<stages[i].second<<"]";}out<<"],\n\"safe_closure_pass_additions\":[";
  for(size_t i=0;i<passadds.size();i++){if(i)out<<",";out<<passadds[i];}out<<"],\n\"explicit_source_heads\":"<<sourcecount<<",\n\"safe_closure_events\":"<<events.size()<<",\n\"final_labels\":26242,\n\"exact_original_base_match\":true,\n\"safe_events\":[";
  for(size_t i=0;i<events.size();i++){if(i)out<<",";out<<"[";for(int j=0;j<7;j++){if(j)out<<",";out<<events[i][j];}out<<"]";}out<<"]\n}\n";
  cerr<<"PASS outer E6 source ancestry: "<<sourcecount<<" explicit heads + "<<events.size()<<" safe transfers = 26242\n";
}
