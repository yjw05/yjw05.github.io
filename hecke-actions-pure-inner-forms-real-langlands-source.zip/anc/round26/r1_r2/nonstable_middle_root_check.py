#!/usr/bin/env python3
"""Exact root audit for arbitrary (including theta-nonstable) middle J.

This checks root identities and induction decrease only.  It does not
certify derived incidence, duality, or ordinary vanishing.
No earlier Weyl or finite-certificate implementation is imported.
"""
from collections import Counter, deque
from itertools import combinations
import hashlib
import json
from pathlib import Path


def root_check(name, edges, theta):
    n = len(theta)
    cartan = [[2 * (i == j) for j in range(n)] for i in range(n)]
    for i, j in edges:
        cartan[i][j] = cartan[j][i] = -1
    unit = tuple(tuple(int(i == j) for i in range(n)) for j in range(n))

    def reflect(root, i):
        result = list(root)
        result[i] -= sum(cartan[i][j] * root[j] for j in range(n))
        return tuple(result)

    roots = set(unit)
    pending = deque(unit)
    while pending:
        root = pending.popleft()
        for i in range(n):
            image = reflect(root, i)
            if image not in roots:
                roots.add(image)
                pending.append(image)
    positive = {r for r in roots if all(c >= 0 for c in r)}
    assert len(roots) == 2 * len(positive)

    def apply(w, r):
        return tuple(sum(r[j] * w[j][i] for j in range(n)) for i in range(n))

    def right(w, i):
        return tuple(apply(w, reflect(unit[j], i)) for j in range(n))

    def left(w, i):
        return tuple(reflect(w[j], i) for j in range(n))

    def permute(r):
        result = [0] * n
        for i in range(n):
            result[theta[i]] = r[i]
        return tuple(result)

    subsets = [frozenset(c) for size in range(n + 1)
               for c in combinations(range(n), size)]
    subroots = {s: {r for r in positive if all(i in s or c == 0
                                               for i, c in enumerate(r))}
                for s in subsets}
    groups = {}
    for s in subsets:
        elements = {unit}
        queue = deque([unit])
        while queue:
            w = queue.popleft()
            for i in s:
                image = right(w, i)
                if image not in elements:
                    elements.add(image)
                    queue.append(image)
        groups[s] = elements
    lengths = {w: sum(apply(w, r) not in positive for r in positive)
               for w in groups[frozenset(range(n))]}
    negative = lambda s: {tuple(-x for x in r) for r in s}
    stream = []
    counts = Counter()
    max_core = 0
    for I in subsets:
        if len(I) == n or {theta[i] for i in I} != I:
            continue
        phi_I = subroots[I]
        for J in subsets:
            H = I & J
            phi_J, phi_H = subroots[J], subroots[H]
            p_J = positive | negative(phi_J)
            nonstable_J = {theta[j] for j in J} != J
            for w in groups[J]:
                if any(lengths[left(w, h)] < lengths[w] or
                       lengths[right(w, h)] < lengths[w] for h in H):
                    continue
                counts['minimal_middle_positions'] += 1
                assert all(lengths[left(w, i)] > lengths[w] and
                           lengths[right(w, i)] > lengths[w] for i in I)
                if any(permute(w[i]) != w[theta[i]] for i in range(n)):
                    counts['not_theta_fixed_positions'] += 1
                    continue
                counts['theta_fixed_positions'] += 1
                counts['nonstable_J_theta_fixed_positions'] += nonstable_J
                inverse_on_roots = {apply(w, r): r for r in roots}
                image_I = {apply(w, r) for r in phi_I}
                image_H = {apply(w, r) for r in phi_H}
                phi_K = phi_I & image_I
                K = frozenset(i for i in I if unit[i] in phi_K)
                assert phi_K == subroots[K]
                assert {theta[i] for i in K} == K
                H_K = H & K
                assert K <= I and len(phi_K) < len(positive)
                max_core = max(max_core, len(phi_K))
                inversions = {r for r in positive if inverse_on_roots[r]
                              not in positive}
                P = positive - (phi_I | image_I | inversions)
                E1 = phi_I - (phi_H | phi_K)
                E2 = image_I - (image_H | phi_K)
                U = positive - (phi_J | phi_K)
                M = phi_J - (phi_H | image_H | inversions)
                assert not (P & E1 or P & E2 or E1 & E2 or U & M)
                assert P | E1 | E2 == U | M
                R = (positive - inversions) | negative(phi_K)
                S = R & p_J
                expected_zero = subroots[H_K]
                assert (S & negative(phi_K)) == negative(expected_zero)

                def weight(r):
                    ir = inverse_on_roots[r]
                    return sum(r[i] + ir[i] for i in range(n) if i not in I)

                assert all(weight(r) > 0 for r in P | E1 | E2 | U | M)
                assert all(weight(r) >= 0 for r in R)
                assert {r for r in R if weight(r) == 0} == phi_K | negative(phi_K)
                tangent_one = negative(phi_J - phi_H)
                tangent_two = {apply(w, r) for r in tangent_one}
                orbit_tangent = p_J - S
                normal = Counter(tangent_one) + Counter(tangent_two)
                normal.subtract(Counter(orbit_tangent))
                assert all(v >= 0 for v in normal.values())
                assert +normal == Counter(negative(M))
                a, i, j, h, k, hk, ell = (len(positive), len(phi_I),
                    len(phi_J), len(phi_H), len(phi_K), len(subroots[H_K]), lengths[w])
                assert len(P) == a - 2 * i + k - ell
                assert len(E1) == len(E2) == i - h - k + hk
                assert len(U) == a - j - k + hk
                assert len(M) == j - 2 * h + hk - ell
                stream.append((tuple(sorted(I)), tuple(sorted(J)), w,
                               tuple(sorted(K)), tuple(sorted(H_K)),
                               len(P), len(E1), len(E2), len(U), len(M)))
    encoded = json.dumps(sorted(stream), separators=(',', ':')).encode()
    return {
        'type': name, 'rank': n, 'positive_roots': len(positive),
        'weyl_order': len(lengths), 'counts': dict(counts),
        'maximum_common_core_positive_roots': max_core,
        'complete_stream_sha256': hashlib.sha256(encoded).hexdigest(),
        'passed': True,
    }


if __name__ == '__main__':
    result = {
        'scope': 'Root identities and strict signs only; no derived vanishing claim.',
        'cases': [
            root_check('outer A2', [(0, 1)], [1, 0]),
            root_check('outer A3', [(0, 1), (1, 2)], [2, 1, 0]),
            root_check('outer A4', [(0, 1), (1, 2), (2, 3)], [3, 2, 1, 0]),
            root_check('outer A5', [(0, 1), (1, 2), (2, 3), (3, 4)], [4, 3, 2, 1, 0]),
            root_check('outer D4', [(0, 1), (1, 2), (1, 3)], [0, 1, 3, 2]),
        ]
    }
    target = Path(__file__).with_suffix('.json')
    target.write_text(json.dumps(result, ensure_ascii=False, indent=2) + '\n')
    print(json.dumps(result, ensure_ascii=False, indent=2))
