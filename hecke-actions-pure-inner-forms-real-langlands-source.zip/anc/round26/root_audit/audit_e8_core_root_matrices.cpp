// Small independent L64 equality-tree verifier. It reads no E7/E8 group
// arrays, source mask, L8 table, or generator ColorParts implementation.
#define E8_RAW_AUDIT_LIBRARY
#include "audit_e8_low_terminal_certificate.cpp"
#include <unordered_map>
#include <set>
using Matrix8=array<int8_t,64>;
using Root8=array<int8_t,8>;
struct RootModel{
 int A[8][8]{};vector<Root8>positive;
 RootModel(){
  for(int i=0;i<8;i++)A[i][i]=2;for(auto[i,j]:vector<pair<int,int>>{{0,2},{2,3},{1,3},{3,4},{4,5},{5,6},{6,7}})A[i][j]=A[j][i]=-1;
  set<Root8>seen;vector<Root8>todo;for(int i=0;i<8;i++){Root8 a{};a[i]=1;seen.insert(a);todo.push_back(a);}
  for(size_t p=0;p<todo.size();p++)for(int s=0;s<8;s++){Root8 b=todo[p];int t=0;for(int j=0;j<8;j++)t+=A[s][j]*b[j];b[s]-=t;if(seen.insert(b).second)todo.push_back(b);}
  assert(todo.size()==240);for(auto a:todo)if(all_of(a.begin(),a.end(),[](int x){return x>=0;}))positive.push_back(a);assert(positive.size()==120);
 }
 Matrix8 right(const Matrix8&m,int s)const{Matrix8 z=m;for(int j=0;j<8;j++)if(A[s][j])for(int i=0;i<8;i++)z[i*8+j]-=A[s][j]*m[i*8+s];return z;}
 Matrix8 left(const Matrix8&m,int s)const{Matrix8 z=m;for(int j=0;j<8;j++){int q=0;for(int i=0;i<8;i++)q+=A[s][i]*m[i*8+j];z[s*8+j]-=q;}return z;}
 Matrix8 element(const string&w)const{Matrix8 z{};for(int i=0;i<8;i++)z[8*i+i]=1;for(char c:w){assert('1'<=c&&c<='8');z=right(z,c-'1');}return z;}
 int length(const Matrix8&m)const{int n=0;for(auto a:positive){bool negative=true;for(int i=0;i<8;i++){int q=0;for(int j=0;j<8;j++)q+=m[8*i+j]*a[j];if(q>0)negative=false;}n+=negative;}return n;}
 int desc(const Matrix8&m)const{int D=0;for(int s=0;s<8;s++){bool negative=true;for(int i=0;i<8;i++)if(m[8*i+s]>0)negative=false;D|=negative<<s;}return D;}
};
struct Element{Matrix8 m;int len,D,E;bool involution;};
int main(){
 string base="round21/computation/";RootModel G;RawParts P;unordered_map<uint32_t,Element>elements;
 ifstream words(base+"e8_L64_core_words.txt");size_t n;words>>n;set<Matrix8>distinct;
 for(size_t i=0;i<n;i++){uint32_t code;string word;words>>code>>word;assert(words);auto m=G.element(word);string rev=word;reverse(rev.begin(),rev.end());auto inverse=G.element(rev);int l=G.length(m);assert(l==(int)word.size()&&(l==64||l==65));assert(distinct.insert(m).second);assert(elements.emplace(code,Element{m,l,G.desc(inverse),G.desc(m),m==inverse}).second);}
 unordered_map<uint64_t,uint32_t>id;vector<uint64_t>keys;ifstream in(base+"e8_L64_core_keys.bin",ios::binary);uint64_t k;
 while(in.read((char*)&k,8)){auto&x=elements.at(uint32_t(k));int a=uint8_t(k>>32),b=uint8_t(k>>40);assert(x.len==64);assert(P.rep[x.D][a]==a&&P.rep[x.E][b]==b);
  for(int s=0;s<8;s++)for(int j=0;j<4;j++){if(x.D>>s&1)assert(!(P.classes[x.D][a][j]&P.whitebits[s][j]));if(x.E>>s&1)assert(!(P.classes[x.E][b][j]&P.whitebits[s][j]));}
  for(int c:{a,b}){int sz=0;for(auto v:P.classes[255][P.rep[255][c]])sz+=__builtin_popcountll(v);assert(sz==135);}
  assert(id.emplace(k,keys.size()).second);keys.push_back(k);
 }assert(in.eof()&&in.gcount()==0&&keys.size()==35419);
 auto adjacent=[&](uint64_t parent,uint64_t head){auto&p=elements.at(uint32_t(parent));auto&h=elements.at(uint32_t(head));int a=uint8_t(parent>>32),b=uint8_t(parent>>40),aa=uint8_t(head>>32),bb=uint8_t(head>>40);if(p.len!=64||h.len!=65||P.rep[h.D][aa]!=aa||P.rep[h.E][bb]!=bb)return false;
  for(int s=0;s<8;s++){if(!(p.D>>s&1)&&G.left(p.m,s)==h.m&&P.meet(p.D,a,h.D,aa,s)&&P.meet(p.E,b,h.E,bb))return true;if(!(p.E>>s&1)&&G.right(p.m,s)==h.m&&P.meet(p.D,a,h.D,aa)&&P.meet(p.E,b,h.E,bb,s))return true;}return false;};
 vector<uint32_t>uf(keys.size());for(uint32_t i=0;i<uf.size();i++)uf[i]=i;
 auto find=[&](uint32_t x){while(uf[x]!=x){uf[x]=uf[uf[x]];x=uf[x];}return x;};
 ifstream forest(base+"e8_L64_core_forest.bin",ios::binary);uint64_t row[4],count=0;
 while(forest.read((char*)row,sizeof(row))){assert(row[0]==0&&id.count(row[1])&&id.count(row[2]));assert(adjacent(row[1],row[3])&&adjacent(row[2],row[3]));auto a=find(id.at(row[1])),b=find(id.at(row[2]));assert(a!=b);uf[b]=a;count++;}
 assert(forest.eof()&&forest.gcount()==0&&count+1==keys.size());for(uint32_t i=0;i<keys.size();i++)assert(find(i)==find(0));
 auto&chosen=elements.at(359034028);assert(chosen.len==64&&chosen.D==16&&chosen.E==16&&chosen.involution);
 assert(P.black[5]==16&&P.raw_of_black[16]==5&&id.count(359034028ULL|(16ULL<<32)|(16ULL<<40)));
 ofstream out("round26/root_audit/e8_core_root_matrix_replay.json");out<<"{\"status\":\"PASS\",\"scope\":\"Equality of all core scalar detectors conditional on ordinary lengths below64; not vanishing by itself\",\"states\":"<<keys.size()<<",\"tree_edges\":"<<count<<",\"independent_root_matrices\":"<<elements.size()<<",\"all_lengths_and_descents_recomputed\":true,\"full_raw_mark_partitions\":true,\"no_full_group_arrays_read\":true,\"chosen_code\":359034028,\"chosen_is_involution\":true,\"chosen_DL_DR\":16,\"chosen_left_right_raw_mark\":5,\"chosen_left_right_black_color\":16,\"chosen_state_in_verified_tree\":true}\n";
 cerr<<"ROOT MATRIX CORE AUDIT PASS "<<keys.size()<<" states "<<count<<" tree edges\n";
}
