#!/usr/bin/env python3
"""Independent root/mark check for the geometric E8 anchor; no group table."""
from fractions import Fraction
from pathlib import Path
import json

r = 8
A = [[2*int(i == j) for j in range(r)] for i in range(r)]
for i, j in [(0, 2), (2, 3), (1, 3), (3, 4), (4, 5), (5, 6), (6, 7)]:
    A[i][j] = A[j][i] = -1
roots = {tuple(int(i == j) for i in range(r)) for j in range(r)}
todo = list(roots)
for x in todo:
    for s in range(r):
        y = list(x)
        y[s] -= sum(A[j][s]*x[j] for j in range(r))
        y = tuple(y)
        if y not in roots:
            roots.add(y)
            todo.append(y)
assert len(roots) == 240
positive = sorted(x for x in roots if all(t >= 0 for t in x))
word = '5423143565423143546765423143542654787654231435426543176542348765'
assert len(word) == 64
M = [[int(i == j) for j in range(r)] for i in range(r)]
for c in word:
    s = int(c)-1
    M = [[M[i][j] - A[j][s]*M[i][s] for j in range(r)] for i in range(r)]
act = lambda a: tuple(sum(M[i][j]*a[j] for j in range(r)) for i in range(r))
assert sum(all(t <= 0 for t in act(a)) for a in positive) == 64
assert all(sum(M[i][k]*M[k][j] for k in range(r)) == int(i == j)
           for i in range(r) for j in range(r))
# Since w is an involution, these right descents are also the left descents.
descents = [i+1 for i in range(r) if all(M[j][i] <= 0 for j in range(r))]
assert descents == [5]
phase = [0, 0, 0, 0, 0, 2, 0, 2]
image = phase[:]
for c in reversed(word):
    s = int(c)-1
    image[s] = (image[s] - sum(A[s][j]*image[j] for j in range(r))) % 4
assert image == [0, 0, 2, 2, 0, 0, 2, 2]
assert image != phase
colors = [sum(A[i][j]*phase[j] for j in range(r)) % 4 for i in range(r)]
assert colors == [0, 0, 0, 0, 2, 0, 0, 0]
Kpos = [a for a in positive if sum(a[i]*colors[i] for i in range(r)) % 4 == 0]
assert len(Kpos) == 56
Kset = set(Kpos)
simple = [a for a in Kpos if not any(tuple(a[i]-b[i] for i in range(r)) in Kset for b in Kpos)]
assert len(simple) == 8
KA = [[sum(x[i]*A[i][j]*y[j] for i in range(r) for j in range(r)) for y in simple] for x in simple]
degree = sorted(sum(x == -1 for x in row) for row in KA)
assert degree == [1, 1, 1, 2, 2, 2, 2, 3]
# Remove the unique trivalent node. In D8 the three arms have sizes 1, 1, 5.
neighbors = [{j for j, value in enumerate(row) if value == -1} for row in KA]
branch = next(i for i, adj in enumerate(neighbors) if len(adj) == 3)
seen = {branch}
arms = []
for start in sorted(neighbors[branch]):
    component = set()
    stack = [start]
    while stack:
        j = stack.pop()
        if j in seen:
            continue
        seen.add(j)
        component.add(j)
        stack.extend(neighbors[j] - seen)
    arms.append(len(component))
assert len(seen) == r and sorted(arms) == [1, 1, 5]
Q = [[Fraction(v) for v in row] for row in KA]
det = Fraction(1)
for i in range(r):
    p = next(j for j in range(i, r) if Q[j][i])
    if p != i:
        Q[i], Q[p] = Q[p], Q[i]
        det = -det
    d = Q[i][i]
    det *= d
    for j in range(i+1, r):
        q = Q[j][i]/d
        for k in range(i, r):
            Q[j][k] -= q*Q[i][k]
assert det == 4
assert all(KA[i][i] == 2 and all(KA[i][j] in (0,-1) for j in range(r) if j != i) for i in range(r))
result = {'status': 'PASS', 'word': word, 'length': 64, 'involution': True,
          'left_and_right_descents': descents, 'centralizer_diagram_arms': sorted(arms),
          'original_raw_phase_mod4': phase, 'word_image_raw_phase_mod4': image,
          'simple_root_phase_mod4': colors, 'centralizer_positive_roots': 56,
          'centralizer_simple_roots': simple, 'centralizer_cartan': KA,
          'centralizer_cartan_determinant': 4, 'centralizer_type': 'D8',
          'w_not_in_mark_stabilizer': True,
          'meaning': 'Checks the exact hypothesis of the uniform geometric anchor, not its geometric proof'}
Path(__file__).with_name('e8_geometric_anchor.json').write_text(json.dumps(result, indent=2)+'\n')
print('E8 anchor PASS: length 64, actual phase moved, connected root centralizer D8')
