#!/usr/bin/env python3
"""Exact small-rank closure from same-I sources and actual raw coroot marks.

No Kazhdan--Lusztig values, former source arrays, or previous closure outputs
are imported.  The mathematical input is the ordinary same-I source theorem,
ordinary completed positive decompositions, and marked panel identities.
The code retains unanchored equality components as unresolved.
"""
from collections import defaultdict, deque
from pathlib import Path
import argparse
import hashlib
import json


class RootGroup:
    def __init__(self, cartan, expected):
        self.A = cartan
        self.r = r = len(cartan)
        unit = tuple(int(i == j) for i in range(r) for j in range(r))
        self.mat = [unit]
        self.ids = {unit: 0}
        self.words = [()]
        self.length = [0]
        self.right = []
        for k, mat in enumerate(self.mat):
            row = []
            for s in range(r):
                # s(alpha_j) = alpha_j - A[j,s] alpha_s.
                z = tuple(mat[i*r+j] - cartan[j][s]*mat[i*r+s]
                          for i in range(r) for j in range(r))
                if z not in self.ids:
                    self.ids[z] = len(self.mat)
                    self.mat.append(z)
                    self.words.append(self.words[k] + (s,))
                    self.length.append(self.length[k] + 1)
                row.append(self.ids[z])
            self.right.append(row)
        assert len(self.mat) == expected
        self.left = []
        for mat in self.mat:
            row = []
            for s in range(r):
                z = list(mat)
                for j in range(r):
                    z[s*r+j] -= sum(cartan[i][s]*mat[i*r+j] for i in range(r))
                row.append(self.ids[tuple(z)])
            self.left.append(row)
        self.D = [sum(1 << s for s in range(r)
                      if self.length[self.left[w][s]] < self.length[w])
                  for w in range(expected)]
        self.E = [sum(1 << s for s in range(r)
                      if self.length[self.right[w][s]] < self.length[w])
                  for w in range(expected)]
        roots = {tuple(int(i == j) for i in range(r)) for j in range(r)}
        todo = list(roots)
        for a in todo:
            for s in range(r):
                b = list(a)
                b[s] -= sum(cartan[j][s]*a[j] for j in range(r))
                b = tuple(b)
                if b not in roots:
                    roots.add(b)
                    todo.append(b)
        pos = [a for a in roots if all(x >= 0 for x in a)]
        assert len(roots) == 2*len(pos)
        # Check BFS lengths against the intrinsic inversion count.
        for w, mat in enumerate(self.mat):
            inv = 0
            for a in pos:
                b = [sum(mat[i*r+j]*a[j] for j in range(r)) for i in range(r)]
                assert all(x >= 0 for x in b) or all(x <= 0 for x in b)
                inv += all(x <= 0 for x in b)
            assert inv == self.length[w]
            for s in range(r):
                assert self.left[self.left[w][s]][s] == w
                assert self.right[self.right[w][s]][s] == w
                assert abs(self.length[self.left[w][s]] - inv) == 1
                assert abs(self.length[self.right[w][s]] - inv) == 1
                for t in range(r):
                    assert self.left[self.right[w][t]][s] == self.right[self.left[w][s]][t]
        self.positive_roots = len(pos)

    def sources(self):
        r = self.r
        longest = []
        for J in range(1 << r):
            w = 0
            while True:
                nxt = next((self.right[w][s] for s in range(r)
                            if J >> s & 1 and self.length[self.right[w][s]] > self.length[w]), None)
                if nxt is None:
                    break
                w = nxt
            assert self.E[w] & J == J
            longest.append(w)
        source = [0]*len(self.mat)
        all_families = (1 << r) - 1
        for w in longest:
            source[w] = all_families
        # Each bit remembers the omitted node, hence the SAME proper I
        # containing both endpoint words.  Never propagate across that node.
        for w in sorted(range(len(self.mat)), key=self.length.__getitem__):
            for s in range(r):
                bits = source[w] & ~(1 << s)
                if not bits:
                    continue
                for v in (self.left[w][s], self.right[w][s]):
                    if self.length[v] > self.length[w]:
                        source[v] |= bits
        # Independent predecessor-gather reconstruction.
        gather = [0]*len(self.mat)
        for w in longest:
            gather[w] = all_families
        for w in sorted(range(len(self.mat)), key=self.length.__getitem__):
            for s in range(r):
                for v in (self.left[w][s], self.right[w][s]):
                    if self.length[v] < self.length[w]:
                        gather[w] |= gather[v] & ~(1 << s)
        assert gather == source
        return source, longest


class Marks:
    def __init__(self, G):
        r = G.r
        self.n = 1 << r
        self.color = []
        self.action = []
        for p in range(self.n):
            black = sum((sum(G.A[s][j]*((p >> j) & 1) for j in range(r)) % 2) << s
                        for s in range(r))
            self.color.append(black)
            self.action.append([p ^ (((black >> s) & 1) << s) for s in range(r)])
        self.rep = []
        self.classes = []
        self.sink = []
        for D in range(1 << r):
            rep = [-1]*self.n
            parts = {}
            for p in range(self.n):
                if rep[p] >= 0:
                    continue
                cell = {p}
                queue = [p]
                for q in queue:
                    for s in range(r):
                        if D >> s & 1:
                            nxt = self.action[q][s]
                            if nxt not in cell:
                                cell.add(nxt)
                                queue.append(nxt)
                for q in cell:
                    rep[q] = p
                parts[p] = sorted(cell)
            self.rep.append(rep)
            self.classes.append(parts)
            self.sink.append({p: all((self.color[q] & D) == D for q in cell)
                              for p, cell in parts.items()})
        self.orbits = list(self.classes[-1].values())


def closure(G, P, source, orbit, diagonal_standard_anchors=False):
    rows = []
    for L in range(max(G.length)+1):
        targets = []
        for w in range(len(G.mat)):
            if G.length[w] != L or source[w]:
                continue
            aa = sorted({P.rep[G.D[w]][p] for p in orbit if P.sink[G.D[w]][P.rep[G.D[w]][p]]})
            bb = sorted({P.rep[G.E[w]][p] for p in orbit if P.sink[G.E[w]][P.rep[G.E[w]][p]]})
            targets.extend((w, a, b) for a in aa for b in bb)
        ids = {x: i for i, x in enumerate(targets)}
        uf = list(range(len(targets)))
        boundary = [False]*len(targets)
        geometric = []
        if diagonal_standard_anchors:
            for idx, (w, a, b) in enumerate(targets):
                for p in sorted(set(P.classes[G.D[w]][a]) & set(P.classes[G.E[w]][b])):
                    image = p
                    for s in reversed(G.words[w]):
                        image = P.action[image][s]
                    if image != p:
                        boundary[idx] = True
                        geometric.append({'target_id': idx, 'word': [s+1 for s in G.words[w]],
                                          'diagonal_mark': p, 'image_mark': image,
                                          'left_class': a, 'right_class': b})
                        break

        def find(x):
            while uf[x] != x:
                uf[x] = uf[uf[x]]
                x = uf[x]
            return x

        def join(x, y):
            a, b = find(x), find(y)
            if a != b:
                uf[b] = a

        heads = defaultdict(set)
        for idx, (w, a, b) in enumerate(targets):
            for s in range(G.r):
                for left in (True, False):
                    h = (G.left if left else G.right)[w][s]
                    if G.length[h] != L+1:
                        continue
                    for x in P.classes[G.D[w]][a]:
                        if left and P.color[x] >> s & 1:
                            continue
                        for y in P.classes[G.E[w]][b]:
                            if not left and P.color[y] >> s & 1:
                                continue
                            heads[h, P.rep[G.D[h]][x], P.rep[G.E[h]][y]].add(idx)
        ordinary_heads = 0
        edge_rows = []
        for (h, a, b), incident in sorted(heads.items()):
            incident = sorted(incident)
            for v in incident[1:]:
                join(incident[0], v)
                edge_rows.append([0, incident[0], v, h, a, b])
            anchored = bool(source[h])
            witness = None
            if not anchored:
                for s in range(G.r):
                    for left in (True, False):
                        w = (G.left if left else G.right)[h][s]
                        if G.length[w] != L:
                            continue
                        for x in P.classes[G.D[h]][a]:
                            if left and P.color[x] >> s & 1:
                                continue
                            for y in P.classes[G.E[h]][b]:
                                if not left and P.color[y] >> s & 1:
                                    continue
                                wa, wb = P.rep[G.D[w]][x], P.rep[G.E[w]][y]
                                if source[w] or not (P.sink[G.D[w]][wa] and P.sink[G.E[w]][wb]):
                                    anchored = True
                                    witness = [w, wa, wb, s, left, x, y]
                                else:
                                    # Every genuine nonsource sink predecessor
                                    # must already be in the exhaustive target set.
                                    assert (w, wa, wb) in ids
                                    assert ids[w, wa, wb] in incident
            if anchored:
                ordinary_heads += 1
                boundary[incident[0]] = True
                edge_rows.append([1, incident[0], h, a, b, witness])
        anchored_components = {find(i) for i, b in enumerate(boundary) if b}
        bad = [targets[i] for i in range(len(targets)) if find(i) not in anchored_components]
        digest = hashlib.sha256(json.dumps([targets, edge_rows], separators=(',', ':')).encode()).hexdigest()
        rows.append({'length': L, 'sink_targets': len(targets), 'heads': len(heads),
                     'anchored_heads': ordinary_heads, 'unresolved_states': len(bad),
                     'diagonal_standard_anchors': geometric,
                     'target_and_edge_sha256': digest})
        if bad:
            return {'status': 'UNRESOLVED', 'orbit': orbit, 'layers': rows,
                    'first_unresolved': [{'word': [s+1 for s in G.words[w]], 'left_mark': a,
                                          'right_mark': b} for w, a, b in bad[:20]]}
    return {'status': 'CLOSED', 'orbit': orbit, 'layers': rows}


def run(name, cartan, expected, require_marks):
    G = RootGroup(cartan, expected)
    source, longest = G.sources()
    ans = {'type': name, 'weyl_order': len(G.mat), 'positive_roots': G.positive_roots,
           'cartan_rows_root_columns_coroot': cartan,
           'same_I_source_labels': sum(bool(x) for x in source),
           'source_scatter_gather_identical': True,
           'source_hash': hashlib.sha256(bytes(source)).hexdigest(),
           'parabolic_longest_indices': longest}
    if require_marks:
        P = Marks(G)
        ans['raw_coroot_2_torsion_marks'] = P.n
        ans['raw_orbit_sizes'] = [len(x) for x in P.orbits]
        ans['blocks_without_new_geometric_anchor'] = [closure(G, P, source, orb) for orb in P.orbits]
        ans['blocks'] = [closure(G, P, source, orb, True) for orb in P.orbits]
        ans['new_geometric_input'] = 'All-degree diagonal standard vanishing for w moving the full raw mark; Rouquier transfer uses shorter-label ordinarity only'
        ans['status'] = 'CLOSED' if all(x['status'] == 'CLOSED' for x in ans['blocks']) else 'UNRESOLVED'
    else:
        ans['status'] = 'ALL_LABELS_ARE_SOURCES' if all(source) else 'SOURCE_COVERAGE_INCOMPLETE'
    return ans


if __name__ == '__main__':
    parser = argparse.ArgumentParser()
    parser.add_argument('--e6', action='store_true', help='Also regenerate E6 directly from its Cartan matrix')
    args = parser.parse_args()
    cases = [('B2_C2', [[2, -1], [-2, 2]], 8, False),
             ('G2', [[2, -1], [-3, 2]], 12, True),
             ('F4', [[2, -1, 0, 0], [-1, 2, -1, 0],
                     [0, -2, 2, -1], [0, 0, -1, 2]], 1152, True)]
    if args.e6:
        E6 = [[2*int(i == j) for j in range(6)] for i in range(6)]
        for i, j in [(0, 2), (2, 3), (1, 3), (3, 4), (4, 5)]:
            E6[i][j] = E6[j][i] = -1
        cases.append(('E6', E6, 51840, True))
    result = {'scope': 'Exact finite closure conditional only on the stated geometric source and marked identities',
              'input_source': 'Cartan matrices and all raw coroot 2-torsion points; no former finite output imported',
              'results': [run(*case) for case in cases]}
    path = Path(__file__).with_name('small_marked_closure_with_e6.json' if args.e6 else 'small_marked_closure.json')
    path.write_text(json.dumps(result, indent=2) + '\n')
    for row in result['results']:
        print(row['type'], row['status'], 'sources', row['same_I_source_labels'], '/', row['weyl_order'], flush=True)
        for b in row.get('blocks', []):
            print('  orbit', len(b['orbit']), b['status'], 'last length', b['layers'][-1]['length'],
                  'residual', b['layers'][-1]['unresolved_states'], flush=True)
