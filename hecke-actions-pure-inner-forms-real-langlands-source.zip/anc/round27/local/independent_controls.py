#!/usr/bin/env python3
"""Independent local controls: exact rank-one periods and Euclidean E8 roots.

No Round26 implementation, JSON, Weyl cache, or certificate is imported.
The rank-one all-degree formula follows from a two-period recurrence.
The E8 control checks the geometric anchor's hypothesis, not the large
finite forest or the geometric proof.
"""
from fractions import Fraction
from itertools import combinations, product
from pathlib import Path
import json


def add(x, y):
    return tuple(a + b for a, b in zip(x, y))


def dot(x, y):
    return sum(a * b for a, b in zip(x, y))


def rank_one():
    # Exponents refer to u,z.  The hypersurface is f=u*z^2.
    f = (1, 2)
    cases = {
        'canonical_s': {'a': (1, 1), 'b': (0, 1), 'twist': 1},
        'identity_e': {'a': (0, 1), 'b': (1, 1), 'twist': 0},
        'incorrect_untwisted_s': {'a': (1, 1), 'b': (0, 1), 'twist': 0},
    }
    result = {}
    for name, case in cases.items():
        a, b, twist = case['a'], case['b'], case['twist']
        assert add(a, b) == f
        # In k[u,z], a domain, ((a*b):a)=(b) and conversely.
        # Thus ...--b-->R--a-->R is an exact periodic resolution.
        weight = lambda monomial: monomial[1] - monomial[0]
        weights = [-twist]
        generator = twist
        for j in range(1, 65):
            generator += weight(a if j % 2 else b)
            weights.append(-generator)
        if name == 'canonical_s':
            expected = [-(j // 2 + 1) for j in range(65)]
            formula = '-(floor(j/2)+1)*alpha for every j>=0'
        elif name == 'identity_e':
            expected = [-((j + 1) // 2) for j in range(65)]
            formula = '-ceil(j/2)*alpha for every j>=0'
        else:
            expected = [-(j // 2) for j in range(65)]
            formula = '-floor(j/2)*alpha for every j>=0'
        assert weights == expected
        result[name] = {
            'factorization_exponents': [a, b],
            'source_character_alpha_units': twist,
            'ext_character_formula': formula,
            'first_ten_ext_characters_alpha_units': weights[:10],
            'torus_invariant_degrees':
                'none' if name == 'canonical_s' else
                ([0] if name == 'identity_e' else [0, 1]),
            'all_degree_justification':
                'Polynomial-domain annihilator identities plus the two-step character recurrence; not a truncation inference.',
        }
    return result


def solve(a, b):
    n = len(a)
    m = [[Fraction(x) for x in row] + [Fraction(y)]
         for row, y in zip(a, b)]
    for j in range(n):
        p = next(i for i in range(j, n) if m[i][j])
        m[j], m[p] = m[p], m[j]
        c = m[j][j]
        m[j] = [x / c for x in m[j]]
        for i in range(n):
            if i != j:
                c = m[i][j]
                m[i] = [x - c * y for x, y in zip(m[i], m[j])]
    return [row[-1] for row in m]


def determinant(a):
    n = len(a)
    m = [[Fraction(x) for x in row] for row in a]
    d = Fraction(1)
    for j in range(n):
        p = next(i for i in range(j, n) if m[i][j])
        if p != j:
            m[p], m[j] = m[j], m[p]
            d = -d
        c = m[j][j]
        d *= c
        for i in range(j + 1, n):
            q = m[i][j] / c
            m[i] = [x - q * y for x, y in zip(m[i], m[j])]
    return int(d)


def euclidean_e8():
    # All vectors are twice the usual Euclidean roots; squared length is 8.
    roots = set()
    for i, j in combinations(range(8), 2):
        for a, b in product((-2, 2), repeat=2):
            x = [0] * 8
            x[i], x[j] = a, b
            roots.add(tuple(x))
    for x in product((-1, 1), repeat=8):
        if sum(a < 0 for a in x) % 2 == 0:
            roots.add(x)
    assert len(roots) == 240 and {dot(x, x) for x in roots} == {8}
    simple = [(1, -1, -1, -1, -1, -1, -1, 1),
              (2, 2, 0, 0, 0, 0, 0, 0)]
    for i in range(6):
        x = [0] * 8
        x[i], x[i + 1] = -2, 2
        simple.append(tuple(x))
    assert set(simple).issubset(roots)
    # This rho pairs to 2 with each twice-simple-root, so positivity is
    # determined independently of a root-coefficient or Coxeter table.
    rho = (0, 1, 2, 3, 4, 5, 6, 23)
    assert [dot(rho, s) for s in simple] == [2] * 8
    positive = {x for x in roots if dot(rho, x) > 0}
    assert len(positive) == 120
    word = '5423143565423143546765423143542654787654231435426543176542348765'

    def reflect(x, i):
        num = dot(x, simple[i])
        assert num % 4 == 0
        return tuple(a - (num // 4) * b for a, b in zip(x, simple[i]))

    def act(x, inverse=False):
        for c in word if inverse else reversed(word):
            x = reflect(x, int(c) - 1)
        return x

    assert all(reflect(x, i) in roots for x in roots for i in range(8))
    length = sum(dot(rho, act(x)) < 0 for x in positive)
    assert length == len(word) == 64
    assert all(act(act(s)) == s for s in simple)
    left = [i + 1 for i, s in enumerate(simple) if dot(rho, act(s, True)) < 0]
    right = [i + 1 for i, s in enumerate(simple) if dot(rho, act(s)) < 0]
    assert left == right == [5]

    phase = [0, 0, 0, 0, 0, 2, 0, 2]
    p = tuple(sum(phase[j] * simple[j][i] for j in range(8)) for i in range(8))
    basis = [[simple[j][i] for j in range(8)] for i in range(8)]
    moved_coefficients = solve(basis, act(p))
    assert all(x.denominator == 1 for x in moved_coefficients)
    moved = [int(x) % 4 for x in moved_coefficients]
    assert moved == [0, 0, 2, 2, 0, 0, 2, 2] and moved != phase
    colors = [(dot(s, p) // 4) % 4 for s in simple]
    assert colors == [0, 0, 0, 0, 2, 0, 0, 0]
    central_roots = {x for x in roots if dot(x, p) % 16 == 0}
    kp = central_roots & positive
    assert len(central_roots) == 112 and len(kp) == 56
    ks = sorted(x for x in kp if not any(
        tuple(a - b for a, b in zip(x, y)) in kp for y in kp))
    assert len(ks) == 8
    cartan = [[dot(x, y) // 4 for y in ks] for x in ks]
    adjacency = [[j for j in range(8) if cartan[i][j] == -1] for i in range(8)]
    branch = [i for i in range(8) if len(adjacency[i]) == 3]
    assert len(branch) == 1
    arms = []
    for start in adjacency[branch[0]]:
        prev, cur, length_arm = branch[0], start, 1
        while len(adjacency[cur]) == 2:
            nxt = next(j for j in adjacency[cur] if j != prev)
            prev, cur, length_arm = cur, nxt, length_arm + 1
        assert len(adjacency[cur]) == 1
        arms.append(length_arm)
    assert sorted(arms) == [1, 1, 5]
    assert determinant(cartan) == 4
    return {
        'model': 'Euclidean E8: roots +/-e_i+/-e_j and even half-spin roots; integer doubled coordinates',
        'root_count': len(roots), 'positive_roots': len(positive),
        'word': word, 'length': length, 'left_descents': left,
        'right_descents': right, 'involution': True,
        'raw_phase_mod4': phase, 'image_raw_phase_mod4': moved,
        'simple_root_phases_mod4': colors,
        'centralizer_positive_roots': len(kp),
        'centralizer_simple_roots_doubled_euclidean': ks,
        'centralizer_cartan': cartan,
        'centralizer_cartan_determinant': determinant(cartan),
        'centralizer_dynkin_arm_lengths': sorted(arms),
        'centralizer_type': 'D8',
        'geometric_anchor_hypothesis': 'w(t) != t, hence w and w^-1 are outside W_K',
        'scope': 'Does not reverify the large E8 finite forest or prove local geometric vanishing.',
    }


if __name__ == '__main__':
    result = {'rank_one': rank_one(), 'e8_anchor': euclidean_e8(),
              'scope_correction': {
                  'group': 'GL2',
                  'automorphism': 'theta(g)=g/det(g)',
                  'root_action': 'identity; restricts to identity on SL2',
                  'central_torus_action': 'z*I maps to z^-1*I',
                  'consequence': 'The marked fiber theorem assumes theta=id_G before global torus separation.'}}
    output = Path(__file__).with_name('independent_controls.json')
    output.write_text(json.dumps(result, indent=2) + '\n')
    print('Verified exact rank-one period recurrences and the E8 geometric hypothesis in an independent Euclidean model.')
