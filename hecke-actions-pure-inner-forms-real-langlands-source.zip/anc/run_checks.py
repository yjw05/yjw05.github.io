#!/usr/bin/env python3
"""Run portable certificate checks in an isolated copy of these inputs."""
from pathlib import Path
import argparse
import json
import shutil
import subprocess
import sys
import tempfile
import time

HERE=Path(__file__).resolve().parent
parser=argparse.ArgumentParser(description=__doc__)
parser.add_argument('--outer-e6',action='store_true',help='also rebuild all outer-E6 source, KL, event, and positive rows')
parser.add_argument('--output',type=Path,default=HERE/'replay_output')
args=parser.parse_args()
output=args.output.resolve()
output.mkdir(parents=True,exist_ok=True)
ledger=[]

with tempfile.TemporaryDirectory(prefix='categorical-comparison-') as temp:
    work=Path(temp)/'ancillary'
    def ignored(directory,names):
        return [n for n in names if n in {'replay_output','__pycache__'}]
    shutil.copytree(HERE,work,ignore=ignored)

    def run(name,command):
        before=time.monotonic()
        result=subprocess.run(command,cwd=work,stdout=subprocess.PIPE,
                              stderr=subprocess.STDOUT,text=True)
        (output/(name+'.log')).write_text(result.stdout)
        ledger.append({'name':name,'command':command,'returncode':result.returncode,
                       'seconds':round(time.monotonic()-before,3)})
        print(f'{name}: '+('PASS' if result.returncode==0 else 'FAILED'),flush=True)
        (output/'replay_ledger.json').write_text(json.dumps(ledger,indent=2)+'\n')
        if result.returncode:
            print(result.stdout[-4000:])
            raise SystemExit(result.returncode)

    run('selected_anchor',[sys.executable,'round26/root_audit/check_e8_anchor.py'])
    run('euclidean_anchor_and_rank_one',[sys.executable,'round27/local/independent_controls.py'])
    run('schreier_model',[sys.executable,'round21/root_audit/audit_e8_schreier_model.py'])
    run('schreier_euclidean',[sys.executable,'round20/e8_frontier/audit_schreier_euclidean.py'])
    run('nonstable_middle_roots',[sys.executable,'round26/r1_r2/nonstable_middle_root_check.py'])
    run('outer_small_sources',[sys.executable,'round26/descent/check_outer_small_sources.py'])
    run('outer_small_replay',[sys.executable,'round26/descent/replay_outer_small_sources.py'])
    run('compile_core',['g++','-O2','-std=c++17','-I','round21/computation',
                       'round26/root_audit/audit_e8_core_root_matrices.cpp','-o',str(work/'core-check')])
    run('core_tree',[str(work/'core-check')])

    if args.outer_e6:
        jobs=[
          ('source','e6_source_replay.cpp',[
             'round26/descent/e6_inputs/e6_base_labels.txt',
             'round26/descent/e6_same_I_sources.txt','round26/descent/e6_source_replay.json']),
          ('mu','e6_mu_left_audit.cpp',[
             'round26/descent/e6_inputs/e6_base_labels.txt',
             'round26/descent/e6_inputs/e6_expected_mu.txt','round26/descent/e6_mu_left_replay.json']),
          ('events','e6_event_independent_audit.cpp',[
             'round26/descent/e6_inputs/e6_base_labels.txt',
             'round26/descent/e6_inputs/e6_expected_mu.txt',
             'round26/descent/e6_inputs/e6_endpoint_events.txt',
             'round26/descent/e6_inputs/e6_endpoint_missing.txt',
             'round26/descent/e6_residual_rows_replay.txt','round26/descent/e6_event_replay.json'])]
        for name,source,arguments in jobs:
            executable=work/('e6-'+name)
            run('compile_e6_'+name,['g++','-O2','-std=c++17','round26/descent/'+source,'-o',str(executable)])
            run('e6_'+name,[str(executable)]+arguments)
        run('e6_positive',[sys.executable,'round26/descent/e6_augmented_positive_replay.py'])

    # Preserve the actual generated JSON outputs beside their program logs.
    wanted=[
      'round26/root_audit/e8_geometric_anchor.json',
      'round26/root_audit/e8_core_root_matrix_replay.json',
      'round27/local/independent_controls.json',
      'round21/root_audit/e8_schreier_model_independent_audit.json',
      'round26/descent/outer_small_independent_replay.json']
    if args.outer_e6:
        wanted += ['round26/descent/'+n+'.json' for n in
                   ['e6_source_replay','e6_mu_left_replay','e6_event_replay','e6_augmented_positive_replay']]
    for name in wanted:
        source=work/name
        if not source.is_file():
            raise FileNotFoundError(source)
        shutil.copy2(source,output/source.name)

print(f'Completed {len(ledger)} commands. Results: {output}')
